# 🏰 Терский Мир — РВПИ

Стandalone HTML файл для Ролевой-Военно-Политической Игры «Терский Мир» с тёмным славянским фэнтези оформлением.

## 📦 Что внутри

Один файл `tersky-mir.html` со всем функционалом:

- 🔐 **Аутентификация** (Firebase Auth, email/password)
- 🛡️ **Фракции** — регистрация княжества + 8 секций статистики
- 📜 **Посты игроков** с вложениями + вердикты администратора
- ⚔️ **Вердикты** с автообновлением статистики фракции
- 💬 **Чаты** (realtime) между игроками с итогами встреч
- 📰 **Новости** (общая лента)
- ⚔️ **Военные баталии** (силы сторон, таймер постов, статус)
- 📖 **Хроника** и 🐾 **Бестиарий**
- 🛡️ **Anti-scraping**: запрет копирования, контекстного меню, F12, noindex

## 🚀 Быстрый старт

### 1. Создайте проект Firebase

1. Перейдите на [console.firebase.google.com](https://console.firebase.google.com)
2. Нажмите **Add project** → создайте проект «Терский Мир»

### 2. Подключите веб-приложение

1. В консоли Firebase нажмите **Add app → Web (</>)**
2. Введите название приложения
3. Скопируйте `firebaseConfig` (apiKey, authDomain, projectId и т.д.)

### 3. Включите Authentication

1. В меню слева → **Authentication → Sign-in method**
2. Включите **Email/Password**

### 4. Создайте Firestore Database

1. В меню слева → **Firestore Database → Create database**
2. Выберите **production mode**
3. Выберите регион (ближайший к игрокам)

### 5. Настройте правила безопасности

В **Firestore Database → Rules** вставьте:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null;
    }
    match /users/{userId} {
      allow read: if request.auth != null;
      allow create, update: if request.auth != null && request.auth.uid == userId;
      allow delete: if request.auth != null;
    }
  }
}
```

### 6. Вставьте конфиг в HTML

Откройте `tersky-mir.html` в любом редакторе кода и найдите строку:

```javascript
const firebaseConfig = {
  apiKey: "ВАШ_API_KEY",
  authDomain: "ВАШ_ПРОЕКТ.firebaseapp.com",
  ...
};
```

Замените значения на свои из Firebase Console.

### 7. Загрузите на GitHub

```bash
git init
git add tersky-mir.html README.md
git commit -m "Терский Мир — РВПИ"
git branch -M main
git remote add origin https://github.com/ВАШ_НИК/tersky-mir.git
git push -u origin main
```

Затем включите **GitHub Pages**: Settings → Pages → Source: main branch → Save.

Сайт будет доступен по адресу: `https://ВАШ_НИК.github.io/tersky-mir/tersky-mir.html`

## 🎨 Цветовая палитра

Тёмное славянское фэнтези:

| Элемент | Цвет |
|---------|------|
| Фон | `#0a0f0f` болотно-чёрный |
| Карточки | `#11181a` |
| Акцент | `#3a7d74` мшисто-бирюзовый |
| Текст | `#e8f0ed` слоновая кость |
| Шрифты | Cinzel + Cormorant Garamond |

## 📋 Использование

1. **Первый зарегистрированный пользователь** автоматически становится Администратором
2. Администратор может:
   - Управлять пользователями (роли, удаление)
   - Утверждать фракции игроков
   - Редактировать статистику фракций (секция за секцией)
   - Выносить вердикты по постам (ролевая + техническая части + автообновление статов)
   - Создавать новости, чаты, баталии, хронику, бестиарий
3. Игроки могут:
   - Регистрировать фракцию
   - Писать посты с вложениями
   - Участвовать в чатах
   - Просматривать вести, хронику, бестиарий

## 🔄 Realtime

Все данные обновляются в реальном времени через Firestore `onSnapshot`:
- Новые сообщения в чатах появляются мгновенно
- Новые посты/новости видны сразу после создания
- Вердикты обновляют статистику автоматически

## 🛡️ Anti-scraping

- `user-select: none` на всём сайте
- Запрет контекстного меню, drag-and-drop, копирования
- Блокировка F12, Ctrl+Shift+I/J/C, Ctrl+U/S/P
- `noindex, nofollow, noarchive` в мета-тегах
- Запрет печати (`@media print`)

## 📁 Структура

```
tersky-mir.html  — весь сайт в одном файле (~80KB)
README.md        — эта инструкция
```

## ⚠️ Важно

- **Размер вложений**: Firestore имеет лимит 1MB на документ. Вложения хранятся как base64 внутри поста — не загружайте файлы больше ~500KB.
- Для больших файлов подключите Firebase Storage (потребуется доп. настройка).
- Первый пользователь = Администратор. Убедитесь, что это нужный человек.

## 🆘 Проблемы

- **Белый экран** → проверьте консоль браузера (F12), скорее всего не настроен Firebase
- **Permission denied** → проверьте правила Firestore
- **Не входится** → проверьте, что включён Email/Password в Auth

---

**Терский Мир** · Ролевая-Военно-Политическая Игра · 2025
