'use client'

import { useState, useEffect, useRef, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, Shield, Newspaper, BookOpen, PawPrint, Swords,
  MessageSquare, FileText, ScrollText, LayoutDashboard, Flag,
  CornerDownLeft, ArrowUp, ArrowDown, X, Coins, Activity, User, Compass, Bookmark, Trophy, Crown,
} from 'lucide-react'
import { useAppStore, type ViewKey } from '@/stores/app-store'
import { cn } from '@/lib/utils'

interface CommandItem {
  id: string
  label: string
  hint?: string
  icon: React.ComponentType<{ className?: string }>
  type: 'view' | 'post' | 'news' | 'chronicle' | 'bestiary'
  action: () => void
}

interface CommandPaletteProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CommandPalette({ open, onOpenChange }: CommandPaletteProps) {
  const { setView } = useAppStore()
  const [query, setQuery] = useState('')
  const [selectedIndex, setSelectedIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const listRef = useRef<HTMLDivElement>(null)

  // Загружаем все поисковые индексы
  const { data: postsData } = useQuery<{ posts: Array<{ id: string; title: string; status: string }> }>({
    queryKey: ['cmd-posts'],
    queryFn: async () => (await fetch('/api/posts')).json(),
    enabled: open,
  })
  const { data: newsData } = useQuery<{ news: Array<{ id: string; title: string; category: string }> }>({
    queryKey: ['cmd-news'],
    queryFn: async () => (await fetch('/api/news')).json(),
    enabled: open,
  })
  const { data: chronicleData } = useQuery<{ articles: Array<{ id: string; title: string }> }>({
    queryKey: ['cmd-chronicle'],
    queryFn: async () => (await fetch('/api/chronicle')).json(),
    enabled: open,
  })
  const { data: bestiaryData } = useQuery<{ entries: Array<{ id: string; name: string; category: string }> }>({
    queryKey: ['cmd-bestiary'],
    queryFn: async () => (await fetch('/api/bestiary')).json(),
    enabled: open,
  })

  // Строим список команд
  const items: CommandItem[] = useMemo(() => {
    const viewItems: CommandItem[] = [
      { id: 'v-dashboard', label: 'Сводка', icon: LayoutDashboard, type: 'view', action: () => setView('dashboard') },
      { id: 'v-faction', label: 'Моё княжество', icon: Shield, type: 'view', action: () => setView('my-faction') },
      { id: 'v-posts', label: 'Мои посты', icon: ScrollText, type: 'view', action: () => setView('posts') },
      { id: 'v-chats', label: 'Переговоры', icon: MessageSquare, type: 'view', action: () => setView('chats') },
      { id: 'v-battles', label: 'Военные дела', icon: Swords, type: 'view', action: () => setView('battles') },
      { id: 'v-news', label: 'Вести мира', icon: Newspaper, type: 'view', action: () => setView('news') },
      { id: 'v-chronicle', label: 'Хроника', icon: BookOpen, type: 'view', action: () => setView('chronicle') },
      { id: 'v-bestiary', label: 'Бестиарий', icon: PawPrint, type: 'view', action: () => setView('bestiary') },
      { id: 'v-activity', label: 'Летопись (Активность)', icon: Activity, type: 'view', action: () => setView('activity') },
      { id: 'v-profile', label: 'Профиль', icon: User, type: 'view', action: () => setView('profile') },
      { id: 'v-directory', label: 'Державы мира', icon: Compass, type: 'view', action: () => setView('directory') },
      { id: 'v-bookmarks', label: 'Закладки', icon: Bookmark, type: 'view', action: () => setView('bookmarks') },
      { id: 'v-achievements', label: 'Достижения', icon: Trophy, type: 'view', action: () => setView('achievements') },
      { id: 'v-leaderboard', label: 'Зал славы', icon: Crown, type: 'view', action: () => setView('leaderboard') },
    ]

    const postItems: CommandItem[] = (postsData?.posts || []).slice(0, 20).map((p) => ({
      id: `p-${p.id}`,
      label: p.title,
      hint: `Пост · ${p.status === 'PENDING' ? 'Ожидает' : 'С вердиктом'}`,
      icon: FileText,
      type: 'post',
      action: () => setView('posts'),
    }))

    const newsItems: CommandItem[] = (newsData?.news || []).slice(0, 15).map((n) => ({
      id: `n-${n.id}`,
      label: n.title,
      hint: `Новость · ${n.category}`,
      icon: Newspaper,
      type: 'news',
      action: () => setView('news'),
    }))

    const chronicleItems: CommandItem[] = (chronicleData?.articles || []).slice(0, 15).map((a) => ({
      id: `c-${a.id}`,
      label: a.title,
      hint: 'Хроника',
      icon: BookOpen,
      type: 'chronicle',
      action: () => setView('chronicle'),
    }))

    const bestiaryItems: CommandItem[] = (bestiaryData?.entries || []).slice(0, 15).map((b) => ({
      id: `b-${b.id}`,
      label: b.name,
      hint: `Бестиарий · ${b.category}`,
      icon: PawPrint,
      type: 'bestiary',
      action: () => setView('bestiary'),
    }))

    return [...viewItems, ...postItems, ...newsItems, ...chronicleItems, ...bestiaryItems]
  }, [postsData, newsData, chronicleData, bestiaryData, setView])

  // Фильтрация
  const filtered = useMemo(() => {
    if (!query.trim()) return items
    const q = query.toLowerCase()
    return items.filter((i) =>
      i.label.toLowerCase().includes(q) ||
      (i.hint?.toLowerCase().includes(q) ?? false)
    )
  }, [items, query])

  // Сброс при открытии
  useEffect(() => {
    if (open) {
      setQuery('')
      setSelectedIndex(0)
      setTimeout(() => inputRef.current?.focus(), 50)
    }
  }, [open])

  // Сброс выбора при изменении фильтра
  useEffect(() => {
    setSelectedIndex(0)
  }, [query])

  // Прокрутка к выбранному элементу
  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${selectedIndex}"]`)
    el?.scrollIntoView({ block: 'nearest' })
  }, [selectedIndex])

  // Обработка клавиш
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSelectedIndex((i) => Math.min(i + 1, filtered.length - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSelectedIndex((i) => Math.max(i - 1, 0))
    } else if (e.key === 'Enter') {
      e.preventDefault()
      const item = filtered[selectedIndex]
      if (item) {
        item.action()
        onOpenChange(false)
      }
    } else if (e.key === 'Escape') {
      e.preventDefault()
      onOpenChange(false)
    }
  }

  // Группировка по типу
  const grouped = useMemo(() => {
    const groups: Record<string, CommandItem[]> = {}
    for (const item of filtered) {
      const type = item.type === 'view' ? 'Разделы' : item.type === 'post' ? 'Посты' : item.type === 'news' ? 'Новости' : item.type === 'chronicle' ? 'Хроника' : 'Бестиарий'
      if (!groups[type]) groups[type] = []
      groups[type].push(item)
    }
    return groups
  }, [filtered])

  let flatIndex = 0

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] px-4"
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm vignette"
            onClick={() => onOpenChange(false)}
          />

          {/* Palette */}
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.97 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-xl rounded-lg border border-border/60 bg-card/95 backdrop-blur-xl shadow-2xl overflow-hidden"
          >
            {/* Search input */}
            <div className="flex items-center gap-3 p-4 border-b border-border/40">
              <Search className="h-4 w-4 text-muted-foreground shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Поиск по разделам, постам, новостям..."
                className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none"
              />
              <kbd className="px-1.5 py-0.5 rounded bg-background/60 border border-border/40 text-[9px] font-mono text-muted-foreground">
                ESC
              </kbd>
              <button
                onClick={() => onOpenChange(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Results */}
            <div ref={listRef} className="max-h-[50vh] overflow-y-auto custom-scroll p-2">
              {filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Search className="h-8 w-8 text-muted-foreground/40 mb-2" />
                  <p className="text-sm text-muted-foreground">Ничего не найдено</p>
                  <p className="text-[10px] text-muted-foreground/60 mt-1">Попробуйте другой запрос</p>
                </div>
              ) : (
                Object.entries(grouped).map(([groupName, groupItems]) => (
                  <div key={groupName} className="mb-2">
                    <p className="px-2 py-1 text-[10px] uppercase tracking-wider font-heading text-muted-foreground/70">
                      {groupName}
                    </p>
                    {groupItems.map((item) => {
                      const idx = flatIndex++
                      const selected = idx === selectedIndex
                      const Icon = item.icon
                      return (
                        <button
                          key={item.id}
                          data-idx={idx}
                          onClick={() => {
                            item.action()
                            onOpenChange(false)
                          }}
                          onMouseEnter={() => setSelectedIndex(idx)}
                          className={cn(
                            'w-full flex items-center gap-3 px-2 py-2 rounded-md text-left transition-colors',
                            selected ? 'bg-accent/15 text-accent' : 'text-foreground hover:bg-muted/30'
                          )}
                        >
                          <Icon className={cn('h-4 w-4 shrink-0', selected ? 'text-accent' : 'text-muted-foreground')} />
                          <span className="flex-1 text-sm truncate">{item.label}</span>
                          {item.hint && (
                            <span className="text-[10px] text-muted-foreground/70 shrink-0">{item.hint}</span>
                          )}
                          {selected && <CornerDownLeft className="h-3 w-3 text-accent shrink-0" />}
                        </button>
                      )
                    })}
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between p-2 border-t border-border/40 bg-secondary/20 text-[10px] text-muted-foreground/70">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <ArrowUp className="h-3 w-3" /><ArrowDown className="h-3 w-3" /> навигация
                </span>
                <span className="flex items-center gap-1">
                  <CornerDownLeft className="h-3 w-3" /> выбрать
                </span>
              </div>
              <span>{filtered.length} результатов</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
