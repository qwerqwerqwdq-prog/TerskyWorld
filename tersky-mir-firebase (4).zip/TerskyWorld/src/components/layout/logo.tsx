'use client'

interface LogoProps {
  size?: number
  className?: string
}

// Стилизованный герб «Терского Мира» — рунический символ в круге
export function Logo({ size = 48, className = '' }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Герб Терского Мира"
    >
      <defs>
        <radialGradient id="logo-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#3a7d74" stopOpacity="0.6" />
          <stop offset="60%" stopColor="#1a3a35" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#0a0f0f" stopOpacity="0" />
        </radialGradient>
      </defs>
      {/* Свечение */}
      <circle cx="50" cy="50" r="48" fill="url(#logo-glow)" />
      {/* Внешний круг */}
      <circle cx="50" cy="50" r="36" stroke="#3a7d74" strokeWidth="1.5" fill="none" opacity="0.7" />
      <circle cx="50" cy="50" r="32" stroke="#8fbfb5" strokeWidth="0.8" fill="none" opacity="0.5" />
      {/* Рунический символ — стилизованная «Т» (Терский) с мечом */}
      <g stroke="#e8f0ed" strokeWidth="2.2" strokeLinecap="round" fill="none">
        {/* Горизонтальная перекладина */}
        <line x1="35" y1="38" x2="65" y2="38" />
        {/* Вертикальный ствол */}
        <line x1="50" y1="38" x2="50" y2="70" />
        {/* Угловые элементы (руны) */}
        <line x1="40" y1="44" x2="50" y2="44" />
        <line x1="60" y1="44" x2="50" y2="44" />
        {/* Основание (меч) */}
        <line x1="46" y1="70" x2="54" y2="70" />
      </g>
      {/* Орнаментальные точки */}
      <circle cx="50" cy="22" r="1.8" fill="#3a7d74" />
      <circle cx="50" cy="78" r="1.8" fill="#3a7d74" />
      <circle cx="22" cy="50" r="1.8" fill="#3a7d74" />
      <circle cx="78" cy="50" r="1.8" fill="#3a7d74" />
    </svg>
  )
}
