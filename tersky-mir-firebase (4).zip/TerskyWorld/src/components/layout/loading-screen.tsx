'use client'

import { Logo } from '@/components/layout/logo'

export function LoadingScreen() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-6">
      <div className="relative">
        <Logo size={80} className="animate-pulse" />
      </div>
      <div className="flex items-center gap-3 text-muted-foreground">
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: '0ms' }} />
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: '150ms' }} />
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
      <p className="font-heading text-sm tracking-widest text-muted-foreground uppercase">
        Врата открываются…
      </p>
    </div>
  )
}
