'use client'

import { useState, Suspense, lazy, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  LayoutDashboard, Shield, ScrollText, MessageSquare, Swords,
  Newspaper, BookOpen, PawPrint, LogOut, Menu, X, ChevronDown,
  Users, Flag, FileText, Settings, Home, ChevronRight, Activity, User, Compass, Bookmark, Trophy, Crown,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore, type ViewKey } from '@/stores/app-store'
import { useAuth } from '@/lib/auth-context'
import { Logo } from '@/components/layout/logo'
import { NotificationsMenu } from '@/components/layout/notifications-menu'
import { CommandPalette } from '@/components/layout/command-palette'
import { KeyboardShortcutsHelp } from '@/components/layout/keyboard-shortcuts-help'
import { QuickActionsFab } from '@/components/layout/quick-actions-fab'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface NavItem {
  key: ViewKey
  label: string
  icon: React.ReactNode
  group: 'player' | 'admin'
  badgeKey?: 'pending-posts' | 'pending-verdicts'
}

const playerNav: NavItem[] = [
  { key: 'dashboard', label: 'Сводка', icon: <LayoutDashboard className="h-4 w-4" />, group: 'player' },
  { key: 'my-faction', label: 'Моё княжество', icon: <Shield className="h-4 w-4" />, group: 'player' },
  { key: 'posts', label: 'Мои посты', icon: <ScrollText className="h-4 w-4" />, group: 'player', badgeKey: 'pending-verdicts' },
  { key: 'chats', label: 'Переговоры', icon: <MessageSquare className="h-4 w-4" />, group: 'player' },
  { key: 'battles', label: 'Военные дела', icon: <Swords className="h-4 w-4" />, group: 'player' },
  { key: 'news', label: 'Вести мира', icon: <Newspaper className="h-4 w-4" />, group: 'player' },
  { key: 'chronicle', label: 'Хроника', icon: <BookOpen className="h-4 w-4" />, group: 'player' },
  { key: 'bestiary', label: 'Бестиарий', icon: <PawPrint className="h-4 w-4" />, group: 'player' },
  { key: 'activity', label: 'Летопись', icon: <Activity className="h-4 w-4" />, group: 'player' },
  { key: 'directory', label: 'Державы мира', icon: <Compass className="h-4 w-4" />, group: 'player' },
  { key: 'bookmarks', label: 'Закладки', icon: <Bookmark className="h-4 w-4" />, group: 'player' },
  { key: 'achievements', label: 'Достижения', icon: <Trophy className="h-4 w-4" />, group: 'player' },
  { key: 'leaderboard', label: 'Зал славы', icon: <Crown className="h-4 w-4" />, group: 'player' },
]

const adminNav: NavItem[] = [
  { key: 'admin-users', label: 'Игроки', icon: <Users className="h-4 w-4" />, group: 'admin' },
  { key: 'admin-factions', label: 'Фракции', icon: <Flag className="h-4 w-4" />, group: 'admin' },
  { key: 'admin-posts', label: 'Все посты', icon: <FileText className="h-4 w-4" />, group: 'admin', badgeKey: 'pending-posts' },
  { key: 'admin-news', label: 'Новости', icon: <Newspaper className="h-4 w-4" />, group: 'admin' },
  { key: 'admin-chats', label: 'Чаты', icon: <MessageSquare className="h-4 w-4" />, group: 'admin' },
  { key: 'admin-battles', label: 'Баталии', icon: <Swords className="h-4 w-4" />, group: 'admin' },
  { key: 'admin-chronicle', label: 'Хроника', icon: <BookOpen className="h-4 w-4" />, group: 'admin' },
  { key: 'admin-bestiary', label: 'Бестиарий', icon: <PawPrint className="h-4 w-4" />, group: 'admin' },
]

// Lazy-загрузка views
const DashboardView = lazy(() => import('@/components/views/dashboard-view').then((m) => ({ default: m.DashboardView })))
const FactionView = lazy(() => import('@/components/views/faction-view').then((m) => ({ default: m.FactionView })))
const PostsView = lazy(() => import('@/components/views/posts-view').then((m) => ({ default: m.PostsView })))
const ChatsView = lazy(() => import('@/components/views/chats-view').then((m) => ({ default: m.ChatsView })))
const BattlesView = lazy(() => import('@/components/views/battles-view').then((m) => ({ default: m.BattlesView })))
const NewsView = lazy(() => import('@/components/views/news-view').then((m) => ({ default: m.NewsView })))
const ChronicleView = lazy(() => import('@/components/views/chronicle-view').then((m) => ({ default: m.ChronicleView })))
const BestiaryView = lazy(() => import('@/components/views/bestiary-view').then((m) => ({ default: m.BestiaryView })))
const ActivityView = lazy(() => import('@/components/views/activity-view').then((m) => ({ default: m.ActivityView })))
const ProfileView = lazy(() => import('@/components/views/profile-view').then((m) => ({ default: m.ProfileView })))
const DirectoryView = lazy(() => import('@/components/views/directory-view').then((m) => ({ default: m.DirectoryView })))
const BookmarksView = lazy(() => import('@/components/views/bookmarks-view').then((m) => ({ default: m.BookmarksView })))
const AchievementsView = lazy(() => import('@/components/views/achievements-view').then((m) => ({ default: m.AchievementsView })))
const LeaderboardView = lazy(() => import('@/components/views/leaderboard-view').then((m) => ({ default: m.LeaderboardView })))
const AdminUsersView = lazy(() => import('@/components/views/admin-users-view').then((m) => ({ default: m.AdminUsersView })))
const AdminFactionsView = lazy(() => import('@/components/views/admin-factions-view').then((m) => ({ default: m.AdminFactionsView })))
const AdminPostsView = lazy(() => import('@/components/views/admin-posts-view').then((m) => ({ default: m.AdminPostsView })))
const AdminNewsView = lazy(() => import('@/components/views/admin-news-view').then((m) => ({ default: m.AdminNewsView })))
const AdminChatsView = lazy(() => import('@/components/views/admin-chats-view').then((m) => ({ default: m.AdminChatsView })))
const AdminBattlesView = lazy(() => import('@/components/views/admin-battles-view').then((m) => ({ default: m.AdminBattlesView })))

function ViewFallback() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="flex items-center gap-3 text-muted-foreground">
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" />
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: '150ms' }} />
        <div className="h-2 w-2 rounded-full bg-accent animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
    </div>
  )
}

function renderView(view: ViewKey, selectedId: string | null) {
  const props = { selectedId }
  switch (view) {
    case 'dashboard': return <DashboardView {...props} />
    case 'my-faction': return <FactionView {...props} />
    case 'posts': return <PostsView {...props} />
    case 'chats': return <ChatsView {...props} />
    case 'battles': return <BattlesView {...props} />
    case 'news': return <NewsView {...props} />
    case 'chronicle': return <ChronicleView {...props} />
    case 'bestiary': return <BestiaryView {...props} />
    case 'activity': return <ActivityView />
    case 'profile': return <ProfileView />
    case 'directory': return <DirectoryView />
    case 'bookmarks': return <BookmarksView />
    case 'achievements': return <AchievementsView />
    case 'leaderboard': return <LeaderboardView />
    case 'admin-users': return <AdminUsersView {...props} />
    case 'admin-factions': return <AdminFactionsView {...props} />
    case 'admin-posts': return <AdminPostsView {...props} />
    case 'admin-news': return <AdminNewsView {...props} />
    case 'admin-chats': return <AdminChatsView {...props} />
    case 'admin-battles': return <AdminBattlesView {...props} />
    case 'admin-chronicle': return <ChronicleView {...props} />
    case 'admin-bestiary': return <BestiaryView {...props} />
    default: return <DashboardView {...props} />
  }
}

export function AppShell() {
  const { user: session, signOut } = useAuth()
  const { currentView, setView, sidebarOpen, toggleSidebar, setSidebarOpen, selectedId } = useAppStore()
  const [adminOpen, setAdminOpen] = useState(true)

  const isAdmin = session?.role === 'ADMIN'
  const currentTitle = [...playerNav, ...adminNav].find((n) => n.key === currentView)?.label || 'Сводка'
  const currentGroup = [...playerNav, ...adminNav].find((n) => n.key === currentView)?.group || 'player'

  // Подсчёт постов ожидающих вердикта (для бейджей навигации)
  const { data: postsForBadges } = useQuery<{ posts: Array<{ id: string; status: string; authorId?: string }> }>({
    queryKey: ['nav-badges-posts'],
    queryFn: async () => (await fetch('/api/posts')).json(),
    refetchInterval: 30000,
  })
  const allPosts = postsForBadges?.posts || []
  const pendingPosts = allPosts.filter((p) => p.status === 'PENDING')
  const pendingVerdictsForPlayer = allPosts.filter((p) => p.status === 'PENDING' && p.authorId === session?.id).length
  const pendingPostsForAdmin = pendingPosts.length

  const badgeCount: Record<string, number> = {
    'pending-posts': pendingPostsForAdmin,
    'pending-verdicts': pendingVerdictsForPlayer,
  }

  // Command palette (Cmd+K)
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [shortcutsHelpOpen, setShortcutsHelpOpen] = useState(false)

  useEffect(() => {
    let lastKey = ''
    let lastKeyTime = 0
    const DOUBLE_PRESS_DELAY = 700 // мс

    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable

      // Cmd+K / Ctrl+K — открывает command palette
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setPaletteOpen((v) => !v)
        return
      }

      // Не обрабатываем остальные горячие клавиши в полях ввода
      if (isInput) return

      // Escape — закрываем command palette если открыт
      if (e.key === 'Escape' && paletteOpen) {
        setPaletteOpen(false)
        return
      }

      // G+буква — навигация (двойное нажатие)
      const now = Date.now()
      if (lastKey === 'g' && now - lastKeyTime < DOUBLE_PRESS_DELAY) {
        const map: Record<string, ViewKey> = {
          d: 'dashboard',
          f: 'my-faction',
          p: 'posts',
          c: 'chats',
          b: 'battles',
          n: 'news',
          h: 'chronicle',
          e: 'bestiary',
          a: 'activity',
          r: 'profile',
          o: 'directory',
          m: 'bookmarks',
          t: 'achievements',
          l: 'leaderboard',
        }
        const view = map[e.key.toLowerCase()]
        if (view) {
          e.preventDefault()
          setView(view)
          lastKey = ''
          return
        }
      }

      // Запоминаем текущую клавишу
      lastKey = e.key.toLowerCase()
      lastKeyTime = now
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [paletteOpen, setView])

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 h-14 border-b border-border/50 bg-card/80 backdrop-blur-md flex items-center gap-3 px-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          className="lg:hidden h-9 w-9"
          aria-label="Меню"
        >
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>

        <button
          onClick={() => setView('dashboard')}
          className="flex items-center gap-2.5 group"
          aria-label="На главную"
        >
          <Logo size={32} />
          <div className="hidden sm:block text-left">
            <h1 className="font-heading text-base font-semibold tracking-wider text-foreground leading-none group-hover:text-accent transition-colors">
              ТЕРСКИЙ МИР
            </h1>
            <p className="text-[10px] text-muted-foreground tracking-widest uppercase mt-0.5">
              {currentTitle}
            </p>
          </div>
        </button>

        {/* Breadcrumbs */}
        <nav className="hidden md:flex items-center gap-1.5 text-xs text-muted-foreground ml-2" aria-label="Breadcrumb">
          <ChevronRight className="h-3 w-3 text-muted-foreground/40" />
          <span className={cn(currentGroup === 'admin' && 'text-accent/80')}>{currentGroup === 'admin' ? 'Управление' : 'Держава'}</span>
          <ChevronRight className="h-3 w-3 text-muted-foreground/40" />
          <span className="text-foreground font-heading tracking-wide">{currentTitle}</span>
        </nav>

        <div className="ml-auto flex items-center gap-2">
          {/* Command palette trigger */}
          <button
            onClick={() => setPaletteOpen(true)}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted/30 border border-border/40 text-xs text-muted-foreground hover:text-accent hover:border-accent/30 hover:bg-muted/40 transition-all"
            aria-label="Поиск (Cmd+K)"
          >
            <span className="text-[10px]">Поиск</span>
            <kbd className="px-1.5 py-0.5 rounded bg-background/60 border border-border/40 text-[9px] font-mono">⌘K</kbd>
          </button>

          {/* Keyboard shortcuts help */}
          <button
            onClick={() => setShortcutsHelpOpen(true)}
            className="hidden md:flex h-9 w-9 rounded-md items-center justify-center text-muted-foreground hover:text-accent hover:bg-muted/40 transition-all border border-border/40 bg-muted/20"
            aria-label="Горячие клавиши (?)"
            title="Горячие клавиши (нажмите ?)"
          >
            <kbd className="text-[12px] font-bold">?</kbd>
          </button>

          <NotificationsMenu />

          {session?.faction && (
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-md bg-secondary/40 border border-border/40">
              <Shield className="h-3.5 w-3.5 text-accent" />
              <span className="text-sm font-heading tracking-wide">{session.faction.name}</span>
              {!session.faction.isApproved && (
                <span className="text-[10px] text-amber-400">(на утверждении)</span>
              )}
            </div>
          )}
          <button
            onClick={() => setView('profile')}
            className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-muted/40 transition-colors group"
            aria-label="Профиль"
          >
            <div className="h-8 w-8 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center text-accent font-heading text-sm group-hover:bg-accent/30 transition-colors">
              {session?.name?.[0]?.toUpperCase() || '?'}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-sm font-medium leading-none group-hover:text-accent transition-colors">{session?.name}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                {isAdmin ? 'Администратор' : 'Игрок'}
              </p>
            </div>
          </button>
          <Button
            variant="ghost"
            size="icon"
            onClick={async () => { try { await signOut() } catch { /* ignore */ } }}
            className="h-9 w-9 text-muted-foreground hover:text-destructive"
            aria-label="Выйти"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} />
      <KeyboardShortcutsHelp open={shortcutsHelpOpen} onOpenChange={setShortcutsHelpOpen} />
      <QuickActionsFab />

      {/* Body */}
      <div className="flex flex-1">
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={cn(
            'fixed lg:sticky top-14 left-0 z-30 h-[calc(100vh-3.5rem)] w-64 shrink-0 border-r border-border/50 bg-sidebar/80 backdrop-blur-md transition-transform duration-300 overflow-y-auto',
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          )}
        >
          <nav className="p-3 space-y-1">
            <div className="flex items-center gap-2 px-3 py-1.5 mb-1">
              <Home className="h-3 w-3 text-muted-foreground/60" />
              <p className="text-[10px] font-heading tracking-widest uppercase text-muted-foreground/70">
                Держава
              </p>
            </div>
            {playerNav.map((item) => (
              <NavLink
                key={item.key}
                item={item}
                active={currentView === item.key}
                badgeCount={item.badgeKey ? badgeCount[item.badgeKey] : undefined}
                onClick={() => {
                  setView(item.key)
                  setSidebarOpen(false)
                }}
              />
            ))}

            {isAdmin && (
              <>
                <div className="my-3 ornament-divider opacity-40" />
                <button
                  onClick={() => setAdminOpen((v) => !v)}
                  className="w-full flex items-center gap-2 px-3 py-2 text-[10px] font-heading tracking-widest uppercase text-muted-foreground/70 hover:text-foreground transition-colors"
                >
                  <Settings className="h-3.5 w-3.5" />
                  Управление
                  <ChevronDown className={cn('h-3 w-3 ml-auto transition-transform', adminOpen && 'rotate-180')} />
                </button>
                <AnimatePresence initial={false}>
                  {adminOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="space-y-1 overflow-hidden"
                    >
                      {adminNav.map((item) => (
                        <NavLink
                          key={item.key}
                          item={item}
                          active={currentView === item.key}
                          badgeCount={item.badgeKey ? badgeCount[item.badgeKey] : undefined}
                          onClick={() => {
                            setView(item.key)
                            setSidebarOpen(false)
                          }}
                        />
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            )}
          </nav>

          <div className="p-3 mt-4 space-y-2">
            {/* Profile shortcut */}
            <button
              onClick={() => { setView('profile'); setSidebarOpen(false) }}
              className={cn(
                'w-full flex items-center gap-3 p-2.5 rounded-md border transition-all group',
                currentView === 'profile'
                  ? 'bg-accent/15 border-accent/30 text-accent'
                  : 'border-border/30 bg-card/40 text-muted-foreground hover:text-foreground hover:border-accent/30'
              )}
            >
              <div className={cn(
                'h-8 w-8 rounded-full border flex items-center justify-center font-heading text-sm shrink-0',
                currentView === 'profile' ? 'bg-accent/30 border-accent/50 text-accent' : 'bg-accent/15 border-accent/30 text-accent'
              )}>
                {session?.name?.[0]?.toUpperCase() || '?'}
              </div>
              <div className="flex-1 min-w-0 text-left">
                <p className="text-xs font-medium leading-none truncate group-hover:text-accent transition-colors">{session?.name}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{isAdmin ? 'Администратор' : 'Игрок'}</p>
              </div>
              <User className={cn('h-3.5 w-3.5 shrink-0', currentView === 'profile' ? 'text-accent' : 'text-muted-foreground/60')} />
            </button>

            <div className="rounded-md border border-border/30 bg-card/40 p-3 text-center">
              <p className="text-[10px] text-muted-foreground/60 font-heading tracking-widest uppercase mb-1">
                Версия
              </p>
              <p className="text-xs text-muted-foreground/80">Терский Мир · I эпоха</p>
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 p-4 lg:p-6">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-7xl mx-auto"
          >
            <Suspense fallback={<ViewFallback />}>
              {renderView(currentView, selectedId)}
            </Suspense>
          </motion.div>
        </main>
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/50 bg-card/40 px-6 py-5">
        <div className="max-w-5xl mx-auto">
          <div className="ornament-divider max-w-xs mx-auto opacity-40 mb-4" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {/* Левая колонка — о проекте */}
            <div className="text-center md:text-left">
              <div className="flex items-center gap-2 justify-center md:justify-start mb-1">
                <Logo size={20} />
                <span className="font-heading text-sm font-semibold tracking-wider text-foreground">ТЕРСКИЙ МИР</span>
              </div>
              <p className="text-[10px] text-muted-foreground/70 italic leading-relaxed">
                Ролевая-Военно-Политическая Игра в сеттинге тёмного славянского фэнтези
              </p>
            </div>

            {/* Центральная колонка — цитата */}
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground/60 italic leading-relaxed">
                «Великие княжества рождаются не мечом единым, но словом, золотом и мудростью правителей своих»
              </p>
            </div>

            {/* Правая колонка — шорткаты */}
            <div className="text-center md:text-right">
              <div className="flex items-center gap-2 justify-center md:justify-end mb-1">
                <kbd className="text-[9px]">⌘K</kbd>
                <span className="text-[10px] text-muted-foreground">поиск</span>
                <kbd className="text-[9px]">?</kbd>
                <span className="text-[10px] text-muted-foreground">клавиши</span>
              </div>
              <p className="text-[10px] text-muted-foreground/70">
                {new Date().getFullYear()} · I эпоха
              </p>
            </div>
          </div>
          <div className="border-t border-border/30 pt-3 text-center">
            <p className="text-[10px] text-muted-foreground/50">
              Терский Мир · {new Date().getFullYear()} · С уважением к преданиям и легендам
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function NavLink({ item, active, onClick, badgeCount }: { item: NavItem; active: boolean; onClick: () => void; badgeCount?: number }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-all duration-150 group',
        active
          ? 'bg-accent/15 text-accent border border-accent/30 shadow-sm'
          : 'text-muted-foreground hover:text-foreground hover:bg-muted/40 border border-transparent'
      )}
    >
      <span className={cn(active && 'text-accent', 'shrink-0')}>{item.icon}</span>
      <span className="font-heading tracking-wide text-[13px] flex-1 text-left truncate">{item.label}</span>
      {badgeCount !== undefined && badgeCount > 0 && (
        <span className="h-4 min-w-4 px-1 rounded-full bg-amber-500/90 text-amber-foreground text-[10px] font-bold flex items-center justify-center shrink-0 group-hover:bg-amber-500">
          {badgeCount > 99 ? '99+' : badgeCount}
        </span>
      )}
    </button>
  )
}
