'use client'

import { useState, useRef, useEffect } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion, AnimatePresence } from 'framer-motion'
import { toast as sonnerToast } from 'sonner'
import {
  Bell, Shield, Newspaper, MessageSquare, Clock, CheckCircle2,
  FileText, Coins, X, ChevronRight, Pin,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { useAppStore } from '@/stores/app-store'

interface NotificationItem {
  id: string
  type: 'verdict' | 'news' | 'message' | 'pending_post'
  createdAt: string
  // verdict
  post?: { id: string; title: string }
  author?: { id: string; name: string }
  faction?: { id: string; name: string } | null
  admin?: { id: string; name: string }
  roleplayText?: string
  statChangesCount?: number
  // news
  title?: string
  excerpt?: string | null
  category?: string
  isPinned?: boolean
  // message
  content?: string
  user?: { id: string; name: string }
  chatRoom?: { id: string; name: string }
}

export function NotificationsMenu() {
  const [open, setOpen] = useState(false)
  const [markingRead, setMarkingRead] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const { setView } = useAppStore()
  const queryClient = useQueryClient()

  const { data, isLoading } = useQuery<{ notifications: NotificationItem[]; unreadCount: number }>({
    queryKey: ['notifications'],
    queryFn: async () => (await fetch('/api/notifications')).json(),
    refetchInterval: 60000, // каждую минуту
  })

  const items = data?.notifications || []
  const unreadCount = data?.unreadCount || 0
  const prevUnreadRef = useRef(unreadCount)

  // Toast при увеличении количества непрочитанных
  useEffect(() => {
    const prev = prevUnreadRef.current
    if (unreadCount > prev && unreadCount > 0) {
      const newest = items[0]
      if (newest) {
        const label = newest.type === 'verdict' ? 'Новый вердикт'
          : newest.type === 'pending_post' ? 'Новый пост ожидает'
          : newest.type === 'news' ? 'Новая весть'
          : 'Новое сообщение'
        const title = newest.post?.title || newest.title || (newest.user ? `${newest.user.name} написал` : label)
        sonnerToast(title, {
          description: label,
        })
      }
    }
    prevUnreadRef.current = unreadCount
  }, [unreadCount, items])

  // Закрытие при клике вне
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    if (open) document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [open])

  const handleItemClick = (item: NotificationItem) => {
    setOpen(false)
    if (item.type === 'verdict' && item.post) {
      setView('posts')
    } else if (item.type === 'pending_post') {
      setView('admin-posts')
    } else if (item.type === 'news') {
      setView('news')
    } else if (item.type === 'message' && item.chatRoom) {
      setView('chats')
    }
  }

  const markAllRead = async () => {
    setMarkingRead(true)
    // Помечаем как прочитанные — invalidate queries (сервер считает "новое" как >24ч)
    // Для мгновенной обратной связи — просто инвалидируем кэш (клиент покажет 0 unread)
    queryClient.setQueryData(['notifications'], (old: { notifications: NotificationItem[]; unreadCount: number } | undefined) => {
      if (!old) return old
      return { ...old, unreadCount: 0 }
    })
    setTimeout(() => setMarkingRead(false), 500)
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(!open)}
        className="relative h-9 w-9 rounded-md flex items-center justify-center text-muted-foreground hover:text-accent hover:bg-muted/40 transition-colors"
        aria-label="Уведомления"
      >
        <Bell className="h-4 w-4" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center pulse-accent">
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop для мобильных */}
            <div
              className="fixed inset-0 z-40 md:hidden"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.97 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-11 z-50 w-80 md:w-96 max-w-[calc(100vw-2rem)] rounded-lg border border-border/60 bg-card/95 backdrop-blur-md shadow-2xl overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-3 border-b border-border/40 bg-secondary/20">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-accent" />
                  <h3 className="font-heading text-sm font-semibold text-foreground tracking-wide">Уведомления</h3>
                  {unreadCount > 0 && (
                    <Badge className="bg-accent/20 text-accent border-accent/30 text-[9px]">{unreadCount} новых</Badge>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  {unreadCount > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={markAllRead}
                      disabled={markingRead}
                      className="h-7 text-[10px] text-muted-foreground hover:text-accent"
                    >
                      <CheckCircle2 className="h-3 w-3 mr-1" /> Прочитать
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setOpen(false)}
                    className="h-7 w-7 text-muted-foreground"
                  >
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>

              {/* Items */}
              <div className="max-h-96 overflow-y-auto custom-scroll">
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <div className="h-5 w-5 rounded-full border-2 border-accent/30 border-t-accent animate-spin" />
                  </div>
                ) : items.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center px-4">
                    <Bell className="h-8 w-8 text-muted-foreground/40 mb-2" />
                    <p className="text-sm text-muted-foreground">Уведомлений нет</p>
                    <p className="text-[10px] text-muted-foreground/60 mt-1">Новые события появятся здесь</p>
                  </div>
                ) : (
                  items.map((item) => (
                    <NotificationRow
                      key={`${item.type}-${item.id}`}
                      item={item}
                      onClick={() => handleItemClick(item)}
                    />
                  ))
                )}
              </div>

              {/* Footer */}
              <div className="p-2 border-t border-border/40 bg-secondary/10 text-center">
                <p className="text-[10px] text-muted-foreground/60">
                  Обновляется автоматически каждую минуту
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}

function NotificationRow({ item, onClick }: { item: NotificationItem; onClick: () => void }) {
  const isRecent = Date.now() - new Date(item.createdAt).getTime() < 24 * 60 * 60 * 1000

  const config = {
    verdict: {
      icon: Shield,
      iconColor: 'text-emerald-400',
      iconBg: 'bg-emerald-500/15 border-emerald-500/30',
    },
    pending_post: {
      icon: FileText,
      iconColor: 'text-amber-400',
      iconBg: 'bg-amber-500/15 border-amber-500/30',
    },
    news: {
      icon: Newspaper,
      iconColor: 'text-accent',
      iconBg: 'bg-accent/15 border-accent/30',
    },
    message: {
      icon: MessageSquare,
      iconColor: 'text-teal-300',
      iconBg: 'bg-teal-500/15 border-teal-500/30',
    },
  }[item.type]

  const Icon = config.icon

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full text-left p-3 border-b border-border/20 hover:bg-muted/20 transition-colors flex items-start gap-3 group',
        isRecent && 'bg-accent/5'
      )}
    >
      <div className={cn('h-8 w-8 rounded-md border flex items-center justify-center shrink-0', config.iconBg)}>
        <Icon className={cn('h-3.5 w-3.5', config.iconColor)} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5">
          <span className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground">
            {labelForType(item.type)}
          </span>
          {isRecent && <span className="h-1.5 w-1.5 rounded-full bg-accent shrink-0" />}
          <span className="text-[10px] text-muted-foreground/60 ml-auto">
            {formatRelative(item.createdAt)}
          </span>
        </div>

        {item.type === 'verdict' && (
          <>
            <p className="text-xs font-heading text-foreground group-hover:text-accent transition-colors truncate">
              {item.post?.title}
            </p>
            <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">
              {item.roleplayText}
            </p>
            {item.statChangesCount !== undefined && item.statChangesCount > 0 && (
              <div className="flex items-center gap-1 mt-1">
                <Coins className="h-2.5 w-2.5 text-accent" />
                <span className="text-[10px] text-accent">{item.statChangesCount} секц. статов</span>
              </div>
            )}
          </>
        )}

        {item.type === 'pending_post' && (
          <>
            <p className="text-xs font-heading text-foreground group-hover:text-accent transition-colors truncate">
              {item.title}
            </p>
            <p className="text-[10px] text-muted-foreground mt-0.5">
              От: {item.author?.name} {item.faction ? `· ${item.faction.name}` : ''}
            </p>
          </>
        )}

        {item.type === 'news' && (
          <>
            <p className="text-xs font-heading text-foreground group-hover:text-accent transition-colors truncate flex items-center gap-1">
              {item.isPinned && <Pin className="h-2.5 w-2.5 text-accent shrink-0" />}
              {item.title}
            </p>
            {item.excerpt && (
              <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{item.excerpt}</p>
            )}
          </>
        )}

        {item.type === 'message' && (
          <>
            <p className="text-xs text-foreground">
              <span className="font-heading text-accent">{item.user?.name}</span>
              <span className="text-muted-foreground"> в «{item.chatRoom?.name}»</span>
            </p>
            <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">{item.content}</p>
          </>
        )}
      </div>
      <ChevronRight className="h-3 w-3 text-muted-foreground/40 group-hover:text-accent shrink-0 mt-1" />
    </button>
  )
}

function labelForType(type: string): string {
  return {
    verdict: 'Вердикт',
    pending_post: 'Ожидает',
    news: 'Весть',
    message: 'Сообщение',
  }[type] || type
}

function formatRelative(iso: string): string {
  const d = new Date(iso)
  const diff = Date.now() - d.getTime()
  const mins = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)
  if (mins < 1) return 'сейчас'
  if (mins < 60) return `${mins}м`
  if (hours < 24) return `${hours}ч`
  if (days < 7) return `${days}д`
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })
}
