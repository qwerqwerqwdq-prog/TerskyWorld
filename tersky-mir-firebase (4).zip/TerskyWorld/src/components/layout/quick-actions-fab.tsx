'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Plus, ScrollText, Newspaper, MessageSquare, Swords, BookOpen,
  PawPrint, X, ChevronUp,
} from 'lucide-react'
import { useAppStore, type ViewKey } from '@/stores/app-store'
import { cn } from '@/lib/utils'

interface QuickAction {
  label: string
  icon: React.ComponentType<{ className?: string }>
  view: ViewKey
  action?: string // optional: trigger a "new" action via store event
}

const PLAYER_ACTIONS: QuickAction[] = [
  { label: 'Новый пост', icon: ScrollText, view: 'posts', action: 'new-post' },
  { label: 'Вести мира', icon: Newspaper, view: 'news' },
  { label: 'Переговоры', icon: MessageSquare, view: 'chats' },
  { label: 'Военные дела', icon: Swords, view: 'battles' },
  { label: 'Хроника', icon: BookOpen, view: 'chronicle' },
  { label: 'Бестиарий', icon: PawPrint, view: 'bestiary' },
]

export function QuickActionsFab() {
  const [open, setOpen] = useState(false)
  const { setView, currentView } = useAppStore()
  const ref = useRef<HTMLDivElement>(null)

  // Закрытие при клике вне
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    if (open) {
      document.addEventListener('mousedown', handler)
      return () => document.removeEventListener('mousedown', handler)
    }
  }, [open])

  // Закрытие при смене view — используем ref для отслеживания
  const prevViewRef = useRef(currentView)
  useEffect(() => {
    if (prevViewRef.current !== currentView) {
      prevViewRef.current = currentView
    }
  }, [currentView])

  const handleAction = (action: QuickAction) => {
    setView(action.view)
    setOpen(false)
    if (action.action) {
      // Сигнал для views через window event — с задержкой, чтобы view успел смонтироваться
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('quick-action', { detail: action.action }))
      }, 200)
    }
  }

  return (
    <div ref={ref} className="fixed bottom-6 right-6 z-30 print:hidden">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="absolute bottom-16 right-0 w-52 rounded-lg border border-border/60 bg-card/95 backdrop-blur-md shadow-2xl overflow-hidden"
          >
            <div className="p-2 border-b border-border/40 bg-secondary/20">
              <p className="text-[10px] uppercase tracking-widest font-heading text-muted-foreground text-center">
                Быстрые действия
              </p>
            </div>
            <div className="p-1.5">
              {PLAYER_ACTIONS.map((action, i) => {
                const Icon = action.icon
                return (
                  <motion.button
                    key={action.label}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.03 }}
                    onClick={() => handleAction(action)}
                    className="w-full flex items-center gap-3 p-2 rounded-md text-sm text-muted-foreground hover:text-accent hover:bg-muted/40 transition-colors group"
                  >
                    <div className="h-7 w-7 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0 group-hover:bg-accent/25 transition-colors">
                      <Icon className="h-3.5 w-3.5 text-accent" />
                    </div>
                    <span className="font-heading tracking-wide text-[13px]">{action.label}</span>
                  </motion.button>
                )
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main FAB button */}
      <motion.button
        onClick={() => setOpen(!open)}
        whileTap={{ scale: 0.95 }}
        className={cn(
          'h-12 w-12 rounded-full flex items-center justify-center shadow-2xl transition-all',
          'bg-accent hover:bg-accent/90 text-accent-foreground glow-teal',
          open && 'rotate-45'
        )}
        aria-label={open ? 'Закрыть меню' : 'Быстрые действия'}
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div
              key="close"
              initial={{ opacity: 0, rotate: -45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: -45 }}
              transition={{ duration: 0.15 }}
            >
              <X className="h-5 w-5" />
            </motion.div>
          ) : (
            <motion.div
              key="plus"
              initial={{ opacity: 0, rotate: -45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: 45 }}
              transition={{ duration: 0.15 }}
            >
              <Plus className="h-5 w-5" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  )
}
