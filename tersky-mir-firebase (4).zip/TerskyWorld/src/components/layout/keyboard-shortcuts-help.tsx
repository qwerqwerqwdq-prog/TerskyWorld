'use client'

import { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Command, Search, Bell, Home, ArrowUp, ArrowDown,
  CornerDownLeft, XCircle, X, Shield, ScrollText,
  MessageSquare, Newspaper, Swords, BookOpen, PawPrint, Activity, User, Compass, Bookmark, Trophy, Crown,
} from 'lucide-react'
import { useAppStore } from '@/stores/app-store'

interface ShortcutItem {
  keys: string[]
  description: string
  icon?: React.ComponentType<{ className?: string }>
  action?: () => void
}

interface ShortcutGroup {
  title: string
  shortcuts: ShortcutItem[]
}

interface KeyboardShortcutsHelpProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function KeyboardShortcutsHelp({ open, onOpenChange }: KeyboardShortcutsHelpProps) {
  const { setView } = useAppStore()

  // Слушатель для закрытия по Escape
  useEffect(() => {
    if (!open) return
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault()
        onOpenChange(false)
      }
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [open, onOpenChange])

  // Глобальный слушатель для вызова по «?»
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable
      if (isInput) return
      if (e.key === '?' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault()
        onOpenChange(!open)
      }
    }
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [open, onOpenChange])

  const groups: ShortcutGroup[] = [
    {
      title: 'Навигация',
      shortcuts: [
        { keys: ['G', 'D'], description: 'Сводка (Дашборд)', icon: Home, action: () => setView('dashboard') },
        { keys: ['G', 'F'], description: 'Моё княжество', icon: Shield, action: () => setView('my-faction') },
        { keys: ['G', 'P'], description: 'Мои посты', icon: ScrollText, action: () => setView('posts') },
        { keys: ['G', 'C'], description: 'Переговоры (Чаты)', icon: MessageSquare, action: () => setView('chats') },
        { keys: ['G', 'B'], description: 'Военные дела (Баталии)', icon: Swords, action: () => setView('battles') },
        { keys: ['G', 'N'], description: 'Вести мира (Новости)', icon: Newspaper, action: () => setView('news') },
        { keys: ['G', 'H'], description: 'Хроника', icon: BookOpen, action: () => setView('chronicle') },
        { keys: ['G', 'E'], description: 'Бестиарий', icon: PawPrint, action: () => setView('bestiary') },
        { keys: ['G', 'A'], description: 'Летопись (Активность)', icon: Activity, action: () => setView('activity') },
        { keys: ['G', 'R'], description: 'Профиль', icon: User, action: () => setView('profile') },
        { keys: ['G', 'O'], description: 'Державы мира', icon: Compass, action: () => setView('directory') },
        { keys: ['G', 'M'], description: 'Закладки', icon: Bookmark, action: () => setView('bookmarks') },
        { keys: ['G', 'T'], description: 'Достижения', icon: Trophy, action: () => setView('achievements') },
        { keys: ['G', 'L'], description: 'Зал славы (Leaderboard)', icon: Crown, action: () => setView('leaderboard') },
      ],
    },
    {
      title: 'Действия',
      shortcuts: [
        { keys: ['⌘', 'K'], description: 'Открыть поиск (Command Palette)', icon: Search },
        { keys: ['?'], description: 'Показать подсказки по клавишам', icon: Command },
        { keys: ['N'], description: 'Новая запись (контекстно)', icon: CornerDownLeft },
        { keys: ['Esc'], description: 'Закрыть окно / модал', icon: XCircle },
      ],
    },
    {
      title: 'Command Palette',
      shortcuts: [
        { keys: ['↑'], description: 'Следующий результат', icon: ArrowUp },
        { keys: ['↓'], description: 'Предыдущий результат', icon: ArrowDown },
        { keys: ['⏎'], description: 'Выбрать результат', icon: CornerDownLeft },
      ],
    },
  ]

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-[60] flex items-center justify-center p-4"
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm vignette"
            onClick={() => onOpenChange(false)}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.97 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-2xl rounded-lg border border-border/60 bg-card/95 backdrop-blur-xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-border/40 bg-secondary/20">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center">
                  <Command className="h-4 w-4 text-accent" />
                </div>
                <div>
                  <h2 className="font-heading text-lg font-semibold text-foreground tracking-wide">Горячие клавиши</h2>
                  <p className="text-[10px] text-muted-foreground">Быстрая навигация по Терскому Миру</p>
                </div>
              </div>
              <button
                onClick={() => onOpenChange(false)}
                className="h-8 w-8 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
                aria-label="Закрыть"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Body */}
            <div className="p-4 max-h-[60vh] overflow-y-auto custom-scroll">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {groups.map((group) => (
                  <div key={group.title} className={group.title === 'Навигация' ? 'md:col-span-2' : ''}>
                    <h3 className="text-[10px] uppercase tracking-widest font-heading text-muted-foreground/80 mb-2 flex items-center gap-2">
                      <span className="h-px flex-1 bg-border/40" />
                      {group.title}
                      <span className="h-px flex-1 bg-border/40" />
                    </h3>
                    <div className={`grid gap-1.5 ${group.title === 'Навигация' ? 'grid-cols-1 sm:grid-cols-2' : ''}`}>
                      {group.shortcuts.map((shortcut, i) => {
                        const Icon = shortcut.icon
                        return (
                          <div
                            key={i}
                            className="flex items-center gap-3 p-2 rounded-md hover:bg-muted/20 transition-colors group"
                          >
                            {Icon && <Icon className="h-3.5 w-3.5 text-muted-foreground shrink-0 group-hover:text-accent transition-colors" />}
                            <span className="text-xs text-foreground flex-1 truncate">{shortcut.description}</span>
                            <div className="flex items-center gap-1 shrink-0">
                              {shortcut.keys.map((key, j) => (
                                <kbd key={j}>{key}</kbd>
                              ))}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-border/40 bg-secondary/20 flex items-center justify-between">
              <p className="text-[10px] text-muted-foreground/70 italic">
                Нажмите <kbd className="text-[9px]">?</kbd> в любое время, чтобы открыть эту справку
              </p>
              <button
                onClick={() => onOpenChange(false)}
                className="px-3 py-1 rounded-md bg-accent/15 border border-accent/30 text-accent text-xs font-heading tracking-wide hover:bg-accent/25 transition-colors"
              >
                Понятно
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
