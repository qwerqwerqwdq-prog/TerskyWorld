'use client'

import { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface EmptyStateProps {
  icon?: LucideIcon
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
}

export function EmptyState({ icon: Icon, title, description, action, className }: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center py-16 text-center', className)}>
      {Icon && (
        <div className="mb-4 h-16 w-16 rounded-full bg-muted/30 border border-border/40 flex items-center justify-center">
          <Icon className="h-8 w-8 text-muted-foreground/60" />
        </div>
      )}
      <h3 className="font-heading text-lg text-foreground mb-1">{title}</h3>
      {description && <p className="text-sm text-muted-foreground max-w-sm">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

interface SectionTitleProps {
  title: string
  subtitle?: string
  icon?: LucideIcon
  action?: React.ReactNode
  className?: string
}

export function SectionTitle({ title, subtitle, icon: Icon, action, className }: SectionTitleProps) {
  return (
    <div className={cn('flex items-start justify-between gap-4 mb-4', className)}>
      <div className="flex items-center gap-3">
        {Icon && (
          <div className="h-9 w-9 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
            <Icon className="h-4 w-4 text-accent" />
          </div>
        )}
        <div>
          <h2 className="font-heading text-xl font-semibold text-foreground tracking-wide leading-tight">{title}</h2>
          {subtitle && <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  )
}

interface StatBadgeProps {
  label: string
  value: string | number
  trend?: 'up' | 'down' | 'neutral'
  className?: string
}

export function StatBadge({ label, value, trend = 'neutral', className }: StatBadgeProps) {
  const trendColor = trend === 'up' ? 'text-emerald-400' : trend === 'down' ? 'text-red-400' : 'text-foreground'
  return (
    <div className={cn('rounded-md border border-border/40 bg-card/40 p-3', className)}>
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">{label}</p>
      <p className={cn('font-heading text-lg font-semibold', trendColor)}>{value}</p>
    </div>
  )
}

interface PageHeaderProps {
  title: string
  description?: string
  action?: React.ReactNode
}

export function PageHeader({ title, description, action }: PageHeaderProps) {
  return (
    <div className="mb-6 pb-4 border-b border-border/40">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl lg:text-3xl font-bold text-foreground text-glow tracking-wider">
            {title}
          </h1>
          {description && <p className="text-sm text-muted-foreground mt-1.5">{description}</p>}
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </div>
      <div className="ornament-divider mt-4 opacity-30" />
    </div>
  )
}
