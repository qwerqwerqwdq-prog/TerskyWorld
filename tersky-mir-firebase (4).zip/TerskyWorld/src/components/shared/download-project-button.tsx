'use client'

import { useState } from 'react'
import { Download, Loader2, X, FileArchive, FolderDown } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from '@/components/ui/dialog'

/**
 * Кнопка скачивания исходного кода проекта.
 * Открывает модальное окно с инструкциями и прямой ссылкой на /TerskyWorld.zip
 */
export function DownloadProjectButton() {
  const [open, setOpen] = useState(false)
  const [downloading, setDownloading] = useState(false)

  const handleDownload = async () => {
    setDownloading(true)
    try {
      // Прямая ссылка на статический файл из public/
      const link = document.createElement('a')
      link.href = '/TerskyWorld.zip'
      link.download = 'TerskyWorld.zip'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (e) {
      console.error('Download error:', e)
    } finally {
      // Даём браузеру время начать загрузку
      setTimeout(() => setDownloading(false), 1500)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          className="group fixed bottom-4 right-4 z-50 flex items-center gap-2 rounded-full border border-amber-500/40 bg-amber-500/10 px-4 py-2 text-xs font-medium text-amber-300 backdrop-blur-md transition-all hover:bg-amber-500/20 hover:border-amber-500/60 hover:text-amber-200 shadow-lg shadow-amber-500/10"
          aria-label="Скачать проект"
          title="Скачать исходный код проекта"
        >
          <FileArchive className="h-4 w-4 transition-transform group-hover:scale-110" />
          <span className="hidden sm:inline">Скачать проект</span>
        </button>
      </DialogTrigger>

      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-300">
            <FolderDown className="h-5 w-5" />
            Скачать проект «Терский Мир»
          </DialogTitle>
          <DialogDescription>
            Полный исходный код проекта в ZIP-архиве (~516 КБ). Готов к запуску локально на Windows.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-4">
            <h4 className="mb-2 text-sm font-semibold text-amber-200">
              Что внутри архива
            </h4>
            <ul className="space-y-1 text-xs text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-0.5">▸</span>
                <span>Полный исходный код Next.js 16 + TypeScript</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-0.5">▸</span>
                <span>Prisma-схема (22 модели, SQLite)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-0.5">▸</span>
                <span>shadcn/ui компоненты + все 22 экрана приложения</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-0.5">▸</span>
                <span>Файл <code className="text-amber-300">README.md</code> с инструкциями по установке</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-400 mt-0.5">▸</span>
                <span>Готовый <code className="text-amber-300">.env</code> с относительными путями</span>
              </li>
            </ul>
          </div>

          <div className="rounded-lg border border-border bg-muted/30 p-4">
            <h4 className="mb-2 text-sm font-semibold">
              Быстрый старт (Windows)
            </h4>
            <ol className="space-y-1.5 text-xs text-muted-foreground">
              <li>
                <span className="font-mono text-amber-400">1.</span> Распакуйте архив в{' '}
                <code className="rounded bg-muted px-1.5 py-0.5 text-amber-300">C:\TerskyWorld</code>
              </li>
              <li>
                <span className="font-mono text-amber-400">2.</span> Установите{' '}
                <a
                  href="https://bun.sh"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline"
                >
                  Bun
                </a>{' '}
                и Node.js 20+
              </li>
              <li>
                <span className="font-mono text-amber-400">3.</span>{' '}
                <code className="rounded bg-muted px-1.5 py-0.5 text-amber-300">cd C:\TerskyWorld</code>{' '}
                и{' '}
                <code className="rounded bg-muted px-1.5 py-0.5 text-amber-300">bun install</code>
              </li>
              <li>
                <span className="font-mono text-amber-400">4.</span>{' '}
                <code className="rounded bg-muted px-1.5 py-0.5 text-amber-300">bunx prisma db push</code>
              </li>
              <li>
                <span className="font-mono text-amber-400">5.</span>{' '}
                <code className="rounded bg-muted px-1.5 py-0.5 text-amber-300">bun run dev</code> → http://localhost:3000
              </li>
            </ol>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setOpen(false)}
            >
              <X className="h-4 w-4 mr-1" />
              Закрыть
            </Button>
            <Button
              size="sm"
              onClick={handleDownload}
              disabled={downloading}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {downloading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Загрузка...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Скачать TerskyWorld.zip
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
