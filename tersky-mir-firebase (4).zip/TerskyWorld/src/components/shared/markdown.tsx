'use client'

import ReactMarkdown from 'react-markdown'
import { cn } from '@/lib/utils'

interface MarkdownProps {
  content: string
  className?: string
}

// Рендер Markdown с темизацией под тёмное фэнтези
export function Markdown({ content, className }: MarkdownProps) {
  return (
    <div
      className={cn(
        'prose prose-invert max-w-none prose-headings:font-heading prose-headings:text-foreground prose-headings:tracking-wide prose-p:text-foreground/90 prose-strong:text-accent prose-em:text-accent/80 prose-a:text-accent hover:prose-a:text-accent/80 prose-blockquote:border-l-accent prose-blockquote:text-muted-foreground prose-li:text-foreground/90 prose-code:text-accent prose-code:bg-muted/40 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:before:content-none prose-code:after:content-none prose-hr:border-border/40',
        '[&_*]:!no-underline',
        className
      )}
    >
      <ReactMarkdown
        components={{
          h1: ({ children }) => <h1 className="text-2xl font-bold text-glow mt-6 mb-3">{children}</h1>,
          h2: ({ children }) => <h2 className="text-xl font-semibold mt-5 mb-2 text-foreground">{children}</h2>,
          h3: ({ children }) => <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">{children}</h3>,
          p: ({ children }) => <p className="leading-relaxed mb-3 text-foreground/90">{children}</p>,
          ul: ({ children }) => <ul className="list-disc list-inside space-y-1 mb-3 text-foreground/90">{children}</ul>,
          ol: ({ children }) => <ol className="list-decimal list-inside space-y-1 mb-3 text-foreground/90">{children}</ol>,
          blockquote: ({ children }) => (
            <blockquote className="border-l-2 border-accent/60 pl-4 italic text-muted-foreground my-3">
              {children}
            </blockquote>
          ),
          code: ({ children, className }) => {
            const isInline = !className?.includes('language-')
            return isInline ? (
              <code className="bg-muted/40 text-accent px-1.5 py-0.5 rounded text-sm">{children}</code>
            ) : (
              <code className="block bg-muted/30 text-foreground p-3 rounded-md overflow-x-auto text-sm">{children}</code>
            )
          },
          a: ({ children, href }) => (
            <a href={href} target="_blank" rel="noopener noreferrer" className="text-accent hover:text-accent/80 underline">
              {children}
            </a>
          ),
          // Рендер картинок — без opacity, без prose interference
          img: ({ src, alt }) => (
            <span className="block my-3" style={{ opacity: 1 }}>
              <img
                src={typeof src === 'string' ? src : ''}
                alt={alt || ''}
                className="rounded-lg border border-border/40 max-w-full h-auto shadow-lg"
                style={{ display: 'block', opacity: 1 }}
                loading="lazy"
              />
              {alt && (
                <span className="block text-center text-xs text-muted-foreground italic mt-1.5">{alt}</span>
              )}
            </span>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  )
}
