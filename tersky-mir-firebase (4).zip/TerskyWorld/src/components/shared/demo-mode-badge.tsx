'use client'

import { useAuth } from '@/lib/auth-context'
import { Database, RefreshCw } from 'lucide-react'
import { useState } from 'react'

export function DemoModeBadge() {
  const { isDemoMode } = useAuth()
  const [confirming, setConfirming] = useState(false)

  if (!isDemoMode) return null

  const handleReset = () => {
    if (!confirming) {
      setConfirming(true)
      setTimeout(() => setConfirming(false), 3000)
      return
    }
    if (typeof window !== 'undefined') {
      localStorage.removeItem('tersky-mir-demo:v1')
      window.location.reload()
    }
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs backdrop-blur-md shadow-lg">
      <Database className="h-3.5 w-3.5" />
      <span className="font-heading tracking-wide">Demo режим</span>
      <span className="text-amber-200/60">·</span>
      <span className="text-amber-200/80">данные в браузере</span>
      <button
        onClick={handleReset}
        className="ml-1 p-1 rounded hover:bg-amber-500/30 transition-colors"
        title={confirming ? 'Нажмите ещё раз чтобы сбросить все данные' : 'Сбросить demo-данные'}
      >
        <RefreshCw className={`h-3 w-3 ${confirming ? 'animate-spin' : ''}`} />
      </button>
    </div>
  )
}
