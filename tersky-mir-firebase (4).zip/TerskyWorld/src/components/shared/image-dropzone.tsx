'use client'

import { useState, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Upload, Image as ImageIcon, X, Loader2, FileText, Paperclip } from 'lucide-react'
import { cn } from '@/lib/utils'

export interface UploadedFile {
  filePath: string
  fileName: string
  fileType: string
  isImage: boolean
  markdown: string
}

interface ImageDropzoneProps {
  onUpload: (files: UploadedFile[]) => void
  multiple?: boolean
  className?: string
  compact?: boolean
  label?: string
}

// Компонент для загрузки файлов: drag-and-drop, paste из буфера, клик
export function ImageDropzone({
  onUpload,
  multiple = true,
  className,
  compact = false,
  label = 'Перетащите файлы, вставьте из буфера или нажмите для выбора',
}: ImageDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const dragCounter = useRef(0)

  const handleFiles = useCallback(async (fileList: FileList | File[]) => {
    const files = Array.from(fileList)
    if (files.length === 0) return

    setUploading(true)
    const uploaded: UploadedFile[] = []

    for (const file of files) {
      try {
        const fd = new FormData()
        fd.append('file', file)
        const res = await fetch('/api/upload', { method: 'POST', body: fd })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        uploaded.push({
          filePath: data.filePath,
          fileName: data.fileName,
          fileType: data.fileType,
          isImage: data.isImage,
          markdown: data.markdown,
        })
      } catch (e) {
        console.error('Upload error:', e)
      }
    }

    if (uploaded.length > 0) {
      onUpload(uploaded)
    }
    setUploading(false)
  }, [onUpload])

  // Drag and Drop
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current++
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragging(true)
    }
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current--
    if (dragCounter.current === 0) {
      setIsDragging(false)
    }
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current = 0
    setIsDragging(false)
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files)
    }
  }, [handleFiles])

  // Click to select
  const handleClick = useCallback(() => {
    inputRef.current?.click()
  }, [])

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files)
      e.target.value = '' // reset для повторной загрузки того же файла
    }
  }, [handleFiles])

  if (compact) {
    return (
      <>
        <input
          ref={inputRef}
          type="file"
          className="hidden"
          multiple={multiple}
          accept="image/*,.pdf,.doc,.docx,.txt,.csv"
          onChange={handleInputChange}
        />
        <button
          type="button"
          onClick={handleClick}
          disabled={uploading}
          className={cn(
            'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-dashed text-xs transition-all',
            'border-border/50 text-muted-foreground hover:text-accent hover:border-accent/40',
            uploading && 'opacity-50',
            className
          )}
          title={label}
        >
          {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ImageIcon className="h-3.5 w-3.5" />}
          {uploading ? 'Загрузка...' : 'Картинка'}
        </button>
      </>
    )
  }

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={handleClick}
      className={cn(
        'relative rounded-lg border-2 border-dashed p-6 text-center cursor-pointer transition-all',
        isDragging
          ? 'border-accent bg-accent/10 scale-[1.02]'
          : 'border-border/50 hover:border-accent/40 hover:bg-muted/20',
        uploading && 'opacity-60 pointer-events-none',
        className
      )}
    >
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        multiple={multiple}
        accept="image/*,.pdf,.doc,.docx,.txt,.csv"
        onChange={handleInputChange}
      />

      <AnimatePresence mode="wait">
        {uploading ? (
          <motion.div
            key="uploading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-2"
          >
            <Loader2 className="h-8 w-8 animate-spin text-accent" />
            <p className="text-xs text-muted-foreground">Загрузка...</p>
          </motion.div>
        ) : isDragging ? (
          <motion.div
            key="dragging"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center gap-2"
          >
            <Upload className="h-8 w-8 text-accent" />
            <p className="text-sm font-heading text-accent">Отпустите для загрузки</p>
          </motion.div>
        ) : (
          <motion.div
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-2"
          >
            <div className="h-12 w-12 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center">
              <ImageIcon className="h-6 w-6 text-accent" />
            </div>
            <p className="text-sm text-foreground font-heading">{label}</p>
            <p className="text-[10px] text-muted-foreground/60">PNG, JPG, GIF, WEBP, PDF — до 10MB</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// Хук для paste из буфера обмена в textarea/input
export function usePasteUpload(
  onUpload: (files: UploadedFile[]) => void,
  options?: { insertMarkdown?: (markdown: string) => void }
) {
  const handlePaste = useCallback((e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items
    if (!items) return

    const imageFiles: File[] = []
    for (let i = 0; i < items.length; i++) {
      const item = items[i]
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile()
        if (file) imageFiles.push(file)
      }
    }

    if (imageFiles.length > 0) {
      e.preventDefault()
      // Загружаем файлы
      const uploadFiles = async () => {
        const uploaded: UploadedFile[] = []
        for (const file of imageFiles) {
          try {
            const fd = new FormData()
            fd.append('file', file)
            const res = await fetch('/api/upload', { method: 'POST', body: fd })
            const data = await res.json()
            if (!res.ok) throw new Error(data.error)
            uploaded.push({
              filePath: data.filePath,
              fileName: data.fileName || `pasted-${Date.now()}.png`,
              fileType: data.fileType,
              isImage: data.isImage,
              markdown: data.markdown,
            })
          } catch (e) {
            console.error('Paste upload error:', e)
          }
        }
        if (uploaded.length > 0) {
          onUpload(uploaded)
          if (options?.insertMarkdown) {
            const markdown = uploaded.map((f) => f.markdown).join('\n\n')
            options.insertMarkdown(markdown)
          }
        }
      }
      uploadFiles()
    }
  }, [onUpload, options?.insertMarkdown])

  return handlePaste
}
