'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Bookmark, BookmarkCheck, Loader2 } from 'lucide-react'
import { motion } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

interface BookmarkButtonProps {
  type: 'post' | 'news'
  entityId: string
  variant?: 'icon' | 'badge'
  className?: string
}

interface BookmarkCheckResponse {
  bookmarks: Array<{ type: string; entityId: string }>
}

export function BookmarkButton({ type, entityId, variant = 'icon', className }: BookmarkButtonProps) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [loading, setLoading] = useState(false)

  const { data } = useQuery<BookmarkCheckResponse>({
    queryKey: ['bookmarks'],
    queryFn: async () => (await fetch('/api/bookmarks')).json(),
  })

  const isBookmarked = data?.bookmarks?.some((b) => b.type === type && b.entityId === entityId) ?? false

  const handleClick = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (loading) return
    setLoading(true)
    try {
      if (isBookmarked) {
        const res = await fetch(`/api/bookmarks?type=${type}&entityId=${entityId}`, { method: 'DELETE' })
        if (!res.ok) throw new Error('Ошибка')
        toast({ title: 'Удалено из закладок' })
      } else {
        const res = await fetch('/api/bookmarks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type, entityId }),
        })
        if (!res.ok) {
          const d = await res.json()
          throw new Error(d.error || 'Ошибка')
        }
        toast({ title: 'Добавлено в закладки' })
      }
      queryClient.invalidateQueries({ queryKey: ['bookmarks'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  if (variant === 'badge') {
    return (
      <button
        onClick={handleClick}
        disabled={loading}
        className={cn(
          'inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] border transition-all',
          isBookmarked
            ? 'bg-accent/20 text-accent border-accent/30 hover:bg-accent/30'
            : 'bg-muted/20 text-muted-foreground border-border/40 hover:border-accent/30 hover:text-accent',
          className
        )}
        aria-label={isBookmarked ? 'Убрать из закладок' : 'Добавить в закладки'}
        title={isBookmarked ? 'В закладках' : 'Добавить в закладки'}
      >
        {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : isBookmarked ? <BookmarkCheck className="h-3 w-3" /> : <Bookmark className="h-3 w-3" />}
        <span>{isBookmarked ? 'В закладках' : 'Сохранить'}</span>
      </button>
    )
  }

  return (
    <motion.button
      onClick={handleClick}
      disabled={loading}
      whileTap={{ scale: 0.9 }}
      className={cn(
        'h-8 w-8 rounded-md flex items-center justify-center transition-all',
        isBookmarked
          ? 'text-accent bg-accent/15 hover:bg-accent/25'
          : 'text-muted-foreground hover:text-accent hover:bg-muted/40',
        className
      )}
      aria-label={isBookmarked ? 'Убрать из закладок' : 'Добавить в закладки'}
      title={isBookmarked ? 'В закладках' : 'Добавить в закладки'}
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : isBookmarked ? <BookmarkCheck className="h-3.5 w-3.5" /> : <Bookmark className="h-3.5 w-3.5" />}
    </motion.button>
  )
}
