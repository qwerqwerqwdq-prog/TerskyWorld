'use client'

import { useState, useEffect, useRef } from 'react'

// Хук для count-up анимации числа
export function useCountUp(target: number, duration: number = 1000): number {
  const [current, setCurrent] = useState(0)
  const rafRef = useRef<number | null>(null)
  const targetRef = useRef(target)
  const startTimeRef = useRef<number | null>(null)

  useEffect(() => {
    // Если значение 0 или не изменилось — не анимируем
    if (target === targetRef.current && current === target) return
    targetRef.current = target
    startTimeRef.current = null

    // Если target = 0, сразу ставим 0 без анимации
    if (target === 0) {
      // Use a microtask to avoid cascading render
      Promise.resolve().then(() => setCurrent(0))
      return
    }

    let cancelled = false

    const animate = (timestamp: number) => {
      if (cancelled) return
      if (startTimeRef.current === null) {
        startTimeRef.current = timestamp
      }
      const elapsed = timestamp - startTimeRef.current
      const progress = Math.min(elapsed / duration, 1)

      // Easing: easeOutCubic
      const eased = 1 - Math.pow(1 - progress, 3)
      const value = Math.round(targetRef.current * eased)
      setCurrent(value)

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate)
      }
    }

    rafRef.current = requestAnimationFrame(animate)

    return () => {
      cancelled = true
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [target, duration])

  return current
}

// Компонент для отображения числа с count-up анимацией
export function CountUp({
  value,
  duration = 1000,
  format = true,
  className,
}: {
  value: number
  duration?: number
  format?: boolean
  className?: string
}) {
  const current = useCountUp(value, duration)
  const display = format ? current.toLocaleString('ru-RU') : String(current)
  return <span className={className}>{display}</span>
}
