'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Flag, Loader2, Shield, CheckCircle2, Clock, Trash2, ChevronRight } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { useAppStore } from '@/stores/app-store'

interface Faction {
  id: string
  name: string
  shortName?: string | null
  motto?: string | null
  isApproved: boolean
  createdAt: string
  user: { id: string; name: string; email: string }
}

export function AdminFactionsView() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const { setView } = useAppStore()
  const { data, isLoading } = useQuery<{ factions: Faction[] }>({
    queryKey: ['admin-factions'],
    queryFn: async () => (await fetch('/api/factions')).json(),
  })

  const factions = data?.factions || []

  const toggleApproval = async (faction: Faction) => {
    try {
      const res = await fetch(`/api/factions/${faction.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      })
      // Одобрение делаем через отдельный эндпоинт или флагом
      // Для простоты — обновим через stats endpoint, но правильнее добавить поле isApproved в update
      toast({ title: 'Используйте детали фракции для редактирования статистики' })
      queryClient.invalidateQueries({ queryKey: ['admin-factions'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const handleApprove = async (faction: Faction) => {
    try {
      // Обновляем через stats endpoint — создаём/обновляем секции
      const res = await fetch(`/api/factions/${faction.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isApproved: true }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Княжество утверждено', description: faction.name })
      queryClient.invalidateQueries({ queryKey: ['admin-factions'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const handleDelete = async (faction: Faction) => {
    if (!confirm(`Удалить княжество «${faction.name}»?`)) return
    try {
      const res = await fetch(`/api/factions/${faction.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка удаления')
      toast({ title: 'Княжество удалено' })
      queryClient.invalidateQueries({ queryKey: ['admin-factions'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader title="Управление фракциями" description="Утверждение и редактирование княжеств игроков" />

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : factions.length === 0 ? (
        <EmptyState icon={Flag} title="Фракций нет" description="Игроки ещё не зарегистрировали княжества. Когда правители создадут свои государства, они появятся здесь для утверждения." />
      ) : (
        <div className="space-y-3">
          {factions.map((faction) => (
            <Card key={faction.id} className="border-border/40 bg-card/40 p-4">
              <div className="flex items-start gap-4">
                <div className="h-11 w-11 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
                  <Shield className="h-5 w-5 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-heading text-sm text-foreground">{faction.name}</h3>
                    {faction.isApproved ? (
                      <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 gap-1 text-[10px]">
                        <CheckCircle2 className="h-3 w-3" /> Утверждено
                      </Badge>
                    ) : (
                      <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 gap-1 text-[10px]">
                        <Clock className="h-3 w-3" /> На утверждении
                      </Badge>
                    )}
                  </div>
                  {faction.shortName && <p className="text-xs text-muted-foreground mt-0.5">Короткое: {faction.shortName}</p>}
                  {faction.motto && <p className="text-xs italic text-accent/70 mt-1">«{faction.motto}»</p>}
                  <p className="text-[10px] text-muted-foreground/70 mt-1">
                    Правитель: {faction.user.name} · {faction.user.email}
                  </p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {!faction.isApproved && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleApprove(faction)}
                      className="h-8 text-xs border-accent/40 text-accent hover:bg-accent/10"
                    >
                      Утвердить
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setView('my-faction', faction.id)}
                    className="h-8 text-xs"
                  >
                    Статистика <ChevronRight className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(faction)}
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
