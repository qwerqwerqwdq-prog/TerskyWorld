'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Users, Loader2, Search, Shield, Trash2, Crown, Clock, Mail,
  Ban, ShieldCheck, ShieldOff, AlertTriangle,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogFooter, DialogDescription,
} from '@/components/ui/dialog'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { cn } from '@/lib/utils'

interface User {
  id: string
  name: string
  email: string
  role: string
  avatar?: string | null
  isBanned: boolean
  bannedAt?: string | null
  bannedReason?: string | null
  createdAt: string
  lastLoginAt?: string | null
  faction?: { id: string; name: string; isApproved: boolean } | null
  _count: { posts: number }
}

export function AdminUsersView() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [search, setSearch] = useState('')
  const [banTarget, setBanTarget] = useState<User | null>(null)
  const [banReason, setBanReason] = useState('')

  const { data, isLoading } = useQuery<{ users: User[] }>({
    queryKey: ['admin-users', search],
    queryFn: async () => {
      const url = search ? `/api/admin/users?search=${encodeURIComponent(search)}` : '/api/admin/users'
      return (await fetch(url)).json()
    },
  })

  const users = data?.users || []

  const toggleRole = async (user: User) => {
    const newRole = user.role === 'ADMIN' ? 'PLAYER' : 'ADMIN'
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Роль обновлена', description: `${user.name} — ${newRole === 'ADMIN' ? 'Администратор' : 'Игрок'}` })
      queryClient.invalidateQueries({ queryKey: ['admin-users'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const handleBan = async () => {
    if (!banTarget) return
    try {
      const res = await fetch(`/api/admin/users/${banTarget.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason: banReason || undefined }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Пользователь заблокирован', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-users'] })
      setBanTarget(null)
      setBanReason('')
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const handleUnban = async (user: User) => {
    try {
      const res = await fetch(`/api/admin/users/${user.id}?action=unban`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Пользователь разблокирован', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-users'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const handleDelete = async (user: User) => {
    if (!confirm(`Удалить пользователя ${user.name}? Это действие необратимо. Все данные будут потеряны.`)) return
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Пользователь удалён', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-users'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const bannedCount = users.filter((u) => u.isBanned).length

  return (
    <div className="space-y-5">
      <PageHeader title="Управление игроками" description="Просмотр, бан и удаление пользователей системы" />

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="border-border/40 bg-card/30 p-3 flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
            <Users className="h-4 w-4 text-accent" />
          </div>
          <div>
            <p className="font-heading text-lg font-bold text-foreground leading-none">{users.length}</p>
            <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Всего</p>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/30 p-3 flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
          </div>
          <div>
            <p className="font-heading text-lg font-bold text-foreground leading-none">{users.length - bannedCount}</p>
            <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Активных</p>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/30 p-3 flex items-center gap-2">
          <div className="h-8 w-8 rounded-md bg-red-500/15 border border-red-500/30 flex items-center justify-center shrink-0">
            <Ban className="h-4 w-4 text-red-400" />
          </div>
          <div>
            <p className="font-heading text-lg font-bold text-foreground leading-none">{bannedCount}</p>
            <p className="text-[9px] text-muted-foreground uppercase tracking-wider">Забанено</p>
          </div>
        </Card>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Поиск по имени или email..."
          className="pl-9 bg-background/60"
        />
      </div>

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : users.length === 0 ? (
        <EmptyState icon={Users} title="Пользователей нет" description="Зарегистрированных пользователей не найдено." />
      ) : (
        <div className="space-y-2">
          {users.map((user) => (
            <Card key={user.id} className={cn(
              'border bg-card/40 p-4 flex items-center gap-4 transition-colors',
              user.isBanned ? 'border-red-500/30 bg-red-500/5' : 'border-border/40'
            )}>
              <div className={cn(
                'h-10 w-10 rounded-full border flex items-center justify-center font-heading shrink-0',
                user.isBanned
                  ? 'bg-red-500/15 border-red-500/30 text-red-400'
                  : 'bg-accent/20 border-accent/40 text-accent'
              )}>
                {user.isBanned ? <Ban className="h-4 w-4" /> : user.name[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className={cn(
                    'font-heading text-sm truncate',
                    user.isBanned ? 'text-red-300' : 'text-foreground'
                  )}>{user.name}</h3>
                  {user.role === 'ADMIN' && (
                    <Badge className="bg-accent/20 text-accent border-accent/30 gap-1 text-[10px]">
                      <Crown className="h-3 w-3" /> Админ
                    </Badge>
                  )}
                  {user.isBanned && (
                    <Badge className="bg-red-500/20 text-red-300 border-red-500/30 gap-1 text-[10px]">
                      <Ban className="h-3 w-3" /> Заблокирован
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 mt-0.5 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {user.email}</span>
                  {user.lastLoginAt && (
                    <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {new Date(user.lastLoginAt).toLocaleDateString('ru-RU')}</span>
                  )}
                </div>
                {user.isBanned && user.bannedReason && (
                  <div className="flex items-center gap-1.5 mt-1 text-[10px] text-red-300/80">
                    <AlertTriangle className="h-3 w-3" />
                    <span className="italic">Причина: {user.bannedReason}</span>
                    {user.bannedAt && (
                      <span className="text-red-300/50">· {new Date(user.bannedAt).toLocaleDateString('ru-RU')}</span>
                    )}
                  </div>
                )}
                {user.faction && (
                  <div className="flex items-center gap-1.5 mt-1 text-[10px]">
                    <Shield className="h-3 w-3 text-accent" />
                    <span className="text-muted-foreground">{user.faction.name}</span>
                    {user.faction.isApproved ? (
                      <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[9px]">Утверждено</Badge>
                    ) : (
                      <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 text-[9px]">На утверждении</Badge>
                    )}
                  </div>
                )}
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {!user.isBanned && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleRole(user)}
                      className="h-8 text-xs"
                    >
                      {user.role === 'ADMIN' ? 'Снять админа' : 'Сделать админом'}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setBanTarget(user)}
                      className="h-8 w-8 text-muted-foreground hover:text-amber-400"
                      title="Заблокировать"
                    >
                      <Ban className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(user)}
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      title="Удалить"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </>
                )}
                {user.isBanned && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleUnban(user)}
                    className="h-8 text-xs text-emerald-400 hover:text-emerald-300"
                    title="Разблокировать"
                  >
                    <ShieldOff className="h-3.5 w-3.5 mr-1" />
                    Разбанить
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Ban Dialog */}
      <Dialog open={!!banTarget} onOpenChange={(v) => { if (!v) { setBanTarget(null); setBanReason('') } }}>
        <DialogContent className="bg-card border-border/60">
          <DialogHeader>
            <DialogTitle className="font-heading text-lg text-foreground flex items-center gap-2">
              <Ban className="h-5 w-5 text-red-400" />
              Блокировка пользователя
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Заблокировать «{banTarget?.name}»? Пользователь не сможет войти в систему.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-2">
              <Label className="text-muted-foreground text-xs uppercase tracking-wider">
                Причина блокировки (опционально)
              </Label>
              <Textarea
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                placeholder="Укажите причину бана (видна только администраторам)..."
                className="bg-background/60 min-h-[80px]"
                maxLength={500}
              />
              <p className="text-[10px] text-muted-foreground/60">{banReason.length}/500 символов</p>
            </div>
            <div className="p-3 rounded-md bg-red-500/10 border border-red-500/30 flex gap-2">
              <AlertTriangle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
              <div className="text-xs text-red-200/80">
                <p className="font-heading mb-0.5">Последствия блокировки:</p>
                <ul className="list-disc list-inside space-y-0.5">
                  <li>Пользователь не сможет войти в систему</li>
                  <li>При попытке входа увидит причину бана</li>
                  <li>Аккаунт и данные сохраняются (можно разбанить)</li>
                </ul>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setBanTarget(null); setBanReason('') }}>
              Отмена
            </Button>
            <Button onClick={handleBan} className="bg-red-600 hover:bg-red-700 text-white">
              <Ban className="h-4 w-4 mr-1.5" />
              Заблокировать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
