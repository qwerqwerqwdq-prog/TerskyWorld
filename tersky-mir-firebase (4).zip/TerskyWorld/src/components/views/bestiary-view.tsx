'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { PawPrint, ChevronRight, Loader2, Skull, MapPin, AlertTriangle } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { IconGridSkeleton } from '@/components/shared/skeletons'
import { Markdown } from '@/components/shared/markdown'
import { BESTIARY_CATEGORIES } from '@/lib/constants'

interface Entry {
  id: string
  name: string
  title?: string | null
  content: string
  category: string
  danger?: string | null
  habitat?: string | null
  imageUrl?: string | null
  order: number
  createdAt: string
  author: { name: string }
}

export function BestiaryView() {
  const [selected, setSelected] = useState<Entry | null>(null)
  const [filter, setFilter] = useState('ALL')

  const { data, isLoading } = useQuery<{ entries: Entry[] }>({
    queryKey: ['bestiary'],
    queryFn: async () => (await fetch('/api/bestiary')).json(),
  })

  const entries = data?.entries || []
  const filtered = filter === 'ALL' ? entries : entries.filter((e) => e.category === filter)

  if (selected) {
    return (
      <div className="space-y-4">
        <button onClick={() => setSelected(null)} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
          <ChevronRight className="h-3 w-3 rotate-180" /> Назад к бестиарию
        </button>
        <Card className="ornate-border bg-card/40 border-border/40 p-6">
          <div className="flex items-start gap-4 mb-4">
            {selected.imageUrl ? (
              <img src={selected.imageUrl} alt={selected.name} className="h-20 w-20 rounded-md object-cover border border-border/40" />
            ) : (
              <div className="h-20 w-20 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center">
                <PawPrint className="h-8 w-8 text-accent" />
              </div>
            )}
            <div className="flex-1">
              <h1 className="font-heading text-2xl font-bold text-foreground text-glow">{selected.name}</h1>
              {selected.title && <p className="text-sm text-muted-foreground italic">{selected.title}</p>}
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">
                  {BESTIARY_CATEGORIES[selected.category] || selected.category}
                </Badge>
                {selected.danger && (
                  <Badge variant="outline" className="text-[10px] border-red-500/30 text-red-300 gap-1">
                    <Skull className="h-3 w-3" /> {selected.danger}
                  </Badge>
                )}
                {selected.habitat && (
                  <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground gap-1">
                    <MapPin className="h-3 w-3" /> {selected.habitat}
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <div className="ornament-divider opacity-30 mb-4" />
          <Markdown content={selected.content} />
          <div className="mt-4 pt-3 border-t border-border/30 text-xs text-muted-foreground">
            Записал: {selected.author.name}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <PageHeader title="Бестиарий" description="Существа, фракции и места Терского Мира" />

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setFilter('ALL')}
          className={`px-3 py-1.5 rounded-md text-xs font-heading tracking-wide border transition-colors ${
            filter === 'ALL' ? 'bg-accent text-accent-foreground border-accent' : 'border-border/40 text-muted-foreground hover:text-foreground'
          }`}
        >
          Все
        </button>
        {Object.entries(BESTIARY_CATEGORIES).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setFilter(key)}
            className={`px-3 py-1.5 rounded-md text-xs font-heading tracking-wide border transition-colors ${
              filter === key ? 'bg-accent text-accent-foreground border-accent' : 'border-border/40 text-muted-foreground hover:text-foreground'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <IconGridSkeleton count={4} />
      ) : filtered.length === 0 ? (
        <EmptyState icon={PawPrint} title="Бестиарий пуст" description="Записи о существах, фракциях, персонах и местах ещё не добавлены. Мудрецы собирают предания о тварях и обителях Терского Мира." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((e) => (
            <Card
              key={e.id}
              onClick={() => setSelected(e)}
              className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group flex items-start gap-3"
            >
              {e.imageUrl ? (
                <img src={e.imageUrl} alt={e.name} className="h-14 w-14 rounded-md object-cover border border-border/40 shrink-0" />
              ) : (
                <div className="h-14 w-14 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
                  <PawPrint className="h-5 w-5 text-accent" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h3 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">{e.name}</h3>
                {e.title && <p className="text-xs text-muted-foreground italic truncate">{e.title}</p>}
                <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                  <Badge variant="outline" className="text-[9px] border-border/40 text-muted-foreground">
                    {BESTIARY_CATEGORIES[e.category] || e.category}
                  </Badge>
                  {e.danger && (
                    <Badge variant="outline" className="text-[9px] border-red-500/30 text-red-300 gap-0.5">
                      <AlertTriangle className="h-2.5 w-2.5" /> {e.danger}
                    </Badge>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
