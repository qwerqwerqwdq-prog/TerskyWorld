'use client'

import { useState, useEffect, useRef } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  FileText, Loader2, Clock, CheckCircle2, ChevronRight, Shield,
  X, Send, ScrollText, Save, AlertCircle, Trash2, History, Coins,
  TrendingUp, TrendingDown, Minus,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { Markdown } from '@/components/shared/markdown'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { STAT_SECTIONS } from '@/lib/constants'
import { StatSectionEditor, type StatContent, type StatChange } from '@/components/admin/stat-section-editor'
import { cn } from '@/lib/utils'

interface Post {
  id: string
  title: string
  content: string
  context?: string | null
  turnNumber?: number | null
  weekNumber?: number | null
  status: string
  createdAt: string
  author: { id: string; name: string }
  faction?: { id: string; name: string } | null
  attachments: Array<{ id: string; fileName: string; filePath: string; fileType: string; mimeType: string; fileSize: number }>
  verdict?: {
    id: string
    roleplayText: string
    technicalText?: string | null
    statChanges?: string | null
    createdAt: string
    admin: { id: string; name: string }
  } | null
}

export function AdminPostsView() {
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [filter, setFilter] = useState<'PENDING' | 'VERDICTED' | 'ALL'>('PENDING')

  const { data, isLoading } = useQuery<{ posts: Post[] }>({
    queryKey: ['admin-posts', filter],
    queryFn: async () => {
      const url = filter !== 'ALL' ? `/api/posts?status=${filter}` : '/api/posts'
      return (await fetch(url)).json()
    },
  })

  const posts = data?.posts || []

  if (selectedId) {
    const post = posts.find((p) => p.id === selectedId)
    if (post) return <VerdictEditor post={post} onBack={() => setSelectedId(null)} />
  }

  const pendingCount = posts.filter(p => p.status === 'PENDING').length
  const verdictedCount = posts.filter(p => p.status === 'VERDICTED').length

  return (
    <div className="space-y-5">
      <PageHeader title="Все посты" description="Вынесение вердиктов по постам игроков" />

      <Tabs value={filter} onValueChange={(v) => setFilter(v as 'PENDING' | 'VERDICTED' | 'ALL')}>
        <TabsList className="bg-muted/30">
          <TabsTrigger value="PENDING" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
            Ожидают ({pendingCount})
          </TabsTrigger>
          <TabsTrigger value="VERDICTED" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
            С вердиктом ({verdictedCount})
          </TabsTrigger>
          <TabsTrigger value="ALL" className="data-[state=active]:bg-accent data-[state=active]:text-accent-foreground">
            Все ({posts.length})
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {isLoading ? (
        <CardListSkeleton count={4} />
      ) : posts.length === 0 ? (
        <EmptyState icon={FileText} title="Постов нет" description="В выбранной категории постов не найдено. Когда игроки опубликуют свои ролевые действия, они появятся здесь для вынесения вердикта." />
      ) : (
        <div className="space-y-2">
          {posts.map((post) => (
            <Card
              key={post.id}
              onClick={() => setSelectedId(post.id)}
              className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    {post.status === 'PENDING' ? (
                      <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 gap-1 text-[10px]"><Clock className="h-3 w-3" /> Ожидает</Badge>
                    ) : (
                      <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 gap-1 text-[10px]"><CheckCircle2 className="h-3 w-3" /> Вердикт</Badge>
                    )}
                    {post.faction && <Badge variant="outline" className="text-[10px] border-accent/30 text-accent gap-1"><Shield className="h-2.5 w-2.5" /> {post.faction.name}</Badge>}
                    {post.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {post.turnNumber}</Badge>}
                  </div>
                  <h3 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">{post.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{post.content}</p>
                  <p className="text-[10px] text-muted-foreground/60 mt-1.5">
                    {post.author.name} · {new Date(post.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-accent shrink-0 mt-1" />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

interface CurrentStat {
  id: string
  sectionKey: string
  sectionTitle: string
  content: unknown
}

interface ChangeLog {
  id: string
  sectionKey: string
  changeType: string
  oldValue: unknown
  newValue: unknown
  createdAt: string
  verdict?: { post: { id: string; title: string } } | null
  admin: { id: string; name: string }
}

function VerdictEditor({ post, onBack }: { post: Post; onBack: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [saving, setSaving] = useState(false)
  const [roleplayText, setRoleplayText] = useState(post.verdict?.roleplayText || '')
  const [technicalText, setTechnicalText] = useState(post.verdict?.technicalText || '')
  // Map<sectionKey, { content, modified }>
  const [sectionEdits, setSectionEdits] = useState<Record<string, { content: StatContent | null; modified: boolean }>>({})
  const scrollRef = useRef<HTMLDivElement>(null)

  // Загружаем текущие статы фракции поста + существующий вердикт + историю
  const { data: verdictData, isLoading: verdictLoading } = useQuery<{
    faction: { id: string; name: string } | null
    verdict?: Post['verdict'] | null
    currentStats: CurrentStat[]
    changeLogs: ChangeLog[]
  }>({
    queryKey: ['verdict-context', post.id],
    queryFn: async () => (await fetch(`/api/posts/${post.id}/verdict`)).json(),
    enabled: !!post.faction,
  })

  // Если есть существующий вердикт с statChanges — парсим и инициализируем sectionEdits
  useEffect(() => {
    if (post.verdict?.statChanges) {
      try {
        const changes = JSON.parse(post.verdict.statChanges) as StatChange[]
        const init: Record<string, { content: StatContent | null; modified: boolean }> = {}
        for (const c of changes) {
          init[c.sectionKey] = {
            content: (c.newContent as StatContent) ?? null,
            modified: true,
          }
        }
        setSectionEdits(init)
      } catch { /* ignore */ }
    }
  }, [post.verdict?.statChanges])

  const currentStats = verdictData?.currentStats || []
  const changeLogs = verdictData?.changeLogs || []

  const statsByKey: Record<string, StatContent | null> = {}
  for (const s of currentStats) {
    statsByKey[s.sectionKey] = (s.content as StatContent) ?? null
  }

  const modifiedSections = Object.entries(sectionEdits).filter(([, v]) => v.modified && v.content)

  const handleSave = async () => {
    if (roleplayText.length < 5) {
      toast({ title: 'Ошибка', description: 'Ролевая часть вердикта обязательна', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const statChangesArr: StatChange[] = modifiedSections.map(([key, v]) => ({
        sectionKey: key,
        newContent: v.content as StatContent,
      }))
      const res = await fetch(`/api/posts/${post.id}/verdict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roleplayText,
          technicalText,
          statChanges: statChangesArr.length > 0 ? JSON.stringify(statChangesArr) : undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Вердикт вынесен', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-posts'] })
      queryClient.invalidateQueries({ queryKey: ['posts'] })
      queryClient.invalidateQueries({ queryKey: ['faction'] })
      queryClient.invalidateQueries({ queryKey: ['verdict-context'] })
      onBack()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteVerdict = async () => {
    if (!confirm('Отозвать вердикт? Статистика будет автоматически возвращена к исходному состоянию.')) return
    try {
      const res = await fetch(`/api/posts/${post.id}/verdict`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Вердикт отозван', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-posts'] })
      queryClient.invalidateQueries({ queryKey: ['faction'] })
      onBack()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-4" ref={scrollRef}>
      <button onClick={onBack} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1 transition-colors">
        <ChevronRight className="h-3 w-3 rotate-180" /> Назад к постам
      </button>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Left: Post + verdict editor */}
        <div className="space-y-4">
          {/* Пост игрока */}
          <Card className="border-border/40 bg-card/40 p-5">
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              {post.faction && <Badge className="bg-accent/20 text-accent border-accent/30 gap-1 text-[10px]"><Shield className="h-3 w-3" /> {post.faction.name}</Badge>}
              {post.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {post.turnNumber}</Badge>}
              {post.weekNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Нед. {post.weekNumber}</Badge>}
              <span className="text-[10px] text-muted-foreground/60 ml-auto">{post.author.name} · {new Date(post.createdAt).toLocaleString('ru-RU')}</span>
            </div>
            <h2 className="font-heading text-xl font-semibold text-foreground mb-2">{post.title}</h2>
            <div className="ornament-divider opacity-30 mb-3" />
            <div className="prose prose-invert max-w-none text-sm text-foreground/90 leading-relaxed">
              <Markdown content={post.content} />
            </div>
            {post.context && (
              <div className="mt-3 p-3 rounded-md bg-muted/20 border border-border/30">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Контекст от автора</p>
                <p className="text-sm text-foreground/70 italic">{post.context}</p>
              </div>
            )}
            {post.attachments.length > 0 && (
              <div className="mt-3">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-2">Вложения</p>
                <div className="flex flex-wrap gap-2">
                  {post.attachments.map((a) => (
                    <a key={a.id} href={a.filePath} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-2 rounded-md bg-muted/20 border border-border/30 hover:border-accent/30 transition-colors">
                      {a.fileType === 'IMAGE' ? <img src={a.filePath} alt={a.fileName} className="h-8 w-8 rounded object-cover" /> : <FileText className="h-4 w-4 text-muted-foreground" />}
                      <span className="text-xs text-foreground truncate max-w-[120px]">{a.fileName}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </Card>

          {/* Редактор вердикта */}
          <Card className="ornate-border bg-gradient-to-br from-accent/5 to-card/40 border-accent/30 p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center">
                  <Shield className="h-4 w-4 text-accent" />
                </div>
                <h2 className="font-heading text-lg font-semibold text-accent">Вердикт администратора</h2>
                {post.verdict && <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[10px]">Редактирование</Badge>}
              </div>
              {post.verdict && (
                <Button variant="ghost" size="sm" onClick={handleDeleteVerdict} className="text-destructive hover:text-destructive text-xs">
                  <Trash2 className="h-3.5 w-3.5 mr-1" /> Отозвать
                </Button>
              )}
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-muted-foreground text-xs uppercase tracking-wider">Ролевая часть (нарратив) *</Label>
                <Textarea
                  value={roleplayText}
                  onChange={(e) => setRoleplayText(e.target.value)}
                  placeholder="Опишите, что произошло по итогам поста игрока. Это увидит игрок как ролевой итог..."
                  className="bg-background/60 min-h-[150px]"
                />
                <p className="text-[10px] text-muted-foreground/60">Поддерживается Markdown</p>
              </div>

              <div className="space-y-2">
                <Label className="text-muted-foreground text-xs uppercase tracking-wider">Техническая часть (опц.)</Label>
                <Textarea
                  value={technicalText}
                  onChange={(e) => setTechnicalText(e.target.value)}
                  placeholder="Технические пояснения: что именно изменилось, расчёты, формулы..."
                  className="bg-background/60 min-h-[80px]"
                />
              </div>
            </div>
          </Card>
        </div>

        {/* Right: Stat editor + history */}
        <div className="space-y-4">
          <Card className="border-border/40 bg-card/40 p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center">
                  <Coins className="h-4 w-4 text-accent" />
                </div>
                <div>
                  <h2 className="font-heading text-lg font-semibold text-foreground">Статистика государства</h2>
                  <p className="text-xs text-muted-foreground">
                    {post.faction?.name || 'Фракция'} · отметьте секции для обновления
                  </p>
                </div>
              </div>
              {modifiedSections.length > 0 && (
                <Badge className="bg-accent/20 text-accent border-accent/30 text-[10px]">
                  {modifiedSections.length} изм.
                </Badge>
              )}
            </div>

            {verdictLoading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-accent" /></div>
            ) : (
              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1 custom-scroll">
                {STAT_SECTIONS.map((section) => {
                  const current = statsByKey[section.key] ?? null
                  const initial = post.verdict?.statChanges
                    ? (() => {
                        try {
                          const changes = JSON.parse(post.verdict.statChanges) as StatChange[]
                          const found = changes.find((c) => c.sectionKey === section.key)
                          return found ? (found.newContent as StatContent) : undefined
                        } catch { return undefined }
                      })()
                    : undefined
                  return (
                    <StatSectionEditor
                      key={section.key}
                      sectionKey={section.key}
                      currentContent={current}
                      initialContent={initial}
                      onChange={(content, modified) => {
                        setSectionEdits((prev) => ({
                          ...prev,
                          [section.key]: { content, modified },
                        }))
                      }}
                    />
                  )
                })}
              </div>
            )}
          </Card>

          {/* История изменений */}
          {changeLogs.length > 0 && (
            <Card className="border-border/40 bg-card/30 p-5">
              <div className="flex items-center gap-2 mb-3">
                <History className="h-4 w-4 text-accent" />
                <h3 className="font-heading text-sm font-semibold text-foreground">История изменений</h3>
                <Badge variant="outline" className="text-[10px] text-muted-foreground ml-auto">{changeLogs.length}</Badge>
              </div>
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1 custom-scroll">
                {changeLogs.map((log) => (
                  <ChangeLogItem key={log.id} log={log} />
                ))}
              </div>
            </Card>
          )}

          {/* Действия */}
          <div className="flex justify-end gap-2 sticky bottom-4 z-10">
            <Button variant="ghost" onClick={onBack} className="bg-card/80 backdrop-blur">Отмена</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-accent hover:bg-accent/90 glow-teal shadow-lg">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
              {post.verdict ? 'Обновить вердикт' : 'Вынести вердикт'}
              {modifiedSections.length > 0 && ` · ${modifiedSections.length} секц.`}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

function ChangeLogItem({ log }: { log: ChangeLog }) {
  const def = STAT_SECTIONS.find((s) => s.key === log.sectionKey)
  const oldC = (log.oldValue as StatContent) ?? null
  const newC = (log.newValue as StatContent) ?? null

  // Найдём первое числовое поле, где есть diff (для краткого превью)
  const previewField = def?.fields.find((f) => {
    if (f.type !== 'number') return false
    const o = Number(oldC?.[f.key] ?? 0)
    const n = Number(newC?.[f.key] ?? 0)
    return o !== n
  })
  const delta = previewField
    ? Number(newC?.[previewField.key] ?? 0) - Number(oldC?.[previewField.key] ?? 0)
    : null

  const typeColor = {
    CREATE: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    UPDATE: 'bg-accent/20 text-accent border-accent/30',
    DELETE: 'bg-red-500/20 text-red-300 border-red-500/30',
  }[log.changeType] || 'bg-muted text-muted-foreground border-border/40'

  return (
    <div className="p-2.5 rounded-md bg-muted/15 border border-border/30 text-xs">
      <div className="flex items-center gap-2 mb-1 flex-wrap">
        <Badge variant="outline" className={cn('text-[9px] uppercase', typeColor)}>{log.changeType}</Badge>
        <span className="font-heading text-foreground text-[11px]">{def?.title || log.sectionKey}</span>
        <span className="text-muted-foreground/60 ml-auto">{new Date(log.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
      </div>
      <p className="text-[10px] text-muted-foreground">
        {log.verdict?.post?.title || 'Прямое изменение'} · {log.admin.name}
      </p>
      {delta !== null && previewField && (
        <div className="mt-1 flex items-center gap-1">
          {delta > 0 ? <TrendingUp className="h-3 w-3 text-emerald-400" /> : <TrendingDown className="h-3 w-3 text-red-400" />}
          <span className="text-[10px] text-muted-foreground">{previewField.label}:</span>
          <span className={cn('text-[10px] font-medium', delta > 0 ? 'text-emerald-300' : 'text-red-300')}>
            {delta > 0 ? '+' : ''}{delta.toLocaleString('ru-RU')}
          </span>
        </div>
      )}
    </div>
  )
}
