'use client'

import { useState, useMemo, useEffect, useRef, useCallback } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  ScrollText, Plus, Loader2, Clock, CheckCircle2, FileText,
  Paperclip, Image as ImageIcon, X, Send, Shield, ChevronRight,
  TrendingUp, TrendingDown, Coins,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { BookmarkButton } from '@/components/shared/bookmark-button'
import { ImageDropzone, usePasteUpload, type UploadedFile } from '@/components/shared/image-dropzone'
import { Markdown } from '@/components/shared/markdown'
import { STAT_SECTIONS, type StatFieldDef } from '@/lib/constants'
import { cn } from '@/lib/utils'

interface Verdict {
  id: string
  roleplayText: string
  technicalText?: string | null
  statChanges?: string | null
  createdAt: string
  admin: { id: string; name: string }
}

interface Post {
  id: string
  title: string
  content: string
  context?: string | null
  turnNumber?: number | null
  weekNumber?: number | null
  status: string
  createdAt: string
  updatedAt: string
  author: { id: string; name: string }
  faction?: { id: string; name: string } | null
  attachments: Attachment[]
  verdict?: Verdict | null
}

interface Attachment {
  id: string
  fileName: string
  filePath: string
  fileType: string
  mimeType: string
  fileSize: number
}

export function PostsView() {
  const [showForm, setShowForm] = useState(false)
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null)

  // Listen for quick action events (from FAB)
  useEffect(() => {
    const handler = (e: Event) => {
      if ((e as CustomEvent).detail === 'new-post') {
        setShowForm(true)
        setSelectedPostId(null)
      }
    }
    window.addEventListener('quick-action', handler)
    return () => window.removeEventListener('quick-action', handler)
  }, [])

  const { data, isLoading } = useQuery<{ posts: Post[] }>({
    queryKey: ['posts'],
    queryFn: async () => (await fetch('/api/posts')).json(),
  })

  const posts = data?.posts || []

  if (selectedPostId) {
    const post = posts.find((p) => p.id === selectedPostId)
    if (post) return <PostDetail post={post} onBack={() => setSelectedPostId(null)} />
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Мои посты"
        description="Здесь вы пишете ролевые посты и получаете вердикты администратора"
        action={
          <Button onClick={() => setShowForm(true)} className="bg-accent hover:bg-accent/90 glow-teal">
            <Plus className="h-4 w-4 mr-1.5" /> Новый пост
          </Button>
        }
      />

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <PostForm onClose={() => setShowForm(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-accent" />
        </div>
      ) : posts.length === 0 ? (
        <EmptyState
          icon={ScrollText}
          title="Постов пока нет"
          description="Создайте первый пост — опишите действия вашего княжества, и администратор вынесет вердикт"
          action={<Button onClick={() => setShowForm(true)} className="bg-accent hover:bg-accent/90"><Plus className="h-4 w-4 mr-1.5" /> Создать пост</Button>}
        />
      ) : (
        <div className="space-y-3">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} onClick={() => setSelectedPostId(post.id)} />
          ))}
        </div>
      )}
    </div>
  )
}

function PostCard({ post, onClick }: { post: Post; onClick: () => void }) {
  const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
    PENDING: { label: 'Ожидает', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30', icon: <Clock className="h-3 w-3" /> },
    VERDICTED: { label: 'Вердикт', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30', icon: <CheckCircle2 className="h-3 w-3" /> },
    ARCHIVED: { label: 'Архив', color: 'bg-muted text-muted-foreground border-border/40', icon: <FileText className="h-3 w-3" /> },
  }
  const status = statusConfig[post.status] || statusConfig.PENDING

  // Считаем количество изменений в вердикте
  const statChangeCount = useMemo(() => {
    if (!post.verdict?.statChanges) return 0
    try {
      const changes = JSON.parse(post.verdict.statChanges) as unknown[]
      return changes.length
    } catch { return 0 }
  }, [post.verdict])

  return (
    <Card
      onClick={onClick}
      className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <Badge variant="outline" className={`${status.color} text-[10px] gap-1`}>
              {status.icon} {status.label}
            </Badge>
            {post.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {post.turnNumber}</Badge>}
            {post.weekNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Нед. {post.weekNumber}</Badge>}
            {post.attachments.length > 0 && (
              <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground gap-1">
                <Paperclip className="h-3 w-3" /> {post.attachments.length}
              </Badge>
            )}
            {statChangeCount > 0 && (
              <Badge variant="outline" className="text-[10px] border-accent/30 text-accent gap-1">
                <Coins className="h-2.5 w-2.5" /> {statChangeCount} секц.
              </Badge>
            )}
          </div>
          <h3 className="font-heading text-base text-foreground group-hover:text-accent transition-colors truncate">
            {post.title}
          </h3>
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{post.content}</p>
          <p className="text-[10px] text-muted-foreground/60 mt-2">
            {new Date(post.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-accent transition-colors shrink-0 mt-1" />
      </div>
    </Card>
  )
}

function PostForm({ onClose }: { onClose: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [attachments, setAttachments] = useState<Attachment[]>([])
  const [form, setForm] = useState({
    title: '',
    content: '',
    context: '',
    turnNumber: '',
    weekNumber: '',
  })
  const contentTextareaRef = useRef<HTMLTextAreaElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const dragCounter = useRef(0)

  // Paste upload — вставка картинок из буфера обмена прямо в контент
  const handlePaste = usePasteUpload(
    () => {},
    {
      insertMarkdown: (markdown) => {
        setForm((prev) => ({
          ...prev,
          content: prev.content ? `${prev.content}\n\n${markdown}` : markdown,
        }))
        toast({ title: 'Картинка вставлена', description: 'Изображение добавлено в текст поста' })
      },
    }
  )

  // Drag and drop files
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current = 0
    setIsDragging(false)
    const files = Array.from(e.dataTransfer.files)
    if (files.length === 0) return

    setUploading(true)
    for (const file of files) {
      try {
        const fd = new FormData()
        fd.append('file', file)
        const res = await fetch('/api/upload', { method: 'POST', body: fd })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        // Вставляем markdown прямо в контент
        setForm((prev) => ({
          ...prev,
          content: prev.content ? `${prev.content}\n\n${data.markdown}` : data.markdown,
        }))
        // Также добавляем в attachments
        setAttachments((prev) => [...prev, {
          id: `temp-${Date.now()}-${Math.random()}`,
          fileName: data.fileName,
          filePath: data.filePath,
          fileType: data.fileType,
          mimeType: file.type,
          fileSize: file.size,
        }])
      } catch (e) {
        toast({ title: 'Ошибка загрузки', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
      }
    }
    setUploading(false)
  }, [toast])

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current++
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current--
    if (dragCounter.current === 0) setIsDragging(false)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  // Compact upload button handler
  const handleCompactUpload = useCallback(async (files: UploadedFile[]) => {
    for (const f of files) {
      setForm((prev) => ({
        ...prev,
        content: prev.content ? `${prev.content}\n\n${f.markdown}` : f.markdown,
      }))
      setAttachments((prev) => [...prev, {
        id: `temp-${Date.now()}-${Math.random()}`,
        fileName: f.fileName,
        filePath: f.filePath,
        fileType: f.fileType,
        mimeType: '',
        fileSize: 0,
      }])
    }
    toast({ title: 'Файл загружен', description: `${files.length} файл(ов) добавлено` })
  }, [toast])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.title.length < 3 || form.content.length < 10) {
      toast({ title: 'Ошибка', description: 'Заполните заголовок и содержание', variant: 'destructive' })
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: form.title,
          content: form.content,
          context: form.context || undefined,
          turnNumber: form.turnNumber ? Number(form.turnNumber) : undefined,
          weekNumber: form.weekNumber ? Number(form.weekNumber) : undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)

      toast({ title: 'Пост отправлен', description: 'Ожидает вердикта администратора' })
      queryClient.invalidateQueries({ queryKey: ['posts'] })
      onClose()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="ornate-border bg-card/60 border-border/40 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading text-lg font-semibold text-foreground">Новый пост</h2>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Заголовок *</Label>
          <Input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Действия княжества на 5-й неделе..."
            className="bg-background/60"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Ход</Label>
            <Input
              type="number"
              value={form.turnNumber}
              onChange={(e) => setForm({ ...form, turnNumber: e.target.value })}
              placeholder="5"
              className="bg-background/60"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Неделя</Label>
            <Input
              type="number"
              value={form.weekNumber}
              onChange={(e) => setForm({ ...form, weekNumber: e.target.value })}
              placeholder="13"
              className="bg-background/60"
            />
          </div>
        </div>

        <div
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className={cn(
            'relative space-y-2 rounded-lg transition-all',
            isDragging && 'ring-2 ring-accent bg-accent/5 p-2'
          )}
        >
          {isDragging && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-accent/10 backdrop-blur-sm rounded-lg pointer-events-none">
              <div className="text-center">
                <ImageIcon className="h-10 w-10 text-accent mx-auto mb-2" />
                <p className="font-heading text-accent">Отпустите для загрузки</p>
              </div>
            </div>
          )}
          <div className="flex items-center justify-between">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Ролевое содержание *</Label>
            <ImageDropzone onUpload={handleCompactUpload} compact label="Загрузить картинку или файл" />
          </div>
          <Textarea
            ref={contentTextareaRef}
            value={form.content}
            onChange={(e) => setForm({ ...form, content: e.target.value })}
            onPaste={handlePaste}
            placeholder="Опишите действия вашего княжества... Можно вставлять картинки (Ctrl+V) или перетащить файлы."
            className="bg-background/60 min-h-[200px] font-serif"
            required
          />
          <p className="text-[10px] text-muted-foreground/60">Markdown · Ctrl+V для вставки картинки · drag-and-drop файлов</p>
        </div>

        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Контекст / Пояснение (опц.)</Label>
          <Textarea
            value={form.context}
            onChange={(e) => setForm({ ...form, context: e.target.value })}
            placeholder="Технические пояснения к посту для администратора..."
            className="bg-background/60 min-h-[80px]"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Вложения</Label>
          <div className="flex flex-wrap gap-2">
            {attachments.map((a) => (
              <div key={a.id} className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-muted/30 border border-border/40">
                {a.fileType === 'IMAGE' ? <ImageIcon className="h-3.5 w-3.5 text-accent" /> : <Paperclip className="h-3.5 w-3.5 text-muted-foreground" />}
                <span className="text-xs text-foreground truncate max-w-[150px]">{a.fileName}</span>
                <button
                  type="button"
                  onClick={() => setAttachments((prev) => prev.filter((x) => x.id !== a.id))}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            <label className="cursor-pointer">
              <input
                type="file"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (f) handleFile(f)
                  e.target.value = ''
                }}
                accept="image/*,.pdf,.doc,.docx,.txt,.csv"
              />
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-dashed border-border/50 text-xs text-muted-foreground hover:text-accent hover:border-accent/40 transition-colors">
                {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
                {uploading ? 'Загрузка...' : 'Добавить файл'}
              </span>
            </label>
          </div>
        </div>

        <div className="flex gap-2 justify-end pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>Отмена</Button>
          <Button type="submit" disabled={loading} className="bg-accent hover:bg-accent/90 glow-teal">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4 mr-1.5" />}
            Отправить
          </Button>
        </div>
      </form>
    </Card>
  )
}

// === Детали поста с визуализацией изменений статов из вердикта ===
function PostDetail({ post, onBack }: { post: Post; onBack: () => void }) {
  return (
    <div className="space-y-4">
      <button onClick={onBack} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1 transition-colors">
        <ChevronRight className="h-3 w-3 rotate-180" /> Назад к постам
      </button>

      <Card className="ornate-border bg-card/40 border-border/40 p-6">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Badge variant="outline" className="text-[10px] border-border/40">
            {post.status === 'PENDING' ? 'Ожидает вердикта' : post.status === 'VERDICTED' ? 'Вердикт получен' : 'Архив'}
          </Badge>
          {post.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {post.turnNumber}</Badge>}
          {post.weekNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Неделя {post.weekNumber}</Badge>}
          <span className="ml-auto" />
          <BookmarkButton type="post" entityId={post.id} />
        </div>
        <h1 className="font-heading text-2xl font-bold text-foreground text-glow mb-3">{post.title}</h1>
        <p className="text-xs text-muted-foreground mb-4">
          {new Date(post.createdAt).toLocaleString('ru-RU')}
        </p>

        <div className="ornament-divider opacity-30 mb-4" />
        <Markdown content={post.content} />

        {post.context && (
          <div className="mt-4 p-3 rounded-md bg-muted/20 border border-border/30">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Контекст</p>
            <p className="text-sm text-foreground/80 italic">{post.context}</p>
          </div>
        )}

        {post.attachments.length > 0 && (
          <div className="mt-4">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-2">Вложения</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {post.attachments.map((a) => (
                <a
                  key={a.id}
                  href={a.filePath}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-2 rounded-md bg-muted/20 border border-border/30 hover:border-accent/30 transition-colors"
                >
                  {a.fileType === 'IMAGE' ? (
                    <img src={a.filePath} alt={a.fileName} className="h-10 w-10 rounded object-cover" />
                  ) : (
                    <div className="h-10 w-10 rounded bg-muted/40 flex items-center justify-center">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <p className="text-xs text-foreground truncate">{a.fileName}</p>
                    <p className="text-[10px] text-muted-foreground">{(a.fileSize / 1024).toFixed(1)} КБ</p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        )}
      </Card>

      {/* Вердикт */}
      {post.verdict ? (
        <VerdictBlock verdict={post.verdict} />
      ) : (
        <Card className="bg-amber-500/5 border-amber-500/20 p-6 text-center">
          <Clock className="h-8 w-8 text-amber-400/60 mx-auto mb-2" />
          <p className="text-sm text-amber-200/80">Пост ожидает вердикта администратора</p>
        </Card>
      )}
    </div>
  )
}

function VerdictBlock({ verdict }: { verdict: Verdict }) {
  // Парсим statChanges и формируем список diff
  const statChanges = useMemo<Array<{
    sectionKey: string
    sectionTitle?: string
    oldContent?: unknown
    newContent: unknown
  }>>(() => {
    if (!verdict.statChanges) return []
    try { return JSON.parse(verdict.statChanges) } catch { return [] }
  }, [verdict.statChanges])

  return (
    <Card className="ornate-border bg-gradient-to-br from-accent/10 to-card/40 border-accent/30 p-6">
      <div className="flex items-center gap-2 mb-3">
        <div className="h-8 w-8 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center">
          <Shield className="h-4 w-4 text-accent" />
        </div>
        <div>
          <h2 className="font-heading text-lg font-semibold text-accent">Вердикт администратора</h2>
          <p className="text-[10px] text-muted-foreground">
            {verdict.admin.name} · {new Date(verdict.createdAt).toLocaleString('ru-RU')}
          </p>
        </div>
      </div>
      <div className="ornament-divider opacity-30 mb-4" />
      <Markdown content={verdict.roleplayText} />

      {verdict.technicalText && (
        <div className="mt-4 p-3 rounded-md bg-muted/20 border border-border/30">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Техническая часть</p>
          <p className="text-sm text-foreground/80 whitespace-pre-wrap">{verdict.technicalText}</p>
        </div>
      )}

      {/* Изменения статистики — before/after */}
      {statChanges.length > 0 && (
        <div className="mt-4">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-2 flex items-center gap-1.5">
            <Coins className="h-3 w-3 text-accent" /> Изменения статистики государства
          </p>
          <div className="space-y-2">
            {statChanges.map((change, idx) => (
              <StatChangeDiff
                key={idx}
                sectionKey={change.sectionKey}
                sectionTitle={change.sectionTitle}
                oldContent={change.oldContent as Record<string, unknown> | undefined}
                newContent={change.newContent as Record<string, unknown> | undefined}
              />
            ))}
          </div>
        </div>
      )}
    </Card>
  )
}

function StatChangeDiff({
  sectionKey,
  sectionTitle,
  oldContent,
  newContent,
}: {
  sectionKey: string
  sectionTitle?: string
  oldContent?: Record<string, unknown>
  newContent?: Record<string, unknown>
}) {
  const def = STAT_SECTIONS.find((s) => s.key === sectionKey)
  const diffs = useMemo(() => {
    if (!def) return []
    return computeFieldDiffs(def.fields, oldContent ?? {}, newContent ?? {})
  }, [def, oldContent, newContent])

  if (diffs.length === 0) return null

  return (
    <div className="rounded-md border border-accent/20 bg-accent/5 p-3">
      <div className="flex items-center gap-2 mb-2">
        <Coins className="h-3.5 w-3.5 text-accent" />
        <h4 className="font-heading text-sm font-semibold text-foreground">
          {sectionTitle || def?.title || sectionKey}
        </h4>
        <Badge variant="outline" className="text-[9px] border-accent/30 text-accent ml-auto">
          {diffs.length} полей
        </Badge>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
        {diffs.map((d, i) => (
          <div key={i} className="flex items-center gap-2 text-xs bg-background/40 rounded p-2">
            <span className="text-muted-foreground truncate flex-1">{d.label}</span>
            <span className="text-red-300 line-through opacity-70">{d.oldValue}</span>
            <ChevronRight className="h-3 w-3 text-accent shrink-0" />
            <span className="text-emerald-300 font-medium">{d.newValue}</span>
            {d.delta !== null && (
              <Badge className={cn('text-[9px] gap-0.5 shrink-0', d.delta > 0 ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-red-500/20 text-red-300 border-red-500/30')}>
                {d.delta > 0 ? '+' : ''}{d.delta.toLocaleString('ru-RU')}
              </Badge>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

function computeFieldDiffs(
  fields: StatFieldDef[],
  old: Record<string, unknown>,
  newC: Record<string, unknown>
): Array<{ label: string; oldValue: string; newValue: string; delta: number | null }> {
  const out: Array<{ label: string; oldValue: string; newValue: string; delta: number | null }> = []
  for (const f of fields) {
    const o = old[f.key]
    const n = newC[f.key]
    if (f.type === 'number') {
      const on = Number(o ?? 0)
      const nn = Number(n ?? 0)
      if (on !== nn) {
        out.push({
          label: f.label,
          oldValue: on.toLocaleString('ru-RU'),
          newValue: nn.toLocaleString('ru-RU'),
          delta: nn - on,
        })
      }
    } else if (f.type === 'list') {
      const oa = Array.isArray(o) ? o as string[] : []
      const na = Array.isArray(n) ? n as string[] : []
      if (JSON.stringify(oa) !== JSON.stringify(na)) {
        out.push({
          label: f.label,
          oldValue: `${oa.length} зап.`,
          newValue: `${na.length} зап.`,
          delta: na.length - oa.length,
        })
      }
    } else {
      const os = String(o ?? '')
      const ns = String(n ?? '')
      if (os !== ns) {
        out.push({
          label: f.label,
          oldValue: os || '—',
          newValue: ns || '—',
          delta: null,
        })
      }
    }
  }
  return out
}
