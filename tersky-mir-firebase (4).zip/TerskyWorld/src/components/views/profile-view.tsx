'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  User, Mail, Calendar, Loader2, Save, Shield, ScrollText,
  MessageSquare, BookOpen, PawPrint, Crown, Edit, X,
  Clock, Award, FileText, Lock, KeyRound, Eye, EyeOff,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { PageHeader, EmptyState } from '@/components/shared/ui-bits'
import { cn } from '@/lib/utils'

interface ProfileUser {
  id: string
  name: string
  email: string
  role: string
  avatar?: string | null
  bio?: string | null
  createdAt: string
  lastLoginAt?: string | null
  faction?: {
    id: string
    name: string
    shortName?: string | null
    motto?: string | null
    description?: string | null
    bannerColor?: string | null
    isApproved: boolean
    createdAt: string
  } | null
  _count: {
    posts: number
    chatMessages: number
    verdicts: number
    chronicle: number
    bestiary: number
  }
}

export function ProfileView() {
  const queryClient = useQueryClient()
  const [editing, setEditing] = useState(false)

  const { data, isLoading } = useQuery<{ user: ProfileUser }>({
    queryKey: ['profile'],
    queryFn: async () => (await fetch('/api/profile')).json(),
  })

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    )
  }

  const user = data?.user
  if (!user) return <EmptyState icon={User} title="Профиль не найден" />

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      <PageHeader
        title="Профиль правителя"
        description="Ваши данные и статистика участия в Терском Мире"
        action={
          !editing ? (
            <Button onClick={() => setEditing(true)} className="bg-accent hover:bg-accent/90 glow-teal">
              <Edit className="h-4 w-4 mr-1.5" /> Редактировать
            </Button>
          ) : undefined
        }
      />

      {editing ? (
        <ProfileEditForm user={user} onClose={() => setEditing(false)} />
      ) : (
        <ProfileCard user={user} />
      )}

      {/* Статистика участия */}
      <Card className="border-border/40 bg-card/40 p-5">
        <h2 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Award className="h-4 w-4 text-accent" /> Деятельность в Терском Мире
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatBlock icon={ScrollText} label="Постов" value={user._count.posts} color="bg-accent/15 text-accent" />
          <StatBlock icon={MessageSquare} label="Сообщений" value={user._count.chatMessages} color="bg-purple-500/15 text-purple-300" />
          <StatBlock icon={BookOpen} label="Хроника" value={user._count.chronicle} color="bg-teal-500/15 text-teal-300" />
          <StatBlock icon={PawPrint} label="Бестиарий" value={user._count.bestiary} color="bg-amber-500/15 text-amber-300" />
        </div>
        {user.role === 'ADMIN' && (
          <div className="mt-3 p-3 rounded-md bg-accent/10 border border-accent/30 flex items-center gap-2">
            <Crown className="h-4 w-4 text-accent" />
            <span className="text-sm text-accent">Вынесено вердиктов: <strong>{user._count.verdicts}</strong></span>
          </div>
        )}
      </Card>

      {/* Информация о аккаунте */}
      <Card className="border-border/40 bg-card/40 p-5">
        <h2 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <FileText className="h-4 w-4 text-accent" /> Информация об аккаунте
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2 p-2.5 rounded-md bg-muted/20 border border-border/30">
            <Mail className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <span className="text-muted-foreground text-xs">Email:</span>
            <span className="text-foreground truncate">{user.email}</span>
          </div>
          <div className="flex items-center gap-2 p-2.5 rounded-md bg-muted/20 border border-border/30">
            <Calendar className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <span className="text-muted-foreground text-xs">Регистрация:</span>
            <span className="text-foreground">{new Date(user.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
          </div>
          {user.lastLoginAt && (
            <div className="flex items-center gap-2 p-2.5 rounded-md bg-muted/20 border border-border/30">
              <Clock className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground text-xs">Последний вход:</span>
              <span className="text-foreground">{new Date(user.lastLoginAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          )}
          <div className="flex items-center gap-2 p-2.5 rounded-md bg-muted/20 border border-border/30">
            <Shield className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <span className="text-muted-foreground text-xs">Роль:</span>
            <Badge variant="outline" className={user.role === 'ADMIN' ? 'border-accent/40 text-accent text-[10px]' : 'text-[10px]'}>
              {user.role === 'ADMIN' ? 'Администратор' : 'Игрок'}
            </Badge>
          </div>
        </div>
      </Card>

      {/* Смена пароля */}
      <PasswordChangeCard />
    </div>
  )
}

function ProfileCard({ user }: { user: ProfileUser }) {
  return (
    <Card className="ornate-border overflow-hidden border-border/40 bg-card/40">
      <div className="h-2 w-full bg-gradient-to-r from-accent/60 via-accent to-accent/60" />
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:items-start gap-5">
          {/* Аватар */}
          <div className="flex flex-col items-center gap-2 shrink-0">
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} className="h-24 w-24 rounded-full object-cover border-2 border-accent/40 shadow-lg" />
            ) : (
              <div className="h-24 w-24 rounded-full bg-accent/20 border-2 border-accent/40 flex items-center justify-center text-accent font-heading text-3xl font-bold shadow-lg">
                {user.name[0]?.toUpperCase()}
              </div>
            )}
            <Badge variant="outline" className={cn('text-[10px]', user.role === 'ADMIN' ? 'border-accent/40 text-accent' : '')}>
              {user.role === 'ADMIN' ? 'Администратор' : 'Игрок'}
            </Badge>
          </div>

          {/* Данные */}
          <div className="flex-1 min-w-0">
            <h1 className="font-heading text-2xl font-bold text-foreground text-glow mb-1">{user.name}</h1>
            {user.bio ? (
              <p className="text-sm text-foreground/80 italic leading-relaxed mt-2">{user.bio}</p>
            ) : (
              <p className="text-sm text-muted-foreground italic mt-2">Правитель пока не оставил описания своих деяний.</p>
            )}

            {/* Фракция */}
            {user.faction ? (
              <div className="mt-4 p-3 rounded-md bg-muted/20 border border-border/30">
                <div className="flex items-center gap-2 mb-1">
                  <Shield className="h-4 w-4" style={{ color: user.faction.bannerColor || '#3a7d74' }} />
                  <h3 className="font-heading text-sm font-semibold text-foreground">{user.faction.name}</h3>
                  {user.faction.isApproved ? (
                    <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[9px]">Утверждено</Badge>
                  ) : (
                    <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 text-[9px]">На утверждении</Badge>
                  )}
                </div>
                {user.faction.motto && (
                  <p className="text-xs italic text-accent/80 mb-1">«{user.faction.motto}»</p>
                )}
                {user.faction.description && (
                  <p className="text-xs text-muted-foreground line-clamp-2">{user.faction.description}</p>
                )}
              </div>
            ) : (
              <div className="mt-4 p-3 rounded-md bg-amber-500/10 border border-amber-500/30">
                <p className="text-xs text-amber-200/80">У вас ещё нет княжества. Зарегистрируйте его в разделе «Моё княжество».</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  )
}

function ProfileEditForm({ user, onClose }: { user: ProfileUser; onClose: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    name: user.name,
    avatar: user.avatar || '',
    bio: user.bio || '',
  })

  const handleSave = async () => {
    if (form.name.length < 2) {
      toast({ title: 'Ошибка', description: 'Имя минимум 2 символа', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          avatar: form.avatar || undefined,
          bio: form.bio || undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Профиль обновлён', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['profile'] })
      queryClient.invalidateQueries({ queryKey: ['session'] })
      onClose()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="ornate-border bg-card/60 border-border/40 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading text-lg font-semibold text-foreground">Редактирование профиля</h2>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Имя правителя *</Label>
          <Input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Князь..."
            className="bg-background/60"
            maxLength={50}
          />
          <p className="text-[10px] text-muted-foreground/60">{form.name.length}/50 символов</p>
        </div>

        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">URL аватара</Label>
          <Input
            value={form.avatar}
            onChange={(e) => setForm({ ...form, avatar: e.target.value })}
            placeholder="https://..."
            className="bg-background/60"
          />
          <p className="text-[10px] text-muted-foreground/60">Ссылка на изображение для аватара</p>
        </div>

        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">О правителе</Label>
          <Textarea
            value={form.bio}
            onChange={(e) => setForm({ ...form, bio: e.target.value })}
            placeholder="Опишите своего правителя, его историю и цели..."
            className="bg-background/60 min-h-[100px]"
            maxLength={500}
          />
          <p className="text-[10px] text-muted-foreground/60">{form.bio.length}/500 символов</p>
        </div>

        {/* Превью аватара */}
        {form.avatar && (
          <div className="flex items-center gap-3 p-3 rounded-md bg-muted/20 border border-border/30">
            <img src={form.avatar} alt="avatar preview" className="h-12 w-12 rounded-full object-cover border border-border/40" />
            <span className="text-xs text-muted-foreground">Предпросмотр аватара</span>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={onClose}>Отмена</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-accent hover:bg-accent/90 glow-teal">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
            Сохранить
          </Button>
        </div>
      </div>
    </Card>
  )
}

function StatBlock({
  icon: Icon, label, value, color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  color: string
}) {
  return (
    <div className="p-3 rounded-md bg-background/30 border border-border/30">
      <div className={cn('h-8 w-8 rounded-md border flex items-center justify-center mb-2', color)}>
        <Icon className="h-4 w-4" />
      </div>
      <p className="font-heading text-xl font-bold text-foreground leading-none">{value}</p>
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mt-1">{label}</p>
    </div>
  )
}

function PasswordChangeCard() {
  const { toast } = useToast()
  const [saving, setSaving] = useState(false)
  const [showCurrent, setShowCurrent] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)
  const [form, setForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  })

  const passwordsMatch = form.newPassword === form.confirmPassword
  const isValid = form.currentPassword.length >= 1
    && form.newPassword.length >= 6
    && passwordsMatch
    && form.newPassword !== form.currentPassword

  const handleSubmit = async () => {
    if (!passwordsMatch) {
      toast({ title: 'Ошибка', description: 'Пароли не совпадают', variant: 'destructive' })
      return
    }
    if (form.newPassword.length < 6) {
      toast({ title: 'Ошибка', description: 'Новый пароль минимум 6 символов', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/profile/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentPassword: form.currentPassword,
          newPassword: form.newPassword,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Пароль изменён', description: data.message })
      setForm({ currentPassword: '', newPassword: '', confirmPassword: '' })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="border-border/40 bg-card/40 p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="h-8 w-8 rounded-md bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
          <KeyRound className="h-4 w-4 text-amber-400" />
        </div>
        <div>
          <h2 className="font-heading text-lg font-semibold text-foreground tracking-wide">Смена пароля</h2>
          <p className="text-xs text-muted-foreground">Регулярно обновляйте пароль для безопасности</p>
        </div>
      </div>

      <div className="space-y-4 max-w-md">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Текущий пароль *</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              type={showCurrent ? 'text' : 'password'}
              value={form.currentPassword}
              onChange={(e) => setForm({ ...form, currentPassword: e.target.value })}
              placeholder="••••••••"
              className="bg-background/60 pl-9 pr-9"
            />
            <button
              type="button"
              onClick={() => setShowCurrent(!showCurrent)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showCurrent ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Новый пароль *</Label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                type={showNew ? 'text' : 'password'}
                value={form.newPassword}
                onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
                placeholder="Минимум 6 символов"
                className="bg-background/60 pl-9 pr-9"
              />
              <button
                type="button"
                onClick={() => setShowNew(!showNew)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showNew ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>
            {form.newPassword && form.newPassword.length < 6 && (
              <p className="text-[10px] text-amber-400">Пароль слишком короткий ({form.newPassword.length}/6)</p>
            )}
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Подтвердите *</Label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                type={showConfirm ? 'text' : 'password'}
                value={form.confirmPassword}
                onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
                placeholder="Повторите новый пароль"
                className={cn(
                  'bg-background/60 pl-9 pr-9',
                  form.confirmPassword && !passwordsMatch && 'border-red-500/50'
                )}
              />
              <button
                type="button"
                onClick={() => setShowConfirm(!showConfirm)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showConfirm ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>
            {form.confirmPassword && !passwordsMatch && (
              <p className="text-[10px] text-red-400">Пароли не совпадают</p>
            )}
          </div>
        </div>

        {/* Индикатор надёжности пароля */}
        {form.newPassword.length >= 6 && (
          <PasswordStrength password={form.newPassword} />
        )}

        <div className="flex justify-end pt-2">
          <Button onClick={handleSubmit} disabled={!isValid || saving} className="bg-accent hover:bg-accent/90 glow-teal">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4 mr-1.5" />}
            Сменить пароль
          </Button>
        </div>
      </div>
    </Card>
  )
}

function PasswordStrength({ password }: { password: string }) {
  const checks = [
    { label: 'Длина ≥ 6', pass: password.length >= 6 },
    { label: 'Цифра', pass: /\d/.test(password) },
    { label: 'Заглавная', pass: /[A-ZА-Я]/.test(password) },
    { label: 'Спецсимвол', pass: /[^A-Za-zА-Яа-я0-9]/.test(password) },
  ]
  const score = checks.filter((c) => c.pass).length
  const labels = ['Слабый', 'Слабый', 'Средний', 'Хороший', 'Надёжный']
  const colors = ['bg-red-500', 'bg-red-500', 'bg-amber-500', 'bg-accent', 'bg-emerald-500']

  return (
    <div className="p-3 rounded-md bg-muted/20 border border-border/30">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground">Надёжность:</span>
        <span className={cn('text-[10px] font-heading font-semibold', score <= 1 ? 'text-red-400' : score === 2 ? 'text-amber-400' : score === 3 ? 'text-accent' : 'text-emerald-400')}>
          {labels[score]}
        </span>
        <div className="flex-1 flex gap-1">
          {checks.map((c, i) => (
            <div key={i} className={cn('h-1 flex-1 rounded-full', i < score ? colors[score] : 'bg-muted')} />
          ))}
        </div>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {checks.map((c, i) => (
          <span key={i} className={cn('text-[9px] px-1.5 py-0.5 rounded', c.pass ? 'bg-emerald-500/15 text-emerald-300' : 'bg-muted/40 text-muted-foreground')}>
            {c.pass ? '✓' : '○'} {c.label}
          </span>
        ))}
      </div>
    </div>
  )
}
