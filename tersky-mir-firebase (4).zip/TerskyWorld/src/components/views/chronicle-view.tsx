'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { BookOpen, ChevronRight, Scroll, Feather } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { IconGridSkeleton } from '@/components/shared/skeletons'
import { Markdown } from '@/components/shared/markdown'
import { CHRONICLE_CATEGORIES } from '@/lib/constants'

interface Article {
  id: string
  title: string
  content: string
  category: string
  era?: string | null
  order: number
  createdAt: string
  author: { name: string }
}

export function ChronicleView() {
  const [selected, setSelected] = useState<Article | null>(null)

  const { data, isLoading } = useQuery<{ articles: Article[] }>({
    queryKey: ['chronicle'],
    queryFn: async () => (await fetch('/api/chronicle')).json(),
  })

  const articles = data?.articles || []

  if (selected) {
    return (
      <div className="space-y-4">
        <button onClick={() => setSelected(null)} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
          <ChevronRight className="h-3 w-3 rotate-180" /> Назад к летописи
        </button>
        <Card className="ornate-border bg-card/40 border-border/40 p-6">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">
              {CHRONICLE_CATEGORIES[selected.category] || selected.category}
            </Badge>
            {selected.era && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">{selected.era}</Badge>}
          </div>
          <h1 className="font-heading text-2xl font-bold text-foreground text-glow mb-2">{selected.title}</h1>
          <div className="ornament-divider opacity-30 mb-4" />
          <Markdown content={selected.content} />
          <div className="mt-4 pt-3 border-t border-border/30 text-xs text-muted-foreground">
            Летописец: {selected.author.name}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <PageHeader title="Хроника" description="Летопись событий Терского Мира" />

      {isLoading ? (
        <IconGridSkeleton count={4} />
      ) : articles.length === 0 ? (
        <EmptyState icon={BookOpen} title="Летопись пуста" description="Хроника событий ещё не начата. Летописцы собирают предания и легенды прошедших эпох." />
      ) : (
        <div className="space-y-3">
          {articles.map((a) => (
            <Card
              key={a.id}
              onClick={() => setSelected(a)}
              className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group flex items-center gap-4"
            >
              <div className="h-10 w-10 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
                <Scroll className="h-4 w-4 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {a.era && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">{a.era}</Badge>}
                  <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">
                    {CHRONICLE_CATEGORIES[a.category] || a.category}
                  </Badge>
                </div>
                <h3 className="font-heading text-base text-foreground group-hover:text-accent transition-colors">{a.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-1 mt-0.5">{a.content.replace(/[#*`]/g, '').slice(0, 100)}...</p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-accent shrink-0" />
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
