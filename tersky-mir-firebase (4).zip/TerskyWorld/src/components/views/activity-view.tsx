'use client'

import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Activity, Shield, Newspaper, Coins, MessageSquare, ScrollText,
  ChevronRight, Clock, Crown, Filter, TrendingUp, TrendingDown,
  Pin, FileText, Eye, X,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { PageHeader, EmptyState } from '@/components/shared/ui-bits'
import { TimelineSkeleton } from '@/components/shared/skeletons'
import { Markdown } from '@/components/shared/markdown'
import { STAT_SECTIONS, NEWS_CATEGORIES } from '@/lib/constants'
import { useAppStore } from '@/stores/app-store'
import { cn } from '@/lib/utils'

type EventType = 'post' | 'verdict' | 'news' | 'stat_change' | 'chat_message'

interface TimelineEvent {
  id: string
  type: EventType
  createdAt: string
  [key: string]: unknown
}

interface ActivityData {
  events: TimelineEvent[]
  total: number
  counts: {
    posts: number
    verdicts: number
    news: number
    statChanges: number
    messages: number
  }
}

const TYPE_META: Record<EventType, {
  label: string
  icon: React.ComponentType<{ className?: string }>
  color: string
  iconColor: string
  iconBg: string
}> = {
  post: { label: 'Пост', icon: ScrollText, color: 'text-foreground', iconColor: 'text-accent', iconBg: 'bg-accent/15 border-accent/30' },
  verdict: { label: 'Вердикт', icon: Shield, color: 'text-emerald-300', iconColor: 'text-emerald-400', iconBg: 'bg-emerald-500/15 border-emerald-500/30' },
  news: { label: 'Весть', icon: Newspaper, color: 'text-teal-300', iconColor: 'text-teal-300', iconBg: 'bg-teal-500/15 border-teal-500/30' },
  stat_change: { label: 'Изменение статов', icon: Coins, color: 'text-amber-300', iconColor: 'text-amber-400', iconBg: 'bg-amber-500/15 border-amber-500/30' },
  chat_message: { label: 'Сообщение', icon: MessageSquare, color: 'text-purple-300', iconColor: 'text-purple-300', iconBg: 'bg-purple-500/15 border-purple-500/30' },
}

const FILTERS: Array<{ key: EventType | 'ALL'; label: string }> = [
  { key: 'ALL', label: 'Все' },
  { key: 'post', label: 'Посты' },
  { key: 'verdict', label: 'Вердикты' },
  { key: 'stat_change', label: 'Статы' },
  { key: 'news', label: 'Вести' },
  { key: 'chat_message', label: 'Чаты' },
]

export function ActivityView() {
  const { setView } = useAppStore()
  const [filter, setFilter] = useState<EventType | 'ALL'>('ALL')
  const [selectedEvent, setSelectedEvent] = useState<TimelineEvent | null>(null)

  const { data, isLoading } = useQuery<ActivityData>({
    queryKey: ['activity'],
    queryFn: async () => (await fetch('/api/activity?limit=50')).json(),
    refetchInterval: 30000,
  })

  const events = data?.events || []
  const filtered = useMemo(
    () => filter === 'ALL' ? events : events.filter((e) => e.type === filter),
    [events, filter]
  )

  // Группировка по дням
  const grouped = useMemo(() => {
    const groups: Record<string, TimelineEvent[]> = {}
    for (const e of filtered) {
      const date = new Date(e.createdAt)
      const key = date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })
      if (!groups[key]) groups[key] = []
      groups[key].push(e)
    }
    return groups
  }, [filtered])

  return (
    <div className="space-y-5">
      <PageHeader
        title="Летопись деяний"
        description="Хронология всех событий: посты, вердикты, вести, изменения статов"
      />

      {/* Summary cards */}
      {data && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <SummaryCard icon={ScrollText} label="Постов" value={data.counts.posts} color="bg-accent/15 text-accent" />
          <SummaryCard icon={Shield} label="Вердиктов" value={data.counts.verdicts} color="bg-emerald-500/15 text-emerald-400" />
          <SummaryCard icon={Coins} label="Изм. статов" value={data.counts.statChanges} color="bg-amber-500/15 text-amber-400" />
          <SummaryCard icon={Newspaper} label="Вестей" value={data.counts.news} color="bg-teal-500/15 text-teal-300" />
          <SummaryCard icon={MessageSquare} label="Сообщений" value={data.counts.messages} color="bg-purple-500/15 text-purple-300" />
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="h-3.5 w-3.5 text-muted-foreground" />
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              'px-3 py-1.5 rounded-md text-xs font-heading tracking-wide border transition-all',
              filter === f.key
                ? 'bg-accent text-accent-foreground border-accent shadow-sm'
                : 'border-border/40 text-muted-foreground hover:text-foreground hover:border-accent/30'
            )}
          >
            {f.label}
            {f.key !== 'ALL' && (
              <span className="ml-1.5 opacity-60">
                {events.filter((e) => e.type === f.key).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Timeline */}
      {isLoading ? (
        <TimelineSkeleton />
      ) : filtered.length === 0 ? (
        <EmptyState icon={Activity} title="Событий нет" description="В выбранной категории событий пока нет. Загляните позже или смените фильтр." />
      ) : (
        <div className="space-y-6">
          {Object.entries(grouped).map(([dateKey, dayEvents]) => (
            <div key={dateKey} className="relative">
              {/* Day header */}
              <div className="flex items-center gap-3 mb-3">
                <div className="h-px flex-1 bg-border/40" />
                <Badge variant="outline" className="text-[10px] font-heading tracking-widest uppercase border-accent/30 text-accent bg-accent/5 px-3 py-1">
                  {dateKey}
                </Badge>
                <div className="h-px flex-1 bg-border/40" />
              </div>

              {/* Events for this day */}
              <div className="relative pl-8">
                {/* Vertical line */}
                <div className="absolute left-3 top-0 bottom-0 w-px bg-border/40" />

                <div className="space-y-3">
                  {dayEvents.map((event, idx) => (
                    <TimelineEventCard
                      key={event.id}
                      event={event}
                      isFirst={idx === 0}
                      onClick={() => setSelectedEvent(event)}
                      onNavigate={(view) => setView(view)}
                    />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Detail modal */}
      <AnimatePresence>
        {selectedEvent && (
          <EventDetailModal
            event={selectedEvent}
            onClose={() => setSelectedEvent(null)}
            onNavigate={(view) => { setView(view); setSelectedEvent(null) }}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

function SummaryCard({
  icon: Icon, label, value, color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  color: string
}) {
  return (
    <Card className="border-border/40 bg-card/30 p-3 flex items-center gap-3">
      <div className={cn('h-9 w-9 rounded-md border flex items-center justify-center shrink-0', color)}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="font-heading text-lg font-bold text-foreground leading-none">{value}</p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mt-0.5 truncate">{label}</p>
      </div>
    </Card>
  )
}

function TimelineEventCard({
  event, isFirst, onClick, onNavigate,
}: {
  event: TimelineEvent
  isFirst: boolean
  onClick: () => void
  onNavigate: (view: 'posts' | 'news' | 'chats' | 'my-faction') => void
}) {
  const meta = TYPE_META[event.type]
  const Icon = meta.icon

  const time = new Date(event.createdAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })

  return (
    <motion.div
      initial={isFirst ? { opacity: 0, x: -10 } : false}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.2 }}
      className="relative"
    >
      {/* Dot on the line */}
      <div className={cn(
        'absolute -left-[1.4rem] top-4 h-3 w-3 rounded-full border-2 border-background',
        meta.iconBg.split(' ')[0].replace('/15', '/80')
      )} />

      <Card
        onClick={onClick}
        className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-3 group card-hover-lift"
      >
        <div className="flex items-start gap-3">
          <div className={cn('h-8 w-8 rounded-md border flex items-center justify-center shrink-0', meta.iconBg)}>
            <Icon className={cn('h-3.5 w-3.5', meta.iconColor)} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5 flex-wrap">
              <span className={cn('text-[10px] uppercase tracking-wider font-heading', meta.color)}>
                {meta.label}
              </span>
              {'faction' in event && event.faction && (
                <Badge variant="outline" className="text-[9px] border-accent/30 text-accent">
                  {event.faction.name}
                </Badge>
              )}
              {'category' in event && (
                <Badge variant="outline" className={cn('text-[9px]', NEWS_CATEGORIES[event.category as string]?.color || '')}>
                  {NEWS_CATEGORIES[event.category as string]?.label || event.category}
                </Badge>
              )}
              {'isPinned' in event && event.isPinned && (
                <Pin className="h-2.5 w-2.5 text-accent" />
              )}
              <span className="text-[10px] text-muted-foreground/60 ml-auto flex items-center gap-1">
                <Clock className="h-2.5 w-2.5" /> {time}
              </span>
            </div>
            <EventPreview event={event} />
          </div>
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/40 group-hover:text-accent shrink-0 mt-1" />
        </div>
      </Card>
    </motion.div>
  )
}

function EventPreview({ event }: { event: TimelineEvent }) {
  switch (event.type) {
    case 'post':
      return (
        <>
          <h4 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">
            {event.title as string}
          </h4>
          <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
            {String(event.content || '').slice(0, 120)}
          </p>
          <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground/70">
            <span>Автор: {event.author?.name}</span>
            {'turnNumber' in event && event.turnNumber && <span>· Ход {event.turnNumber}</span>}
            {'status' in event && (
              <Badge variant="outline" className={cn(
                'text-[9px]',
                event.status === 'PENDING' ? 'border-amber-500/30 text-amber-300' : 'border-emerald-500/30 text-emerald-300'
              )}>
                {event.status === 'PENDING' ? 'Ожидает' : 'Вердикт'}
              </Badge>
            )}
          </div>
        </>
      )
    case 'verdict':
      return (
        <>
          <h4 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">
            Вердикт: {event.postTitle as string}
          </h4>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
            {String(event.roleplayText || '').slice(0, 160)}
          </p>
          {'statChangesCount' in event && event.statChangesCount > 0 && (
            <div className="flex items-center gap-1 mt-1">
              <Coins className="h-2.5 w-2.5 text-accent" />
              <span className="text-[10px] text-accent">{event.statChangesCount} секц. статов</span>
            </div>
          )}
          <span className="text-[10px] text-muted-foreground/70">Админ: {event.admin?.name}</span>
        </>
      )
    case 'news':
      return (
        <>
          <h4 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">
            {event.title as string}
          </h4>
          {event.excerpt && (
            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
              {String(event.excerpt).slice(0, 140)}
            </p>
          )}
          <span className="text-[10px] text-muted-foreground/70">Автор: {event.author?.name}</span>
        </>
      )
    case 'stat_change':
      return (
        <>
          <h4 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors">
            {STAT_SECTIONS.find((s) => s.key === event.sectionKey)?.title || event.sectionKey}
            <span className="text-muted-foreground ml-2 text-[10px]">· {event.changeType}</span>
          </h4>
          {event.verdictPost && (
            <p className="text-xs text-muted-foreground mt-0.5">Пост: {event.verdictPost}</p>
          )}
          <span className="text-[10px] text-muted-foreground/70">Админ: {event.admin?.name}</span>
        </>
      )
    case 'chat_message':
      return (
        <>
          <p className="text-sm text-foreground group-hover:text-accent transition-colors">
            <span className="font-heading text-accent">{event.user?.name}</span>
            <span className="text-muted-foreground"> в «{event.chatRoom?.name}»</span>
          </p>
          <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
            {String(event.content || '').slice(0, 120)}
          </p>
        </>
      )
    default:
      return null
  }
}

function EventDetailModal({
  event, onClose, onNavigate,
}: {
  event: TimelineEvent
  onClose: () => void
  onNavigate: (view: 'posts' | 'news' | 'chats' | 'my-faction') => void
}) {
  const meta = TYPE_META[event.type]
  const Icon = meta.icon

  const fullDate = new Date(event.createdAt).toLocaleString('ru-RU', {
    day: 'numeric', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })

  const navigateTo = () => {
    if (event.type === 'post' || event.type === 'verdict') onNavigate('posts')
    else if (event.type === 'news') onNavigate('news')
    else if (event.type === 'chat_message') onNavigate('chats')
    else if (event.type === 'stat_change') onNavigate('my-faction')
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm vignette" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.97 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-lg rounded-lg border border-border/60 bg-card/95 backdrop-blur-xl shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border/40 bg-secondary/20">
          <div className="flex items-center gap-2">
            <div className={cn('h-8 w-8 rounded-md border flex items-center justify-center', meta.iconBg)}>
              <Icon className={cn('h-4 w-4', meta.iconColor)} />
            </div>
            <div>
              <h2 className="font-heading text-base font-semibold text-foreground tracking-wide">
                {meta.label}
              </h2>
              <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                <Clock className="h-2.5 w-2.5" /> {fullDate}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="h-8 w-8 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 max-h-[60vh] overflow-y-auto custom-scroll">
          <EventFullContent event={event} />
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-border/40 bg-secondary/20 flex items-center justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={onClose}>Закрыть</Button>
          <Button size="sm" onClick={navigateTo} className="bg-accent hover:bg-accent/90">
            <Eye className="h-3.5 w-3.5 mr-1.5" /> Открыть раздел
          </Button>
        </div>
      </motion.div>
    </motion.div>
  )
}

function EventFullContent({ event }: { event: TimelineEvent }) {
  switch (event.type) {
    case 'post':
      return (
        <div className="space-y-3">
          <h3 className="font-heading text-lg font-semibold text-foreground">{event.title as string}</h3>
          {'turnNumber' in event && event.turnNumber && (
            <Badge variant="outline" className="text-[10px]">Ход {event.turnNumber}</Badge>
          )}
          <div className="ornament-divider opacity-30" />
          <div className="prose prose-invert max-w-none text-sm text-foreground/90">
            <Markdown content={String(event.content || '')} />
          </div>
        </div>
      )
    case 'verdict':
      return (
        <div className="space-y-3">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Пост</p>
            <h3 className="font-heading text-base font-semibold text-foreground">{event.postTitle as string}</h3>
          </div>
          <div className="ornament-divider opacity-30" />
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Ролевая часть вердикта</p>
            <div className="prose prose-invert max-w-none text-sm text-foreground/90">
              <Markdown content={String(event.roleplayText || '')} />
            </div>
          </div>
          {event.technicalText && (
            <div className="p-3 rounded-md bg-muted/20 border border-border/30">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Техническая часть</p>
              <p className="text-sm text-foreground/80 whitespace-pre-wrap">{String(event.technicalText)}</p>
            </div>
          )}
          {'statChangesCount' in event && event.statChangesCount > 0 && (
            <div className="flex items-center gap-2 p-3 rounded-md bg-accent/10 border border-accent/30">
              <Coins className="h-4 w-4 text-accent" />
              <span className="text-sm text-accent">Обновлено секций статистики: {event.statChangesCount}</span>
            </div>
          )}
        </div>
      )
    case 'news':
      return (
        <div className="space-y-3">
          <h3 className="font-heading text-lg font-semibold text-foreground">{event.title as string}</h3>
          {event.excerpt && <p className="text-sm text-muted-foreground italic">{String(event.excerpt)}</p>}
          <div className="ornament-divider opacity-30" />
          <p className="text-sm text-foreground/70">Откройте раздел «Вести мира» для полного текста</p>
        </div>
      )
    case 'stat_change':
      return (
        <div className="space-y-3">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Секция</p>
            <h3 className="font-heading text-base font-semibold text-foreground">
              {STAT_SECTIONS.find((s) => s.key === event.sectionKey)?.title || event.sectionKey}
            </h3>
          </div>
          <div className="ornament-divider opacity-30" />
          {event.verdictPost && (
            <p className="text-sm text-muted-foreground">Связано с постом: <span className="text-foreground">{event.verdictPost}</span></p>
          )}
          <div className="grid grid-cols-2 gap-2">
            <div className="p-3 rounded-md bg-red-500/10 border border-red-500/20">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Было</p>
              <pre className="text-xs text-foreground/70 whitespace-pre-wrap break-words">
                {JSON.stringify(event.oldValue, null, 2).slice(0, 300)}
              </pre>
            </div>
            <div className="p-3 rounded-md bg-emerald-500/10 border border-emerald-500/20">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">Стало</p>
              <pre className="text-xs text-foreground/70 whitespace-pre-wrap break-words">
                {JSON.stringify(event.newValue, null, 2).slice(0, 300)}
              </pre>
            </div>
          </div>
        </div>
      )
    case 'chat_message':
      return (
        <div className="space-y-3">
          <p className="text-sm text-foreground">
            <span className="font-heading text-accent">{event.user?.name}</span> в чате «{event.chatRoom?.name}»
          </p>
          <div className="ornament-divider opacity-30" />
          <div className="p-3 rounded-md bg-muted/20 border border-border/30">
            <p className="text-sm text-foreground/90">{String(event.content)}</p>
          </div>
        </div>
      )
    default:
      return null
  }
}
