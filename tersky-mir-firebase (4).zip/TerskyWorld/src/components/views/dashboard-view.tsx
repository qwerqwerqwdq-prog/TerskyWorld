'use client'

import { useQuery } from '@tanstack/react-query'
import {
  Newspaper, Shield, ScrollText, Swords, MessageSquare, Clock, ChevronRight,
  Coins, TrendingUp, TrendingDown, History, Sparkles, Crown,
  Users, Building2, Flag, HeartPulse, Trophy,
} from 'lucide-react'
import { useAppStore } from '@/stores/app-store'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Markdown } from '@/components/shared/markdown'
import { EmptyState } from '@/components/shared/ui-bits'
import { STAT_SECTIONS } from '@/lib/constants'
import { cn } from '@/lib/utils'

interface NewsItem {
  id: string
  title: string
  excerpt?: string | null
  content: string
  category: string
  isPinned: boolean
  createdAt: string
  author: { name: string }
}

interface Post {
  id: string
  title: string
  status: string
  createdAt: string
  verdict?: {
    id: string
    roleplayText: string
    statChanges?: string | null
    createdAt: string
    admin: { id: string; name: string }
  } | null
}

interface FactionStat {
  sectionKey: string
  sectionTitle: string
  content: string
}

interface Faction {
  id: string
  name: string
  bannerColor?: string | null
  isApproved: boolean
  stats: FactionStat[]
}

interface SessionUser {
  id: string
  name: string
  role: string
  faction?: { id: string; name: string; isApproved: boolean } | null
}

export function DashboardView() {
  const { setView } = useAppStore()
  const { data: session } = useQuery<SessionUser>({
    queryKey: ['session'],
    queryFn: async () => (await fetch('/api/session')).json().then((d) => d.user),
  })

  const { data: newsData } = useQuery<{ news: NewsItem[] }>({
    queryKey: ['news'],
    queryFn: async () => (await fetch('/api/news')).json(),
  })

  const { data: postsData } = useQuery<{ posts: Post[] }>({
    queryKey: ['my-posts'],
    queryFn: async () => (await fetch('/api/posts')).json(),
  })

  // Faction stats for health widget
  const { data: factionData } = useQuery<{ faction: Faction | null }>({
    queryKey: ['faction', session?.faction?.id],
    queryFn: async () => {
      if (!session?.faction?.id) return { faction: null }
      const res = await fetch(`/api/factions/${session.faction.id}`)
      if (!res.ok) return { faction: null }
      return res.json()
    },
    enabled: !!session?.faction?.id,
  })

  // Achievements summary
  const { data: achievementsData } = useQuery<{ summary: { unlocked: number; total: number; percent: number } }>({
    queryKey: ['achievements'],
    queryFn: async () => (await fetch('/api/achievements')).json(),
  })
  const achievementsSummary = achievementsData?.summary

  const faction = factionData?.faction
  const statsByKey: Record<string, Record<string, unknown>> = {}
  for (const s of faction?.stats || []) {
    try { statsByKey[s.sectionKey] = JSON.parse(s.content) } catch { /* ignore */ }
  }

  const recentNews = newsData?.news?.slice(0, 5) || []
  const myPosts = postsData?.posts || []
  const pendingPosts = myPosts.filter((p) => p.status === 'PENDING')
  const verdictedPosts = myPosts.filter((p) => p.status === 'VERDICTED')

  // Последние вердикты (с сортировкой по дате вердикта)
  const recentVerdicts = verdictedPosts
    .filter((p) => p.verdict)
    .sort((a, b) => new Date(b.verdict!.createdAt).getTime() - new Date(a.verdict!.createdAt).getTime())
    .slice(0, 3)

  // Подсчёт общего количества изменений статов
  const totalStatChanges = recentVerdicts.reduce((acc, p) => {
    if (!p.verdict?.statChanges) return acc
    try {
      const changes = JSON.parse(p.verdict.statChanges) as unknown[]
      return acc + changes.length
    } catch { return acc }
  }, 0)

  const greeting = (() => {
    const h = new Date().getHours()
    if (h < 6) return 'Доброй ночи'
    if (h < 12) return 'Доброе утро'
    if (h < 18) return 'Добрый день'
    return 'Добрый вечер'
  })()

  return (
    <div className="space-y-6">
      {/* Приветствие */}
      <div className="ornate-border ambient-gradient bg-gradient-to-br from-card/60 to-secondary/30 border border-border/40 rounded-lg p-6 relative overflow-hidden">
        <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-accent/10 blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 right-0 h-px shimmer-bar opacity-50" />
        <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground font-heading tracking-wider uppercase">
              {greeting}, правитель
            </p>
            <h1 className="font-heading text-3xl font-bold text-foreground text-glow mt-1">
              {session?.name || 'Гость'}
            </h1>
            {session?.faction ? (
              <div className="flex items-center gap-2 mt-2">
                <Shield className="h-4 w-4 text-accent" />
                <span className="text-foreground">{session.faction.name}</span>
                {session.faction.isApproved ? (
                  <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">Утверждено</Badge>
                ) : (
                  <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30">На утверждении</Badge>
                )}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground mt-2">
                Зарегистрируйте своё княжество, чтобы начать игру
              </p>
            )}
          </div>
          {!session?.faction && (
            <button
              onClick={() => setView('my-faction')}
              className="px-4 py-2.5 rounded-md bg-accent text-accent-foreground font-heading tracking-wide hover:bg-accent/90 transition-colors glow-teal"
            >
              Создать княжество
            </button>
          )}
        </div>
      </div>

      {/* Сетка статистики */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard
          icon={<ScrollText className="h-4 w-4" />}
          label="Всего постов"
          value={myPosts.length}
          onClick={() => setView('posts')}
        />
        <StatCard
          icon={<Clock className="h-4 w-4" />}
          label="Ожидают вердикта"
          value={pendingPosts.length}
          accent={pendingPosts.length > 0 ? 'amber' : 'default'}
          onClick={() => setView('posts')}
        />
        <StatCard
          icon={<Shield className="h-4 w-4" />}
          label="Вердиктов получено"
          value={verdictedPosts.length}
          accent={verdictedPosts.length > 0 ? 'emerald' : 'default'}
          onClick={() => setView('posts')}
        />
        <StatCard
          icon={<Coins className="h-4 w-4" />}
          label="Изменений статов"
          value={totalStatChanges}
          accent={totalStatChanges > 0 ? 'emerald' : 'default'}
          onClick={() => setView('my-faction')}
        />
      </div>

      {/* Здоровье государства — виджет с ключевыми метриками */}
      {faction && <StateHealthWidget statsByKey={statsByKey} faction={faction} onClick={() => setView('my-faction')} />}

      {/* Достижения — мини-виджет */}
      {achievementsSummary && (
        <Card
          onClick={() => setView('achievements')}
          className="ornate-border border-border/40 bg-gradient-to-br from-amber-500/5 to-card/40 hover:border-amber-500/30 transition-all cursor-pointer p-4 group card-hover-lift"
        >
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-md bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Trophy className="h-6 w-6 text-amber-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-heading text-sm font-semibold text-foreground group-hover:text-amber-300 transition-colors">Достижения</h3>
                <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 text-[9px]">
                  {achievementsSummary.unlocked}/{achievementsSummary.total}
                </Badge>
              </div>
              <div className="h-1.5 rounded-full bg-muted/40 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all duration-500"
                  style={{ width: `${Math.max(2, achievementsSummary.percent)}%` }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">{achievementsSummary.percent}% открыто</p>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-amber-300 shrink-0" />
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Последние вердикты (2/3 ширины) */}
        <Card className="lg:col-span-2 border-border/40 bg-card/40">
          <div className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-accent" />
                <h2 className="font-heading text-lg font-semibold tracking-wide">Последние вердикты</h2>
                {recentVerdicts.length > 0 && (
                  <Badge variant="outline" className="text-[10px] border-accent/30 text-accent">{recentVerdicts.length}</Badge>
                )}
              </div>
              <button
                onClick={() => setView('posts')}
                className="text-xs text-muted-foreground hover:text-accent flex items-center gap-1 transition-colors"
              >
                Все посты <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            {recentVerdicts.length === 0 ? (
              <EmptyState icon={Shield} title="Вердиктов пока нет" description="После вынесения вердиктов они появятся здесь вместе с изменениями статистики" />
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1 custom-scroll">
                {recentVerdicts.map((p) => (
                  <RecentVerdictCard key={p.id} post={p} onClick={() => setView('posts')} />
                ))}
              </div>
            )}
          </div>
        </Card>

        {/* Последние вести (1/3 ширины) */}
        <Card className="border-border/40 bg-card/40">
          <div className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Newspaper className="h-4 w-4 text-accent" />
                <h2 className="font-heading text-base font-semibold tracking-wide">Вести мира</h2>
              </div>
              <button
                onClick={() => setView('news')}
                className="text-xs text-muted-foreground hover:text-accent flex items-center gap-1 transition-colors"
              >
                Все <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            {recentNews.length === 0 ? (
              <EmptyState icon={Newspaper} title="Вестей нет" description="Новости появятся здесь" />
            ) : (
              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1 custom-scroll">
                {recentNews.map((n) => (
                  <div
                    key={n.id}
                    className="p-2.5 rounded-md bg-muted/20 border border-border/30 hover:border-accent/30 transition-colors"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {n.isPinned && <Badge variant="outline" className="text-accent border-accent/40 text-[9px]">📌</Badge>}
                      <Badge variant="outline" className="text-[9px] border-border/40 text-muted-foreground">{n.category}</Badge>
                      <span className="text-[9px] text-muted-foreground/60 ml-auto">
                        {new Date(n.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                      </span>
                    </div>
                    <h3 className="font-heading text-xs text-foreground mb-0.5 leading-tight">{n.title}</h3>
                    {n.excerpt && <p className="text-[11px] text-muted-foreground line-clamp-2">{n.excerpt}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Быстрый доступ */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <QuickLink icon={<Shield />} label="Княжество" onClick={() => setView('my-faction')} />
        <QuickLink icon={<ScrollText />} label="Посты" onClick={() => setView('posts')} badge={pendingPosts.length} />
        <QuickLink icon={<MessageSquare />} label="Переговоры" onClick={() => setView('chats')} />
        <QuickLink icon={<Swords />} label="Война" onClick={() => setView('battles')} />
        <QuickLink icon={<Trophy />} label="Достижения" onClick={() => setView('achievements')} />
        <QuickLink icon={<Crown />} label="Зал славы" onClick={() => setView('leaderboard')} />
        <QuickLink icon={<History />} label="Летопись" onClick={() => setView('activity')} />
      </div>
    </div>
  )
}

function StatCard({
  icon, label, value, onClick, accent = 'default',
}: {
  icon: React.ReactNode; label: string; value: number; onClick: () => void; accent?: 'default' | 'amber' | 'emerald'
}) {
  const accentBg = accent === 'amber' ? 'bg-amber-500/15 text-amber-400' : accent === 'emerald' ? 'bg-emerald-500/15 text-emerald-400' : 'bg-accent/15 text-accent'
  return (
    <button
      onClick={onClick}
      className="text-left p-4 rounded-md border border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all group relative overflow-hidden"
    >
      <div className="absolute -bottom-8 -right-8 h-20 w-20 rounded-full bg-accent/5 blur-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
      <div className="flex items-center justify-between mb-2 relative">
        <div className={cn('h-8 w-8 rounded-md flex items-center justify-center', accentBg)}>
          {icon}
        </div>
      </div>
      <p className="font-heading text-2xl font-bold text-foreground relative">{value}</p>
      <p className="text-[11px] text-muted-foreground uppercase tracking-wider font-heading mt-0.5 relative">{label}</p>
    </button>
  )
}

function QuickLink({ icon, label, onClick, badge }: { icon: React.ReactNode; label: string; onClick: () => void; badge?: number }) {
  return (
    <button
      onClick={onClick}
      className="relative flex flex-col items-center gap-2 p-4 rounded-md border border-border/40 bg-card/30 hover:bg-card/50 hover:border-accent/30 transition-all group"
    >
      {badge !== undefined && badge > 0 && (
        <span className="absolute top-2 right-2 h-4 min-w-4 px-1 rounded-full bg-amber-500 text-amber-foreground text-[9px] font-bold flex items-center justify-center">
          {badge}
        </span>
      )}
      <div className="h-10 w-10 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center text-accent group-hover:bg-accent/20 transition-colors">
        {icon}
      </div>
      <span className="text-xs font-heading tracking-wide text-muted-foreground group-hover:text-foreground">{label}</span>
    </button>
  )
}

// Карточка последнего вердикта с превью изменений статов
function RecentVerdictCard({ post, onClick }: { post: Post; onClick: () => void }) {
  const verdict = post.verdict!
  // Парсим изменения
  const changes = (() => {
    if (!verdict.statChanges) return []
    try { return JSON.parse(verdict.statChanges) as Array<{ sectionKey: string; sectionTitle?: string }> } catch { return [] }
  })()

  return (
    <button
      onClick={onClick}
      className="w-full text-left p-3 rounded-md bg-muted/15 border border-border/30 hover:border-accent/40 transition-all group"
    >
      <div className="flex items-center gap-2 mb-2 flex-wrap">
        <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[9px] gap-1">
          <Shield className="h-2.5 w-2.5" /> Вердикт
        </Badge>
        <span className="text-[10px] text-muted-foreground/70 ml-auto">
          {new Date(verdict.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
      <h3 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate mb-1">
        {post.title}
      </h3>
      <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
        {verdict.roleplayText.replace(/[#*`_]/g, '').slice(0, 180)}
      </p>

      {/* Превью изменений статов */}
      {changes.length > 0 && (
        <div className="flex items-center gap-1.5 flex-wrap mt-2 pt-2 border-t border-border/20">
          <Coins className="h-3 w-3 text-accent shrink-0" />
          <span className="text-[10px] text-muted-foreground">Обновлено секций:</span>
          {changes.slice(0, 4).map((c, i) => {
            const def = STAT_SECTIONS.find((s) => s.key === c.sectionKey)
            return (
              <Badge key={i} variant="outline" className="text-[9px] border-accent/30 text-accent">
                {def?.title || c.sectionTitle || c.sectionKey}
              </Badge>
            )
          })}
          {changes.length > 4 && (
            <span className="text-[9px] text-muted-foreground">+{changes.length - 4}</span>
          )}
        </div>
      )}
    </button>
  )
}

// === Виджет «Здоровье государства» — ключевые метрики с прогресс-барами ===
function StateHealthWidget({
  statsByKey,
  faction,
  onClick,
}: {
  statsByKey: Record<string, Record<string, unknown>>
  faction: { name: string; bannerColor?: string | null; isApproved: boolean }
  onClick: () => void
}) {
  // Извлекаем ключевые метрики
  const treasury = statsByKey['TREASURY'] || {}
  const army = statsByKey['ARMY'] || {}
  const population = statsByKey['POPULATION'] || {}
  const governance = statsByKey['GOVERNANCE'] || {}
  const horses = statsByKey['HORSES'] || {}

  const balance = Number(treasury.balance ?? 0)
  const reserve = Number(treasury.reserve ?? 0)
  const totalSoldiers = Number(army.meleeInfantry ?? 0) + Number(army.rangedInfantry ?? 0) + Number(army.cavalry ?? 0) + Number(army.fleet ?? 0)
  const totalPop = Number(population.total ?? 0)
  const govRating = Number(governance.rating ?? 0)
  const horseTotal = Number(horses.total ?? 0)

  // «Индекс здоровья» — комплексная метрика (0-100)
  // Учитывает: баланс казны (вес 30), армия (25), население (20), управление (15), кони (10)
  const treasuryScore = Math.min(100, (balance / 100000) * 100)
  const armyScore = Math.min(100, (totalSoldiers / 10000) * 100)
  const popScore = Math.min(100, (totalPop / 100000) * 100)
  const govScore = govRating
  const horseScore = Math.min(100, (horseTotal / 10000) * 100)

  const healthIndex = Math.round(
    treasuryScore * 0.30 + armyScore * 0.25 + popScore * 0.20 + govScore * 0.15 + horseScore * 0.10
  )

  const healthLabel = healthIndex >= 75 ? 'Процветает' : healthIndex >= 50 ? 'Стабильно' : healthIndex >= 25 ? 'Напряжённо' : 'Кризис'
  const healthColor = healthIndex >= 75 ? 'text-emerald-300' : healthIndex >= 50 ? 'text-accent' : healthIndex >= 25 ? 'text-amber-300' : 'text-red-300'
  const healthBg = healthIndex >= 75 ? 'bg-emerald-500' : healthIndex >= 50 ? 'bg-accent' : healthIndex >= 25 ? 'bg-amber-500' : 'bg-red-500'

  const metrics = [
    { label: 'Баланс казны', value: balance.toLocaleString('ru-RU'), unit: 'солей', score: treasuryScore, icon: Coins, color: 'bg-amber-500' },
    { label: 'Армия', value: totalSoldiers.toLocaleString('ru-RU'), unit: 'воинов', score: armyScore, icon: Swords, color: 'bg-red-500' },
    { label: 'Население', value: totalPop.toLocaleString('ru-RU'), unit: 'человек', score: popScore, icon: Users, color: 'bg-accent' },
    { label: 'Управление', value: `${govRating}`, unit: '%', score: govScore, icon: Crown, color: 'bg-purple-500' },
    { label: 'Коневодство', value: horseTotal.toLocaleString('ru-RU'), unit: 'голов', score: horseScore, icon: Sparkles, color: 'bg-teal-500' },
  ]

  return (
    <Card className="ornate-border border-border/40 bg-gradient-to-br from-card/50 to-secondary/20 p-5 relative overflow-hidden">
      <div
        className="absolute top-0 left-0 h-full w-1"
        style={{ background: faction.bannerColor || '#3a7d74' }}
      />
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center">
            <HeartPulse className="h-4 w-4 text-accent" />
          </div>
          <div>
            <h2 className="font-heading text-lg font-semibold text-foreground tracking-wide">Здоровье государства</h2>
            <p className="text-xs text-muted-foreground">{faction.name}</p>
          </div>
        </div>
        <button
          onClick={onClick}
          className="text-xs text-muted-foreground hover:text-accent flex items-center gap-1 transition-colors"
        >
          Все статы <ChevronRight className="h-3 w-3" />
        </button>
      </div>

      {/* Индекс здоровья (большой прогресс-бар) */}
      <div className="mb-4 p-3 rounded-md bg-background/40 border border-border/30">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground">Индекс здоровья</span>
          <span className={cn('font-heading text-2xl font-bold', healthColor)}>{healthIndex}<span className="text-sm text-muted-foreground">/100</span></span>
        </div>
        <div className="h-3 rounded-full bg-muted/40 overflow-hidden relative progress-glow">
          <div
            className={cn('h-full rounded-full transition-all duration-500', healthBg)}
            style={{ width: `${Math.max(2, healthIndex)}%` }}
          />
          {/* Отметки 25/50/75 */}
          {[25, 50, 75].map((mark) => (
            <div
              key={mark}
              className="absolute top-0 h-full w-px bg-background/40"
              style={{ left: `${mark}%` }}
            />
          ))}
        </div>
        <div className="flex items-center justify-between mt-1.5">
          <span className="text-[10px] text-muted-foreground/60">0</span>
          <span className={cn('text-xs font-heading font-semibold', healthColor)}>{healthLabel}</span>
          <span className="text-[10px] text-muted-foreground/60">100</span>
        </div>
      </div>

      {/* Метрики (сетка) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {metrics.map((m) => {
          const Icon = m.icon
          return (
            <div key={m.label} className="p-2.5 rounded-md bg-background/30 border border-border/20">
              <div className="flex items-center gap-1.5 mb-1.5">
                <Icon className="h-3 w-3 text-muted-foreground" />
                <span className="text-[9px] uppercase tracking-wider font-heading text-muted-foreground truncate">{m.label}</span>
              </div>
              <p className="font-heading text-sm font-bold text-foreground leading-tight">
                {m.value}<span className="text-[10px] text-muted-foreground ml-0.5">{m.unit}</span>
              </p>
              <div className="h-1 rounded-full bg-muted/40 overflow-hidden mt-1.5">
                <div className={cn('h-full rounded-full', m.color)} style={{ width: `${Math.max(2, Math.min(100, m.score))}%` }} />
              </div>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
