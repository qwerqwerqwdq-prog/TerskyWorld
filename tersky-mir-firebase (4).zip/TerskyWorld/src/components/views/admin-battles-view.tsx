'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Swords, Loader2, Plus, X, Save, Trash2, Shield, Clock,
  ChevronRight, Flag, Sword, Users, Ship, Footprints, Play, Pause,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'

interface Battle {
  id: string
  name: string
  description?: string | null
  location?: string | null
  turnNumber?: number | null
  status: string
  postDeadline?: string | null
  createdAt: string
  forces: Array<{
    id: string
    commander: string
    infantry: number
    archers: number
    cavalry: number
    fleet: number
    special?: string | null
    description?: string | null
    faction: { id: string; name: string; shortName?: string | null }
  }>
  participants: Array<{
    id: string
    hasPosted: boolean
    faction: { id: string; name: string }
  }>
}

interface Faction {
  id: string
  name: string
  shortName?: string | null
  isApproved: boolean
  user: { id: string; name: string }
}

const STATUS_LABELS: Record<string, string> = {
  PREPARING: 'Подготовка',
  ACTIVE: 'Активна',
  POSTING: 'Сбор постов',
  RESOLVED: 'Завершена',
}

export function AdminBattlesView() {
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)

  const { data, isLoading } = useQuery<{ battles: Battle[] }>({
    queryKey: ['admin-battles'],
    queryFn: async () => (await fetch('/api/battles')).json(),
  })

  const battles = data?.battles || []

  if (editingId) {
    const battle = battles.find((b) => b.id === editingId)
    if (battle) return <BattleEditor battle={battle} onClose={() => setEditingId(null)} />
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Управление баталиями"
        description="Создание и ведение военных действий"
        action={
          <Button onClick={() => setShowForm(true)} className="bg-accent hover:bg-accent/90 glow-teal">
            <Plus className="h-4 w-4 mr-1.5" /> Новая баталия
          </Button>
        }
      />

      {showForm && <BattleForm onClose={() => setShowForm(false)} />}

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : battles.length === 0 ? (
        <EmptyState icon={Swords} title="Баталий нет" description="Создайте первое военное столкновение. Здесь регистрируются конфликты между княжествами." />
      ) : (
        <div className="space-y-3">
          {battles.map((battle) => (
            <Card key={battle.id} className="border-border/40 bg-card/40 p-4">
              <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-md bg-red-500/15 border border-red-500/30 flex items-center justify-center shrink-0">
                  <Swords className="h-5 w-5 text-red-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-heading text-sm text-foreground">{battle.name}</h3>
                    <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">
                      {STATUS_LABELS[battle.status] || battle.status}
                    </Badge>
                    {battle.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {battle.turnNumber}</Badge>}
                  </div>
                  {battle.location && <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1"><Flag className="h-3 w-3" /> {battle.location}</p>}
                  <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground/70">
                    <span className="flex items-center gap-1"><Shield className="h-3 w-3" /> {battle.forces.length} фракций</span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" /> {battle.participants.filter(p => p.hasPosted).length}/{battle.participants.length} написали
                    </span>
                    {battle.postDeadline && (
                      <span className="flex items-center gap-1 text-amber-400"><Clock className="h-3 w-3" /> {new Date(battle.postDeadline).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                    )}
                  </div>
                </div>
                <div className="flex flex-col gap-1 shrink-0">
                  <Button variant="outline" size="sm" onClick={() => setEditingId(battle.id)} className="h-7 text-xs">
                    Редактировать <ChevronRight className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function BattleForm({ onClose }: { onClose: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    name: '',
    description: '',
    location: '',
    turnNumber: '',
    postDeadline: '',
  })

  const handleSave = async () => {
    if (form.name.length < 3) {
      toast({ title: 'Ошибка', description: 'Название минимум 3 символа', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/battles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          description: form.description || undefined,
          location: form.location || undefined,
          turnNumber: form.turnNumber ? Number(form.turnNumber) : undefined,
          postDeadline: form.postDeadline ? new Date(form.postDeadline).toISOString() : undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Баталия создана', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-battles'] })
      queryClient.invalidateQueries({ queryKey: ['battles'] })
      onClose()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="ornate-border bg-card/60 border-border/40 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading text-lg font-semibold text-foreground">Новая баталия</h2>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8"><X className="h-4 w-4" /></Button>
      </div>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Название *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Осада Рифа" className="bg-background/60" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Место</Label>
            <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Гойский остров" className="bg-background/60" />
          </div>
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Ход</Label>
            <Input type="number" value={form.turnNumber} onChange={(e) => setForm({ ...form, turnNumber: e.target.value })} className="bg-background/60" />
          </div>
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Дедлайн постов</Label>
          <Input
            type="datetime-local"
            value={form.postDeadline}
            onChange={(e) => setForm({ ...form, postDeadline: e.target.value })}
            className="bg-background/60"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Описание</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Описание военной ситуации..." className="bg-background/60 min-h-[100px]" />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={onClose}>Отмена</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-accent hover:bg-accent/90 glow-teal">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
            Создать
          </Button>
        </div>
      </div>
    </Card>
  )
}

function BattleEditor({ battle, onClose }: { battle: Battle; onClose: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [saving, setSaving] = useState(false)
  const [forces, setForces] = useState(battle.forces)
  const [participants, setParticipants] = useState<string[]>(battle.participants.map((p) => p.faction.id))
  const [status, setStatus] = useState(battle.status)

  const { data: factionsData } = useQuery<{ factions: Faction[] }>({
    queryKey: ['admin-factions'],
    queryFn: async () => (await fetch('/api/factions')).json(),
  })
  const factions = (factionsData?.factions || []).filter((f) => f.isApproved)

  const addForce = (factionId: string) => {
    const faction = factions.find((f) => f.id === factionId)
    if (!faction) return
    setForces([...forces, {
      id: `temp-${Date.now()}`,
      commander: '',
      infantry: 0,
      archers: 0,
      cavalry: 0,
      fleet: 0,
      special: '',
      description: '',
      faction: { id: faction.id, name: faction.name, shortName: faction.shortName },
    }])
    if (!participants.includes(factionId)) {
      setParticipants([...participants, factionId])
    }
  }

  const updateForce = (index: number, field: string, value: unknown) => {
    const newForces = [...forces]
    (newForces[index] as Record<string, unknown>)[field] = value
    setForces(newForces)
  }

  const removeForce = (index: number) => {
    const removed = forces[index]
    setForces(forces.filter((_, i) => i !== index))
    setParticipants(participants.filter((id) => id !== removed.faction.id))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch(`/api/battles/${battle.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          forces: forces.map((f) => ({
            factionId: f.faction.id,
            commander: f.commander,
            infantry: f.infantry,
            archers: f.archers,
            cavalry: f.cavalry,
            fleet: f.fleet,
            special: f.special || undefined,
            description: f.description || undefined,
          })),
          participants,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Баталия обновлена' })
      queryClient.invalidateQueries({ queryKey: ['admin-battles'] })
      queryClient.invalidateQueries({ queryKey: ['battles'] })
      onClose()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <button onClick={onClose} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
        <ChevronRight className="h-3 w-3 rotate-180" /> Назад к баталиям
      </button>

      <Card className="border-border/40 bg-card/40 p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-md bg-red-500/15 border border-red-500/30 flex items-center justify-center">
            <Swords className="h-5 w-5 text-red-400" />
          </div>
          <div className="flex-1">
            <h2 className="font-heading text-lg font-semibold text-foreground">{battle.name}</h2>
            <p className="text-xs text-muted-foreground">{battle.location || 'Место не указано'}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Статус баталии</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="PREPARING">Подготовка</SelectItem>
                <SelectItem value="ACTIVE">Активна</SelectItem>
                <SelectItem value="POSTING">Сбор постов</SelectItem>
                <SelectItem value="RESOLVED">Завершена</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Силы сторон</Label>
            {forces.length === 0 && <p className="text-xs text-muted-foreground italic">Силы не добавлены</p>}
            {forces.map((force, index) => (
              <div key={index} className="p-3 rounded-md bg-muted/20 border border-border/30 space-y-3">
                <div className="flex items-center gap-2">
                  <Flag className="h-4 w-4 text-accent" />
                  <span className="font-heading text-sm text-foreground flex-1">{force.faction.name}</span>
                  <Button variant="ghost" size="icon" onClick={() => removeForce(index)} className="h-7 w-7 text-muted-foreground hover:text-destructive">
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <Input
                  value={force.commander}
                  onChange={(e) => updateForce(index, 'commander', e.target.value)}
                  placeholder="Имя командира"
                  className="bg-background/60 h-8 text-sm"
                />
                <div className="grid grid-cols-4 gap-2">
                  <ForceInput icon={<Sword className="h-3 w-3" />} label="Пехота" value={force.infantry} onChange={(v) => updateForce(index, 'infantry', v)} />
                  <ForceInput icon={<Users className="h-3 w-3" />} label="Лучники" value={force.archers} onChange={(v) => updateForce(index, 'archers', v)} />
                  <ForceInput icon={<Footprints className="h-3 w-3" />} label="Кавалерия" value={force.cavalry} onChange={(v) => updateForce(index, 'cavalry', v)} />
                  <ForceInput icon={<Ship className="h-3 w-3" />} label="Флот" value={force.fleet} onChange={(v) => updateForce(index, 'fleet', v)} />
                </div>
              </div>
            ))}

            {/* Добавить фракцию */}
            <Select onValueChange={addForce}>
              <SelectTrigger className="bg-background/60 border-dashed">
                <Plus className="h-3.5 w-3.5 mr-1" /> Добавить фракцию
              </SelectTrigger>
              <SelectContent>
                {factions
                  .filter((f) => !forces.some((force) => force.faction.id === f.id))
                  .map((f) => (
                    <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={onClose}>Отмена</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-accent hover:bg-accent/90 glow-teal">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
              Сохранить
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

function ForceInput({ icon, label, value, onChange }: { icon: React.ReactNode; label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-1">
      <Label className="text-[9px] text-muted-foreground uppercase flex items-center gap-1">{icon} {label}</Label>
      <Input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="bg-background/60 h-8 text-sm"
      />
    </div>
  )
}
