'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Newspaper, ChevronRight, Clock, Loader2, Pin } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { BookmarkButton } from '@/components/shared/bookmark-button'
import { Markdown } from '@/components/shared/markdown'
import { NEWS_CATEGORIES } from '@/lib/constants'

interface NewsItem {
  id: string
  title: string
  content: string
  excerpt?: string | null
  category: string
  isPinned: boolean
  turnNumber?: number | null
  createdAt: string
  author: { name: string }
}

export function NewsView() {
  const [selected, setSelected] = useState<NewsItem | null>(null)
  const [filter, setFilter] = useState<string>('ALL')

  const { data, isLoading } = useQuery<{ news: NewsItem[] }>({
    queryKey: ['news'],
    queryFn: async () => (await fetch('/api/news')).json(),
  })

  const news = data?.news || []
  const filtered = filter === 'ALL' ? news : news.filter((n) => n.category === filter)

  if (selected) {
    return (
      <div className="space-y-4">
        <button onClick={() => setSelected(null)} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
          <ChevronRight className="h-3 w-3 rotate-180" /> Назад к вестям
        </button>
        <Card className="ornate-border bg-card/40 border-border/40 p-6">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            {selected.isPinned && <Badge className="bg-accent/20 text-accent border-accent/40 text-[10px] gap-1"><Pin className="h-3 w-3" /> Закреплено</Badge>}
            <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">
              {NEWS_CATEGORIES[selected.category]?.label || selected.category}
            </Badge>
            {selected.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {selected.turnNumber}</Badge>}
            <span className="text-[10px] text-muted-foreground/60 ml-auto flex items-center gap-1">
              <Clock className="h-3 w-3" /> {new Date(selected.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
            <BookmarkButton type="news" entityId={selected.id} />
          </div>
          <h1 className="font-heading text-2xl font-bold text-foreground text-glow mb-2">{selected.title}</h1>
          {selected.excerpt && <p className="text-sm text-muted-foreground italic mb-3">{selected.excerpt}</p>}
          <div className="ornament-divider opacity-30 mb-4" />
          <Markdown content={selected.content} />
          <div className="mt-4 pt-3 border-t border-border/30 text-xs text-muted-foreground">
            Автор: {selected.author.name}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <PageHeader title="Вести мира" description="Общедоступные новости и события Терского Мира" />

      {/* Фильтр по категориям */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={filter === 'ALL' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('ALL')}
          className={filter === 'ALL' ? 'bg-accent text-accent-foreground' : ''}
        >
          Все
        </Button>
        {Object.entries(NEWS_CATEGORIES).map(([key, cat]) => (
          <Button
            key={key}
            variant={filter === key ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(key)}
            className={filter === key ? 'bg-accent text-accent-foreground' : ''}
          >
            {cat.label}
          </Button>
        ))}
      </div>

      {isLoading ? (
        <CardListSkeleton count={4} />
      ) : filtered.length === 0 ? (
        <EmptyState icon={Newspaper} title="Вестей нет" description="В выбранной категории новости пока не опубликованы. Глашатаи готовят вести из всех уголков Терского Мира." />
      ) : (
        <div className="space-y-3">
          {filtered.map((n) => (
            <Card
              key={n.id}
              onClick={() => setSelected(n)}
              className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group"
            >
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                {n.isPinned && <Pin className="h-3 w-3 text-accent" />}
                <Badge variant="outline" className={`text-[10px] ${NEWS_CATEGORIES[n.category]?.color || ''}`}>
                  {NEWS_CATEGORIES[n.category]?.label || n.category}
                </Badge>
                {n.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {n.turnNumber}</Badge>}
                <span className="text-[10px] text-muted-foreground/60 ml-auto">
                  {new Date(n.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
                </span>
              </div>
              <h3 className="font-heading text-base text-foreground group-hover:text-accent transition-colors mb-1">{n.title}</h3>
              {n.excerpt && <p className="text-sm text-muted-foreground line-clamp-2">{n.excerpt}</p>}
              {!n.excerpt && <p className="text-sm text-muted-foreground line-clamp-2">{n.content.replace(/[#*`]/g, '').slice(0, 150)}...</p>}
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
