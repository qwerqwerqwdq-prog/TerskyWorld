'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  MessageSquare, Loader2, Plus, X, Save, Trash2, Users,
  ScrollText, Crown, ChevronRight, Check,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'

interface ChatRoom {
  id: string
  name: string
  topic?: string | null
  description?: string | null
  status: string
  summary?: string | null
  createdAt: string
  participants: Array<{
    id: string
    userId: string
    role: string
    user: { id: string; name: string; faction?: { id: string; name: string } | null }
  }>
  _count?: { messages: number }
}

interface User {
  id: string
  name: string
  email: string
  faction?: { id: string; name: string; isApproved: boolean } | null
}

export function AdminChatsView() {
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<ChatRoom | null>(null)

  const { data, isLoading } = useQuery<{ chats: ChatRoom[] }>({
    queryKey: ['admin-chats'],
    queryFn: async () => (await fetch('/api/chats')).json(),
  })

  const chats = data?.chats || []

  return (
    <div className="space-y-5">
      <PageHeader
        title="Управление чатами"
        description="Создание дипломатических переговоров между фракциями"
        action={
          <Button onClick={() => { setEditing(null); setShowForm(true) }} className="bg-accent hover:bg-accent/90 glow-teal">
            <Plus className="h-4 w-4 mr-1.5" /> Создать чат
          </Button>
        }
      />

      {showForm && <ChatForm chat={editing} onClose={() => { setShowForm(false); setEditing(null) }} />}

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : chats.length === 0 ? (
        <EmptyState icon={MessageSquare} title="Чатов нет" description="Создайте первый дипломатический чат для переговоров между правителями княжеств." />
      ) : (
        <div className="space-y-3">
          {chats.map((chat) => (
              <ChatRow key={chat.id} chat={chat} onEdit={() => { setEditing(chat); setShowForm(true) }} />
          ))}
        </div>
      )}
    </div>
  )
}

function ChatRow({ chat, onEdit }: { chat: ChatRoom; onEdit: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [showSummary, setShowSummary] = useState(false)
  const [summary, setSummary] = useState(chat.summary || '')

  const handleDelete = async () => {
    if (!confirm(`Удалить чат «${chat.name}»?`)) return
    try {
      const res = await fetch(`/api/chats/${chat.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка')
      toast({ title: 'Чат удалён' })
      queryClient.invalidateQueries({ queryKey: ['admin-chats'] })
      queryClient.invalidateQueries({ queryKey: ['chats'] })
    } catch (e) {
      toast({ title: 'Ошибка', variant: 'destructive' })
    }
  }

  const saveSummary = async () => {
    try {
      const res = await fetch(`/api/chats/${chat.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ summary, closeChat: true }),
      })
      if (!res.ok) throw new Error('Ошибка')
      toast({ title: 'Итог встречи зафиксирован' })
      queryClient.invalidateQueries({ queryKey: ['admin-chats'] })
      queryClient.invalidateQueries({ queryKey: ['chats'] })
      setShowSummary(false)
    } catch (e) {
      toast({ title: 'Ошибка', variant: 'destructive' })
    }
  }

  return (
    <Card className="border-border/40 bg-card/40 p-4">
      <div className="flex items-start gap-4">
        <div className="h-10 w-10 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
          <MessageSquare className="h-5 w-5 text-accent" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-heading text-sm text-foreground">{chat.name}</h3>
            {chat.status === 'SUMMARIZED' && <Badge className="text-[9px] bg-purple-500/20 text-purple-300 border-purple-500/30 gap-0.5"><ScrollText className="h-2.5 w-2.5" /> Итог</Badge>}
            {chat.status === 'CLOSED' && <Badge className="text-[9px] bg-muted text-muted-foreground border-border/40">Закрыт</Badge>}
          </div>
          {chat.topic && <p className="text-xs text-muted-foreground mt-0.5">{chat.topic}</p>}
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground/70">
              <Users className="h-3 w-3" /> {chat.participants.length}
            </span>
            {chat._count && (
              <span className="flex items-center gap-1 text-[10px] text-muted-foreground/70">
                <MessageSquare className="h-3 w-3" /> {chat._count.messages}
              </span>
            )}
          </div>
          {chat.summary && (
            <div className="mt-2 p-2 rounded-md bg-purple-500/10 border border-purple-500/20">
              <p className="text-[10px] text-purple-300 uppercase tracking-wider font-heading mb-0.5">Итог встречи</p>
              <p className="text-xs text-foreground/80 italic line-clamp-2">{chat.summary}</p>
            </div>
          )}
        </div>
        <div className="flex flex-col gap-1 shrink-0">
          <Button variant="outline" size="sm" onClick={() => setShowSummary(true)} className="h-7 text-xs">
            <ScrollText className="h-3 w-3 mr-1" /> Итог
          </Button>
          <Button variant="ghost" size="icon" onClick={handleDelete} className="h-7 w-7 text-muted-foreground hover:text-destructive">
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {showSummary && (
        <div className="mt-3 p-3 rounded-md bg-muted/20 border border-border/30 space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Итог встречи</Label>
          <Textarea
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            placeholder="Опишите итог дипломатической встречи..."
            className="bg-background/60 min-h-[80px]"
          />
          <div className="flex gap-2 justify-end">
            <Button variant="ghost" size="sm" onClick={() => setShowSummary(false)}>Отмена</Button>
            <Button size="sm" onClick={saveSummary} className="bg-accent hover:bg-accent/90 h-7 text-xs">
              <Check className="h-3 w-3 mr-1" /> Зафиксировать и закрыть
            </Button>
          </div>
        </div>
      )}
    </Card>
  )
}

function ChatForm({ chat, onClose }: { chat: ChatRoom | null; onClose: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    name: chat?.name || '',
    topic: chat?.topic || '',
    description: chat?.description || '',
  })
  const [selectedUsers, setSelectedUsers] = useState<string[]>(
    chat?.participants.filter((p) => p.role !== 'ADMIN').map((p) => p.userId) || []
  )

  const { data: usersData } = useQuery<{ users: User[] }>({
    queryKey: ['admin-users'],
    queryFn: async () => (await fetch('/api/admin/users')).json(),
  })
  const users = (usersData?.users || []).filter((u) => u.faction?.isApproved)

  const toggleUser = (userId: string) => {
    setSelectedUsers((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    )
  }

  const handleSave = async () => {
    if (form.name.length < 3) {
      toast({ title: 'Ошибка', description: 'Название минимум 3 символа', variant: 'destructive' })
      return
    }
    if (selectedUsers.length < 1) {
      toast({ title: 'Ошибка', description: 'Выберите хотя бы одного участника', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          topic: form.topic || undefined,
          description: form.description || undefined,
          participantIds: selectedUsers,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Чат создан', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['admin-chats'] })
      queryClient.invalidateQueries({ queryKey: ['chats'] })
      onClose()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="ornate-border bg-card/60 border-border/40 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading text-lg font-semibold text-foreground">Новые переговоры</h2>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8"><X className="h-4 w-4" /></Button>
      </div>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Название *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Встреча Лодерфеса и Помы" className="bg-background/60" />
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Тема</Label>
          <Input value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} placeholder="Торговый договор о беспошлинном ввозе" className="bg-background/60" />
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Описание</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Контекст переговоров..." className="bg-background/60 min-h-[60px]" />
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">
            Участники ({selectedUsers.length})
          </Label>
          <div className="space-y-1 max-h-60 overflow-y-auto pr-1">
            {users.length === 0 ? (
              <p className="text-xs text-muted-foreground italic p-3 text-center">Нет утверждённых фракций</p>
            ) : (
              users.map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => toggleUser(u.id)}
                  className={`w-full flex items-center gap-2 p-2 rounded-md border transition-colors text-left ${
                    selectedUsers.includes(u.id)
                      ? 'bg-accent/15 border-accent/40'
                      : 'bg-muted/20 border-border/30 hover:border-border/50'
                  }`}
                >
                  <div className={`h-5 w-5 rounded border flex items-center justify-center shrink-0 ${
                    selectedUsers.includes(u.id) ? 'bg-accent border-accent' : 'border-border'
                  }`}>
                    {selectedUsers.includes(u.id) && <Check className="h-3 w-3 text-accent-foreground" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground truncate">{u.name}</p>
                    {u.faction && <p className="text-[10px] text-accent/70 truncate">{u.faction.name}</p>}
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={onClose}>Отмена</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-accent hover:bg-accent/90 glow-teal">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
            Создать чат
          </Button>
        </div>
      </div>
    </Card>
  )
}
