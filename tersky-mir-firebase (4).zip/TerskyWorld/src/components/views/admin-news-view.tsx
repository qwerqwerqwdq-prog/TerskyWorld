'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Newspaper, Loader2, Plus, X, Save, Trash2, Pin, Edit } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { NEWS_CATEGORIES } from '@/lib/constants'

interface NewsItem {
  id: string
  title: string
  content: string
  excerpt?: string | null
  category: string
  isPinned: boolean
  turnNumber?: number | null
  createdAt: string
  author: { name: string }
}

export function AdminNewsView() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [editing, setEditing] = useState<NewsItem | null>(null)
  const [showForm, setShowForm] = useState(false)

  const { data, isLoading } = useQuery<{ news: NewsItem[] }>({
    queryKey: ['admin-news'],
    queryFn: async () => (await fetch('/api/news')).json(),
  })

  const news = data?.news || []

  const handleDelete = async (item: NewsItem) => {
    if (!confirm(`Удалить новость «${item.title}»?`)) return
    try {
      const res = await fetch(`/api/news/${item.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка')
      toast({ title: 'Новость удалена' })
      queryClient.invalidateQueries({ queryKey: ['admin-news'] })
      queryClient.invalidateQueries({ queryKey: ['news'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const togglePin = async (item: NewsItem) => {
    try {
      const res = await fetch(`/api/news/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isPinned: !item.isPinned }),
      })
      if (!res.ok) throw new Error('Ошибка')
      toast({ title: item.isPinned ? 'Откреплено' : 'Закреплено' })
      queryClient.invalidateQueries({ queryKey: ['admin-news'] })
      queryClient.invalidateQueries({ queryKey: ['news'] })
    } catch (e) {
      toast({ title: 'Ошибка', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Управление новостями"
        description="Публикация вестей мира для всех игроков"
        action={
          <Button onClick={() => { setEditing(null); setShowForm(true) }} className="bg-accent hover:bg-accent/90 glow-teal">
            <Plus className="h-4 w-4 mr-1.5" /> Новая весть
          </Button>
        }
      />

      {showForm && <NewsForm news={editing} onClose={() => { setShowForm(false); setEditing(null) }} />}

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : news.length === 0 ? (
        <EmptyState icon={Newspaper} title="Новостей нет" description="Создайте первую новость мира. Глашатаи ждут вестей из всех уголков Терского Мира." />
      ) : (
        <div className="space-y-2">
          {news.map((item) => (
            <Card key={item.id} className="border-border/40 bg-card/40 p-4 flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  {item.isPinned && <Pin className="h-3 w-3 text-accent" />}
                  <Badge variant="outline" className={`text-[10px] ${NEWS_CATEGORIES[item.category]?.color || ''}`}>
                    {NEWS_CATEGORIES[item.category]?.label || item.category}
                  </Badge>
                  {item.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {item.turnNumber}</Badge>}
                  <span className="text-[10px] text-muted-foreground/60 ml-auto">
                    {new Date(item.createdAt).toLocaleDateString('ru-RU')}
                  </span>
                </div>
                <h3 className="font-heading text-sm text-foreground">{item.title}</h3>
                {item.excerpt && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.excerpt}</p>}
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button variant="ghost" size="icon" onClick={() => togglePin(item)} className={`h-8 w-8 ${item.isPinned ? 'text-accent' : 'text-muted-foreground'}`}>
                  <Pin className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => { setEditing(item); setShowForm(true) }} className="h-8 w-8">
                  <Edit className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(item)} className="h-8 w-8 text-muted-foreground hover:text-destructive">
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function NewsForm({ news, onClose }: { news: NewsItem | null; onClose: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    title: news?.title || '',
    content: news?.content || '',
    excerpt: news?.excerpt || '',
    category: news?.category || 'GENERAL',
    isPinned: news?.isPinned || false,
    turnNumber: news?.turnNumber?.toString() || '',
  })

  const handleSave = async () => {
    if (form.title.length < 3 || form.content.length < 10) {
      toast({ title: 'Ошибка', description: 'Заполните заголовок и содержание', variant: 'destructive' })
      return
    }
    setSaving(true)
    try {
      const body = {
        title: form.title,
        content: form.content,
        excerpt: form.excerpt || undefined,
        category: form.category,
        isPinned: form.isPinned,
        turnNumber: form.turnNumber ? Number(form.turnNumber) : undefined,
      }
      const url = news ? `/api/news/${news.id}` : '/api/news'
      const method = news ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: news ? 'Новость обновлена' : 'Новость опубликована' })
      queryClient.invalidateQueries({ queryKey: ['admin-news'] })
      queryClient.invalidateQueries({ queryKey: ['news'] })
      onClose()
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card className="ornate-border bg-card/60 border-border/40 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading text-lg font-semibold text-foreground">{news ? 'Редактировать новость' : 'Новая весть'}</h2>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8"><X className="h-4 w-4" /></Button>
      </div>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Заголовок *</Label>
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-background/60" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Категория</Label>
            <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
              <SelectTrigger className="bg-background/60"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(NEWS_CATEGORIES).map(([key, cat]) => (
                  <SelectItem key={key} value={key}>{cat.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Ход</Label>
            <Input type="number" value={form.turnNumber} onChange={(e) => setForm({ ...form, turnNumber: e.target.value })} className="bg-background/60" />
          </div>
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Краткое описание</Label>
          <Input value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} placeholder="Короткая аннотация..." className="bg-background/60" />
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider">Содержание *</Label>
          <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="bg-background/60 min-h-[200px]" placeholder="Markdown поддерживается..." />
        </div>
        <div className="flex items-center gap-2">
          <Switch checked={form.isPinned} onCheckedChange={(v) => setForm({ ...form, isPinned: v })} />
          <Label className="text-sm text-muted-foreground">Закрепить новость</Label>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={onClose}>Отмена</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-accent hover:bg-accent/90 glow-teal">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4 mr-1.5" />}
            {news ? 'Обновить' : 'Опубликовать'}
          </Button>
        </div>
      </div>
    </Card>
  )
}
