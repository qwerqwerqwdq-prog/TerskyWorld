'use client'

import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Trophy, Crown, Medal, ScrollText, MessageSquare, BookOpen,
  PawPrint, Bookmark, Calendar, Shield, Loader2, TrendingUp,
  Star, Award, ChevronUp, ChevronDown, Minus,
} from 'lucide-react'
import { motion } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { PageHeader, EmptyState } from '@/components/shared/ui-bits'
import { useAppStore } from '@/stores/app-store'
import { cn } from '@/lib/utils'

interface LeaderboardUser {
  id: string
  name: string
  avatar?: string | null
  role?: string
  rank: number
  score: number
  level: string
  levelColor: string
  trend: 'up' | 'down' | 'same' | 'new'
  rankChange: number
  previousRank: number | null
  faction?: {
    id: string
    name: string
    shortName?: string | null
    bannerColor?: string | null
    isApproved: boolean
  } | null
  stats: {
    posts: number
    messages: number
    verdicts: number
    chronicle: number
    bestiary: number
    bookmarks: number
  }
  breakdown: Record<string, number>
  daysSince: number
}

const RANK_CONFIG: Record<number, { medal: string; bg: string; border: string; glow: string }> = {
  1: { medal: '🥇', bg: 'bg-amber-500/15', border: 'border-amber-500/40', glow: 'shadow-amber-500/20' },
  2: { medal: '🥈', bg: 'bg-slate-400/15', border: 'border-slate-400/40', glow: 'shadow-slate-400/20' },
  3: { medal: '🥉', bg: 'bg-amber-700/15', border: 'border-amber-700/40', glow: 'shadow-amber-700/20' },
}

export function LeaderboardView() {
  const { setView } = useAppStore()
  const [period, setPeriod] = useState<'week' | 'month' | 'all'>('all')
  const { data: sessionUser } = useQuery<{ id: string; name: string; role: string }>({
    queryKey: ['session'],
    queryFn: async () => (await fetch('/api/session')).json().then((d) => d.user),
  })
  const currentUserId = sessionUser?.id

  const { data, isLoading } = useQuery<{ leaderboard: LeaderboardUser[] }>({
    queryKey: ['leaderboard', period],
    queryFn: async () => (await fetch(`/api/leaderboard?period=${period}`)).json(),
  })

  const leaderboard = data?.leaderboard || []
  const currentUserEntry = leaderboard.find((u) => u.id === currentUserId)

  // Top 3 (podium)
  const podium = leaderboard.slice(0, 3)
  const rest = leaderboard.slice(3)

  // Сводная статистика
  const totalScore = leaderboard.reduce((acc, u) => acc + u.score, 0)
  const totalPosts = leaderboard.reduce((acc, u) => acc + u.stats.posts, 0)
  const totalMessages = leaderboard.reduce((acc, u) => acc + u.stats.messages, 0)

  return (
    <div className="space-y-5">
      <PageHeader
        title="Зал славы"
        description="Рейтинг правителей Терского Мира по активности и достижениям"
      />

      {/* Period filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
        {([
          { key: 'week' as const, label: 'Неделя' },
          { key: 'month' as const, label: 'Месяц' },
          { key: 'all' as const, label: 'Всё время' },
        ]).map((p) => (
          <button
            key={p.key}
            onClick={() => setPeriod(p.key)}
            className={cn(
              'px-3 py-1.5 rounded-md text-xs font-heading tracking-wide border transition-all',
              period === p.key
                ? 'bg-accent text-accent-foreground border-accent shadow-sm'
                : 'border-border/40 text-muted-foreground hover:text-foreground hover:border-accent/30'
            )}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Summary stats */}
      {leaderboard.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <SummaryCard icon={Users2} label="Правителей" value={leaderboard.length} color="bg-purple-500/15 text-purple-300" />
          <SummaryCard icon={Star} label="Всего очков" value={totalScore.toLocaleString('ru-RU')} color="bg-amber-500/15 text-amber-300" />
          <SummaryCard icon={ScrollText} label="Всего постов" value={totalPosts} color="bg-accent/15 text-accent" />
          <SummaryCard icon={MessageSquare} label="Сообщений" value={totalMessages} color="bg-teal-500/15 text-teal-300" />
        </div>
      )}

      {/* Your rank widget */}
      {currentUserEntry && (
        <Card className="ornate-border border-accent/40 bg-gradient-to-br from-accent/10 to-card/40 p-4">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center shrink-0 relative">
              <span className="font-heading text-lg font-bold text-accent">#{currentUserEntry.rank}</span>
              {currentUserEntry.trend !== 'new' && currentUserEntry.trend !== 'same' && (
                <div className={cn(
                  'absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full flex items-center justify-center border-2 border-card',
                  currentUserEntry.trend === 'up' ? 'bg-emerald-500' : 'bg-red-500'
                )}>
                  {currentUserEntry.trend === 'up'
                    ? <ChevronUp className="h-3 w-3 text-white" />
                    : <ChevronDown className="h-3 w-3 text-white" />}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground">Ваше место в рейтинге</p>
              <p className="font-heading text-base font-semibold text-foreground">{currentUserEntry.name}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <Badge variant="outline" className={cn('text-[9px]', currentUserEntry.levelColor)}>
                  {currentUserEntry.level}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {currentUserEntry.score.toLocaleString('ru-RU')} очков
                </span>
                {currentUserEntry.trend === 'up' && (
                  <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                    <ChevronUp className="h-3 w-3" /> +{currentUserEntry.rankChange} поз.
                  </span>
                )}
                {currentUserEntry.trend === 'down' && (
                  <span className="text-[10px] text-red-400 flex items-center gap-0.5">
                    <ChevronDown className="h-3 w-3" /> −{Math.abs(currentUserEntry.rankChange)} поз.
                  </span>
                )}
                {currentUserEntry.trend === 'same' && (
                  <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                    <Minus className="h-3 w-3" /> без изменений
                  </span>
                )}
                {currentUserEntry.trend === 'new' && (
                  <span className="text-[10px] text-amber-300">новый в рейтинге</span>
                )}
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-4 text-[10px] text-muted-foreground shrink-0 pl-3 border-l border-border/30">
              <span className="flex items-center gap-1">
                <ScrollText className="h-3 w-3" /> {currentUserEntry.stats.posts}
              </span>
              <span className="flex items-center gap-1">
                <MessageSquare className="h-3 w-3" /> {currentUserEntry.stats.messages}
              </span>
              <span className="flex items-center gap-1">
                <Bookmark className="h-3 w-3" /> {currentUserEntry.stats.bookmarks}
              </span>
            </div>
          </div>
        </Card>
      )}

      {/* Podium (Top 3) */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-accent" />
        </div>
      ) : leaderboard.length === 0 ? (
        <EmptyState icon={Trophy} title="Рейтинг пуст" description="Когда правители начнут активность, они появятся здесь." />
      ) : (
        <>
          {podium.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {podium.map((user, idx) => {
                const rank = RANK_CONFIG[user.rank] || {}
                const podiumHeight = idx === 0 ? 'md:pt-2' : idx === 1 ? 'md:pt-8' : 'md:pt-12'
                return (
                  <motion.div
                    key={user.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: idx * 0.1 }}
                    className={podiumHeight}
                  >
                    <PodiumCard user={user} rank={user.rank} isCurrent={false} onClick={() => setView('directory')} />
                  </motion.div>
                )
              })}
            </div>
          )}

          {/* Rest of leaderboard */}
          {rest.length > 0 && (
            <Card className="border-border/40 bg-card/40 overflow-hidden">
              <div className="p-3 border-b border-border/40 bg-secondary/20">
                <h2 className="font-heading text-sm font-semibold text-foreground tracking-wide flex items-center gap-2">
                  <Award className="h-4 w-4 text-accent" /> Полный рейтинг
                </h2>
              </div>
              <div className="divide-y divide-border/30">
                {rest.map((user, idx) => (
                  <LeaderboardRow key={user.id} user={user} index={idx} isCurrentUser={user.id === currentUserId} />
                ))}
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  )
}

function Users2({ className }: { className?: string }) {
  return <span className={className}>👥</span>
}

function SummaryCard({
  icon: Icon, label, value, color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number | string
  color: string
}) {
  return (
    <Card className="border-border/40 bg-card/30 p-3 flex items-center gap-3">
      <div className={cn('h-9 w-9 rounded-md border flex items-center justify-center shrink-0', color)}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="font-heading text-lg font-bold text-foreground leading-none">{value}</p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mt-0.5 truncate">{label}</p>
      </div>
    </Card>
  )
}

function PodiumCard({
  user, rank, onClick,
}: {
  user: LeaderboardUser
  rank: number
  isCurrent: boolean
  onClick: () => void
}) {
  const rankCfg = RANK_CONFIG[rank] || { medal: '', bg: 'bg-muted/20', border: 'border-border/40', glow: '' }
  const bannerColor = user.faction?.bannerColor || '#3a7d74'
  const isFirst = rank === 1

  return (
    <Card
      onClick={onClick}
      className={cn(
        'ornate-border border p-5 text-center transition-all cursor-pointer group relative overflow-hidden',
        rankCfg.bg, rankCfg.border, rankCfg.glow,
        isFirst && 'shadow-2xl'
      )}
    >
      {/* Decorative glow for #1 */}
      {isFirst && (
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 h-20 w-32 rounded-full bg-amber-400/20 blur-2xl pointer-events-none" />
      )}

      {/* Medal */}
      <div className="text-4xl mb-2 relative">{rankCfg.medal}</div>

      {/* Avatar */}
      <div className="relative mx-auto mb-3">
        {user.avatar ? (
          <img
            src={user.avatar}
            alt={user.name}
            className={cn(
              'rounded-full object-cover border-2 mx-auto',
              isFirst ? 'h-20 w-20 border-amber-400' : 'h-16 w-16 border-accent/40'
            )}
          />
        ) : (
          <div
            className={cn(
              'rounded-full border-2 flex items-center justify-center mx-auto font-heading font-bold',
              isFirst ? 'h-20 w-20 bg-amber-500/20 border-amber-400 text-amber-300 text-3xl' : 'h-16 w-16 bg-accent/20 border-accent/40 text-accent text-2xl'
            )}
          >
            {user.name[0]?.toUpperCase()}
          </div>
        )}
        {/* Crown on #1 */}
        {isFirst && (
          <Crown className="absolute -top-2 left-1/2 -translate-x-1/2 h-6 w-6 text-amber-400 drop-shadow-lg" />
        )}
      </div>

      {/* Name */}
      <h3 className={cn('font-heading font-bold text-foreground mb-1', isFirst ? 'text-lg' : 'text-base')}>
        {user.name}
      </h3>

      {/* Faction */}
      {user.faction && (
        <div className="flex items-center justify-center gap-1.5 mb-2">
          <Shield className="h-3 w-3" style={{ color: bannerColor }} />
          <span className="text-xs text-muted-foreground truncate">{user.faction.name}</span>
        </div>
      )}

      {/* Level */}
      <Badge variant="outline" className={cn('text-[10px] mb-3', user.levelColor)}>
        {user.level}
      </Badge>

      {/* Score */}
      <div className={cn(
        'rounded-md border p-3 mb-2',
        isFirst ? 'bg-amber-500/10 border-amber-500/30' : 'bg-muted/20 border-border/30'
      )}>
        <p className="font-heading text-2xl font-bold text-foreground leading-none">
          {user.score.toLocaleString('ru-RU')}
        </p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-1">очков</p>
      </div>

      {/* Mini stats */}
      <div className="grid grid-cols-3 gap-1 text-[10px] text-muted-foreground">
        <div className="flex flex-col items-center">
          <ScrollText className="h-3 w-3 mb-0.5" />
          <span className="text-foreground font-medium">{user.stats.posts}</span>
        </div>
        <div className="flex flex-col items-center">
          <MessageSquare className="h-3 w-3 mb-0.5" />
          <span className="text-foreground font-medium">{user.stats.messages}</span>
        </div>
        <div className="flex flex-col items-center">
          <Bookmark className="h-3 w-3 mb-0.5" />
          <span className="text-foreground font-medium">{user.stats.bookmarks}</span>
        </div>
      </div>
    </Card>
  )
}

function LeaderboardRow({ user, index, isCurrentUser }: { user: LeaderboardUser; index: number; isCurrentUser?: boolean }) {
  const bannerColor = user.faction?.bannerColor || '#3a7d74'

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.25, delay: index * 0.04 }}
      className={cn(
        'flex items-center gap-3 p-3 transition-colors relative',
        isCurrentUser
          ? 'bg-accent/10 border-l-2 border-accent'
          : 'hover:bg-muted/20'
      )}
    >
      {isCurrentUser && (
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-accent" />
      )}
      {/* Rank + trend */}
      <div className="flex flex-col items-center gap-0.5 shrink-0">
        <div className={cn(
          'h-8 w-8 rounded-md border flex items-center justify-center font-heading text-sm font-bold',
          isCurrentUser ? 'bg-accent/20 border-accent/40 text-accent' : 'bg-muted/30 border-border/40 text-muted-foreground'
        )}>
          {user.rank}
        </div>
        <TrendIndicator trend={user.trend} rankChange={user.rankChange} />
      </div>

      {/* Avatar */}
      <div className="shrink-0 relative">
        {user.avatar ? (
          <img src={user.avatar} alt={user.name} className={cn('h-9 w-9 rounded-full object-cover border', isCurrentUser ? 'border-accent/50' : 'border-border/40')} />
        ) : (
          <div className="h-9 w-9 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center text-accent font-heading text-sm">
            {user.name[0]?.toUpperCase()}
          </div>
        )}
      </div>

      {/* Name + faction */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className={cn('text-sm font-heading truncate', isCurrentUser ? 'text-accent' : 'text-foreground')}>{user.name}</p>
          {isCurrentUser && (
            <Badge className="bg-accent/20 text-accent border-accent/30 text-[9px] shrink-0">ВЫ</Badge>
          )}
        </div>
        {user.faction && (
          <div className="flex items-center gap-1.5">
            <Shield className="h-2.5 w-2.5" style={{ color: bannerColor }} />
            <span className="text-[10px] text-muted-foreground truncate">{user.faction.name}</span>
          </div>
        )}
      </div>

      {/* Level badge */}
      <Badge variant="outline" className={cn('text-[9px] hidden sm:inline-flex', user.levelColor)}>
        {user.level}
      </Badge>

      {/* Score */}
      <div className="text-right shrink-0">
        <p className="font-heading text-base font-bold text-foreground leading-none">
          {user.score.toLocaleString('ru-RU')}
        </p>
        <p className="text-[9px] text-muted-foreground uppercase tracking-wider mt-0.5">очков</p>
      </div>

      {/* Mini stats (hidden on mobile) */}
      <div className="hidden lg:flex items-center gap-3 text-[10px] text-muted-foreground shrink-0 pl-3 border-l border-border/30">
        <span className="flex items-center gap-0.5" title="Постов">
          <ScrollText className="h-3 w-3" /> {user.stats.posts}
        </span>
        <span className="flex items-center gap-0.5" title="Сообщений">
          <MessageSquare className="h-3 w-3" /> {user.stats.messages}
        </span>
        <span className="flex items-center gap-0.5" title="Закладок">
          <Bookmark className="h-3 w-3" /> {user.stats.bookmarks}
        </span>
      </div>
    </motion.div>
  )
}

function TrendIndicator({ trend, rankChange }: { trend: 'up' | 'down' | 'same' | 'new'; rankChange: number }) {
  if (trend === 'new') {
    return (
      <span className="text-[8px] text-muted-foreground/50 font-heading tracking-wider">NEW</span>
    )
  }
  if (trend === 'up') {
    return (
      <span className="flex items-center gap-0.5 text-[9px] text-emerald-400 font-heading" title={`Поднялся на ${rankChange} поз.`}>
        <ChevronUp className="h-2.5 w-2.5" />
        {rankChange}
      </span>
    )
  }
  if (trend === 'down') {
    return (
      <span className="flex items-center gap-0.5 text-[9px] text-red-400 font-heading" title={`Опустился на ${Math.abs(rankChange)} поз.`}>
        <ChevronDown className="h-2.5 w-2.5" />
        {Math.abs(rankChange)}
      </span>
    )
  }
  return (
    <span className="text-[9px] text-muted-foreground/40" title="Без изменений">
      <Minus className="h-2.5 w-2.5" />
    </span>
  )
}
