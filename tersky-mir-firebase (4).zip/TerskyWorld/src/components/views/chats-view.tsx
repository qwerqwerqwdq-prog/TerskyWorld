'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  MessageSquare, ChevronRight, Loader2, Send, Users, Shield,
  ScrollText, Lock, X, Crown, Image as ImageIcon,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { ImageDropzone, usePasteUpload, type UploadedFile } from '@/components/shared/image-dropzone'
import { Markdown } from '@/components/shared/markdown'
import { cn } from '@/lib/utils'

interface ChatRoom {
  id: string
  name: string
  topic?: string | null
  description?: string | null
  status: string
  summary?: string | null
  createdAt: string
  participants: Array<{
    id: string
    userId: string
    role: string
    user: { id: string; name: string; faction?: { id: string; name: string } | null }
  }>
  _count?: { messages: number }
}

interface Message {
  id: string
  content: string
  isSystem: boolean
  createdAt: string
  user: { id: string; name: string; faction?: { id: string; name: string } | null }
}

export function ChatsView() {
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const { data, isLoading } = useQuery<{ chats: ChatRoom[] }>({
    queryKey: ['chats'],
    queryFn: async () => (await fetch('/api/chats')).json(),
  })

  const chats = data?.chats || []

  if (selectedId) {
    const chat = chats.find((c) => c.id === selectedId)
    if (chat) return <ChatDetail chat={chat} onBack={() => setSelectedId(null)} />
  }

  return (
    <div className="space-y-5">
      <PageHeader title="Переговоры" description="Дипломатические чаты между правителями" />

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : chats.length === 0 ? (
        <EmptyState
          icon={MessageSquare}
          title="Переговоров пока нет"
          description="Администратор создаст чаты для дипломатических встреч между фракциями. Здесь будут проходить тайные переговоры и публичные встречи правителей."
        />
      ) : (
        <div className="space-y-3">
          {chats.map((chat) => (
            <Card
              key={chat.id}
              onClick={() => setSelectedId(chat.id)}
              className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group flex items-center gap-4"
            >
              <div className="h-11 w-11 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
                <MessageSquare className="h-5 w-5 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">{chat.name}</h3>
                  {chat.status === 'SUMMARIZED' && <Badge className="text-[9px] bg-purple-500/20 text-purple-300 border-purple-500/30 gap-0.5"><ScrollText className="h-2.5 w-2.5" /> Итог</Badge>}
                  {chat.status === 'CLOSED' && <Badge className="text-[9px] bg-muted text-muted-foreground border-border/40 gap-0.5"><Lock className="h-2.5 w-2.5" /> Закрыт</Badge>}
                </div>
                {chat.topic && <p className="text-xs text-muted-foreground truncate">{chat.topic}</p>}
                <div className="flex items-center gap-3 mt-1 text-[10px] text-muted-foreground/70">
                  <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {chat.participants.length}</span>
                  {chat._count && <span className="flex items-center gap-1"><MessageSquare className="h-3 w-3" /> {chat._count.messages}</span>}
                </div>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-accent shrink-0" />
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function ChatDetail({ chat, onBack }: { chat: ChatRoom; onBack: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [message, setMessage] = useState('')
  const [sending, setSending] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const dragCounter = useRef(0)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { data: msgData } = useQuery<{ messages: Message[] }>({
    queryKey: ['chat-messages', chat.id],
    queryFn: async () => (await fetch(`/api/chats/${chat.id}/messages`)).json(),
    refetchInterval: chat.status === 'OPEN' ? 3000 : false,
  })

  const messages = msgData?.messages || []

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  const isClosed = chat.status === 'CLOSED' || chat.status === 'SUMMARIZED'

  // Upload image and insert as markdown into message
  const uploadAndAppend = useCallback(async (files: File[]) => {
    setUploading(true)
    for (const file of files) {
      try {
        const fd = new FormData()
        fd.append('file', file)
        const res = await fetch('/api/upload', { method: 'POST', body: fd })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        setMessage((prev) => prev ? `${prev}\n${data.markdown}` : data.markdown)
        toast({ title: 'Картинка загружена', description: 'Добавлена в сообщение' })
      } catch (e) {
        toast({ title: 'Ошибка загрузки', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
      }
    }
    setUploading(false)
  }, [toast])

  // Paste upload
  const handlePaste = usePasteUpload(
    () => {},
    { insertMarkdown: (md) => setMessage((prev) => prev ? `${prev}\n${md}` : md) }
  )

  // Drag and drop
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current = 0
    setIsDragging(false)
    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) uploadAndAppend(files)
  }, [uploadAndAppend])

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current++
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    dragCounter.current--
    if (dragCounter.current === 0) setIsDragging(false)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  const handleSend = async () => {
    if (!message.trim() || isClosed) return
    setSending(true)
    try {
      const res = await fetch(`/api/chats/${chat.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: message }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setMessage('')
      queryClient.invalidateQueries({ queryKey: ['chat-messages', chat.id] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
        <ChevronRight className="h-3 w-3 rotate-180" /> Назад к переговорам
      </button>

      <Card className="border-border/40 bg-card/40 overflow-hidden">
        {/* Заголовок чата */}
        <div className="p-4 border-b border-border/40 bg-secondary/20">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center">
              <MessageSquare className="h-5 w-5 text-accent" />
            </div>
            <div className="flex-1">
              <h2 className="font-heading text-lg font-semibold text-foreground">{chat.name}</h2>
              {chat.topic && <p className="text-xs text-muted-foreground">{chat.topic}</p>}
            </div>
            {isClosed && <Badge className="bg-muted text-muted-foreground border-border/40 gap-1"><Lock className="h-3 w-3" /> Завершено</Badge>}
          </div>
          {/* Участники */}
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <Users className="h-3.5 w-3.5 text-muted-foreground" />
            {chat.participants.map((p) => (
              <Badge key={p.id} variant="outline" className="text-[10px] border-border/40 text-muted-foreground gap-1">
                {p.role === 'ADMIN' && <Crown className="h-2.5 w-2.5 text-accent" />}
                {p.user.name}
                {p.user.faction && <span className="text-accent/70">· {p.user.faction.name}</span>}
              </Badge>
            ))}
          </div>
        </div>

        {/* Итог встречи */}
        {chat.summary && (
          <div className="p-4 bg-purple-500/10 border-b border-purple-500/20">
            <div className="flex items-center gap-2 mb-2">
              <ScrollText className="h-4 w-4 text-purple-300" />
              <h3 className="font-heading text-sm font-semibold text-purple-200">Итог встречи</h3>
            </div>
            <p className="text-sm text-foreground/90 italic leading-relaxed">{chat.summary}</p>
          </div>
        )}

        {/* Сообщения */}
        <div className="p-4 space-y-3 max-h-[400px] overflow-y-auto">
          {messages.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-8">Сообщений пока нет</p>
          ) : (
            messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.isSystem ? 'justify-center' : 'justify-start'}`}>
                {msg.isSystem ? (
                  <div className="text-[10px] text-muted-foreground/70 italic px-3 py-1 rounded-full bg-muted/20">
                    {msg.content}
                  </div>
                ) : (
                  <div className="max-w-[80%]">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs font-heading text-accent">{msg.user.name}</span>
                      {msg.user.faction && <span className="text-[10px] text-muted-foreground">· {msg.user.faction.name}</span>}
                      <span className="text-[10px] text-muted-foreground/60">
                        {new Date(msg.createdAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="px-3 py-2 rounded-lg bg-muted/30 border border-border/30 text-sm text-foreground/90 [&_img]:rounded-md [&_img]:max-w-full [&_img]:max-h-64 [&_img]:my-1">
                      {msg.content.includes('![') || msg.content.includes('http') ? (
                        <Markdown content={msg.content} />
                      ) : (
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Поле ввода */}
        {!isClosed && (
          <div
            className="p-4 border-t border-border/40"
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            <div className={cn('relative flex gap-2 rounded-lg transition-all', isDragging && 'ring-2 ring-accent')}>
              {isDragging && (
                <div className="absolute inset-0 z-10 flex items-center justify-center bg-accent/10 backdrop-blur-sm rounded-lg pointer-events-none">
                  <ImageIcon className="h-8 w-8 text-accent" />
                </div>
              )}
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onPaste={handlePaste}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    handleSend()
                  }
                }}
                placeholder="Сообщение... Можно вставить картинку (Ctrl+V) или перетащить файл"
                className="bg-background/60 min-h-[44px] max-h-32 resize-none"
                rows={1}
              />
              <ImageDropzone
                onUpload={(uploadedFiles: UploadedFile[]) => {
                  // uploadedFiles already have markdown — just insert it
                  for (const f of uploadedFiles) {
                    setMessage((prev) => prev ? `${prev}\n${f.markdown}` : f.markdown)
                  }
                  toast({ title: 'Картинка загружена', description: 'Добавлена в сообщение' })
                }}
                compact
                label="Картинка"
              />
              <Button
                onClick={handleSend}
                disabled={!message.trim() || sending || uploading}
                className="bg-accent hover:bg-accent/90 glow-teal shrink-0"
              >
                {sending || uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
