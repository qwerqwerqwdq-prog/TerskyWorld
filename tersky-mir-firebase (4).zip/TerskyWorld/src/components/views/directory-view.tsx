'use client'

import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Users, Shield, Crown, ScrollText, ChevronRight, Loader2,
  Search, Coins, Flag, Calendar, Coins as TreasuryIcon,
  Swords, Users as PopIcon, Sparkles, Building2, Handshake,
  Church, PawPrint, ChevronDown, X, TrendingUp, TrendingDown,
  Clock, History,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Markdown } from '@/components/shared/markdown'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton, StatSectionsSkeleton } from '@/components/shared/skeletons'
import { STAT_SECTIONS } from '@/lib/constants'
import { cn } from '@/lib/utils'

interface DirectoryFaction {
  id: string
  name: string
  shortName?: string | null
  motto?: string | null
  description?: string | null
  bannerColor?: string | null
  emblemUrl?: string | null
  isApproved: boolean
  createdAt: string
  user: {
    id: string
    name: string
    avatar?: string | null
    _count: { posts: number }
  }
  _count: {
    posts: number
    statChangeLogs: number
  }
}

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Flag, Handshake, TreasuryIcon, Swords, Church, PopIcon, Sparkles, Building2, Crown,
}

export function DirectoryView() {
  const [search, setSearch] = useState('')
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const { data, isLoading } = useQuery<{ factions: DirectoryFaction[]; stats: { totalFactions: number; totalPosts: number; totalRulers: number } }>({
    queryKey: ['directory'],
    queryFn: async () => (await fetch('/api/directory')).json(),
  })

  const factions = data?.factions || []
  const stats = data?.stats

  const filtered = useMemo(() => {
    if (!search.trim()) return factions
    const q = search.toLowerCase()
    return factions.filter((f) =>
      f.name.toLowerCase().includes(q) ||
      (f.shortName?.toLowerCase().includes(q) ?? false) ||
      f.user.name.toLowerCase().includes(q)
    )
  }, [factions, search])

  if (selectedId) {
    return <FactionDetail factionId={selectedId} onBack={() => setSelectedId(null)} />
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Державы Терского Мира"
        description="Утверждённые княжества и их правители"
      />

      {/* Summary stats */}
      {stats && (
        <div className="grid grid-cols-3 gap-3">
          <SummaryCard icon={Flag} label="Княжеств" value={stats.totalFactions} color="bg-accent/15 text-accent" />
          <SummaryCard icon={Users} label="Правителей" value={stats.totalRulers} color="bg-purple-500/15 text-purple-300" />
          <SummaryCard icon={ScrollText} label="Постов" value={stats.totalPosts} color="bg-teal-500/15 text-teal-300" />
        </div>
      )}

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Поиск по названию или правителю..."
          className="pl-9 bg-background/60"
        />
      </div>

      {/* Factions list */}
      {isLoading ? (
        <CardListSkeleton count={4} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Shield}
          title={search ? "Ничего не найдено" : "Княжеств пока нет"}
          description={search ? "Попробуйте изменить поисковый запрос" : "Утверждённые княжества появятся здесь, когда администратор одобрит их."}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((faction) => (
            <FactionCard key={faction.id} faction={faction} onClick={() => setSelectedId(faction.id)} />
          ))}
        </div>
      )}
    </div>
  )
}

function SummaryCard({
  icon: Icon, label, value, color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  color: string
}) {
  return (
    <Card className="border-border/40 bg-card/30 p-3 flex items-center gap-3">
      <div className={cn('h-9 w-9 rounded-md border flex items-center justify-center shrink-0', color)}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <p className="font-heading text-lg font-bold text-foreground leading-none">{value}</p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mt-0.5 truncate">{label}</p>
      </div>
    </Card>
  )
}

function FactionCard({ faction, onClick }: { faction: DirectoryFaction; onClick: () => void }) {
  const bannerColor = faction.bannerColor || '#3a7d74'

  return (
    <Card
      onClick={onClick}
      className="ornate-border border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all overflow-hidden group card-hover-lift cursor-pointer"
    >
      <div className="h-1.5 w-full" style={{ background: bannerColor }} />

      <div className="p-4">
        <div className="flex items-start gap-3">
          <div
            className="h-14 w-14 rounded-md flex items-center justify-center shrink-0 border-2"
            style={{
              borderColor: bannerColor,
              backgroundColor: `${bannerColor}22`,
            }}
          >
            <Shield className="h-7 w-7" style={{ color: bannerColor }} />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5 flex-wrap">
              <h3 className="font-heading text-base font-semibold text-foreground group-hover:text-accent transition-colors truncate">
                {faction.name}
              </h3>
              {faction.shortName && (
                <Badge variant="outline" className="text-[9px] border-border/40 text-muted-foreground">
                  {faction.shortName}
                </Badge>
              )}
            </div>

            {faction.motto && (
              <p className="text-xs italic text-accent/80 mb-1 line-clamp-1">«{faction.motto}»</p>
            )}

            {faction.description && (
              <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{faction.description}</p>
            )}

            <div className="flex items-center gap-2 mb-2">
              {faction.user.avatar ? (
                <img src={faction.user.avatar} alt={faction.user.name} className="h-5 w-5 rounded-full object-cover border border-border/40" />
              ) : (
                <div className="h-5 w-5 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center text-accent text-[10px] font-heading">
                  {faction.user.name[0]?.toUpperCase()}
                </div>
              )}
              <span className="text-xs text-foreground flex items-center gap-1">
                <Crown className="h-3 w-3 text-amber-400" />
                {faction.user.name}
              </span>
            </div>

            <div className="flex items-center gap-3 text-[10px] text-muted-foreground/70 pt-2 border-t border-border/30">
              <span className="flex items-center gap-1">
                <ScrollText className="h-3 w-3" /> {faction._count.posts} постов
              </span>
              <span className="flex items-center gap-1">
                <Coins className="h-3 w-3" /> {faction._count.statChangeLogs} изм. статов
              </span>
              <span className="flex items-center gap-1 ml-auto group-hover:text-accent transition-colors">
                Открыть <ChevronRight className="h-3 w-3" />
              </span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}

// ===== Детальная страница фракции =====
interface FactionDetailData {
  id: string
  name: string
  shortName?: string | null
  motto?: string | null
  description?: string | null
  bannerColor?: string | null
  isApproved: boolean
  createdAt: string
  user: {
    id: string
    name: string
    avatar?: string | null
    bio?: string | null
    createdAt: string
  }
  stats: Array<{
    id: string
    sectionKey: string
    sectionTitle: string
    content: unknown
    order: number
  }>
  recentPosts: Array<{
    id: string
    title: string
    content: string
    turnNumber?: number | null
    weekNumber?: number | null
    createdAt: string
    verdict?: {
      id: string
      roleplayText: string
      createdAt: string
      statChanges: number
      admin: { id: string; name: string }
    } | null
  }>
  recentChanges: Array<{
    id: string
    sectionKey: string
    changeType: string
    oldValue: unknown
    newValue: unknown
    createdAt: string
    verdict?: { post: { id: string; title: string } } | null
    admin: { id: string; name: string }
  }>
  _count: {
    posts: number
    statChangeLogs: number
  }
}

function FactionDetail({ factionId, onBack }: { factionId: string; onBack: () => void }) {
  const [expandedStat, setExpandedStat] = useState<string | null>('NAME')

  const { data, isLoading } = useQuery<{ faction: FactionDetailData }>({
    queryKey: ['directory-faction', factionId],
    queryFn: async () => (await fetch(`/api/directory/${factionId}`)).json(),
  })

  if (isLoading) {
    return (
      <div className="space-y-5">
        <button onClick={onBack} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
          <ChevronRight className="h-3 w-3 rotate-180" /> Назад к державам
        </button>
        <StatSectionsSkeleton count={4} />
      </div>
    )
  }

  const faction = data?.faction
  if (!faction) return <EmptyState icon={Shield} title="Княжество не найдено" />

  const bannerColor = faction.bannerColor || '#3a7d74'

  return (
    <div className="space-y-5">
      <button onClick={onBack} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1 transition-colors">
        <ChevronRight className="h-3 w-3 rotate-180" /> Назад к державам
      </button>

      {/* Шапка фракции */}
      <Card className="ornate-border overflow-hidden border-border/40 bg-card/40">
        <div className="h-2 w-full" style={{ background: bannerColor }} />
        <div className="p-6 ambient-gradient">
          <div className="flex flex-col md:flex-row md:items-start gap-5">
            <div
              className="h-20 w-20 rounded-md flex items-center justify-center shrink-0 border-2 shadow-lg"
              style={{ borderColor: bannerColor, backgroundColor: `${bannerColor}22` }}
            >
              <Shield className="h-10 w-10" style={{ color: bannerColor }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 flex-wrap mb-2">
                <h1 className="font-heading text-2xl font-bold text-foreground text-glow">{faction.name}</h1>
                {faction.shortName && (
                  <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">
                    {faction.shortName}
                  </Badge>
                )}
                <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[10px]">
                  Утверждено
                </Badge>
              </div>
              {faction.motto && (
                <p className="text-sm italic text-accent/80 mb-2">«{faction.motto}»</p>
              )}
              {faction.description && (
                <p className="text-sm text-foreground/80 mt-2 leading-relaxed">{faction.description}</p>
              )}

              {/* Правитель */}
              <div className="mt-4 p-3 rounded-md bg-muted/20 border border-border/30 flex items-center gap-3">
                {faction.user.avatar ? (
                  <img src={faction.user.avatar} alt={faction.user.name} className="h-10 w-10 rounded-full object-cover border border-accent/30" />
                ) : (
                  <div className="h-10 w-10 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center text-accent font-heading">
                    {faction.user.name[0]?.toUpperCase()}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading">Правитель</p>
                  <p className="text-sm font-heading text-foreground flex items-center gap-1.5">
                    <Crown className="h-3.5 w-3.5 text-amber-400" />
                    {faction.user.name}
                  </p>
                  {faction.user.bio && (
                    <p className="text-xs text-muted-foreground italic mt-0.5 line-clamp-1">{faction.user.bio}</p>
                  )}
                </div>
                <div className="text-right shrink-0">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading">Создано</p>
                  <p className="text-xs text-foreground">{new Date(faction.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                </div>
              </div>

              {/* Счётчики */}
              <div className="flex items-center gap-4 mt-3 text-xs">
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <ScrollText className="h-3.5 w-3.5 text-accent" />
                  <strong className="text-foreground">{faction._count.posts}</strong> постов
                </span>
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <Coins className="h-3.5 w-3.5 text-accent" />
                  <strong className="text-foreground">{faction._count.statChangeLogs}</strong> изменений статов
                </span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Секции статистики */}
        <Card className="border-border/40 bg-card/40 p-5">
          <h2 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Crown className="h-4 w-4 text-accent" /> Статистика государства
          </h2>
          {faction.stats.length === 0 ? (
            <p className="text-sm text-muted-foreground italic py-8 text-center">Статистика ещё не заполнена</p>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scroll pr-1">
              {faction.stats.map((stat) => {
                const def = STAT_SECTIONS.find((s) => s.key === stat.sectionKey)
                const Icon = (def && ICON_MAP[def.icon]) || Flag
                const isOpen = expandedStat === stat.sectionKey
                return (
                  <div key={stat.id} className="border border-border/40 bg-card/30 rounded-md overflow-hidden">
                    <button
                      onClick={() => setExpandedStat(isOpen ? null : stat.sectionKey)}
                      className="w-full flex items-center gap-3 p-3 hover:bg-muted/20 transition-colors text-left"
                    >
                      <div className="h-8 w-8 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
                        <Icon className="h-4 w-4 text-accent" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-heading text-sm font-semibold text-foreground tracking-wide truncate">{stat.sectionTitle}</h3>
                        {def && <p className="text-[10px] text-muted-foreground truncate">{def.description}</p>}
                      </div>
                      <ChevronDown className={cn('h-3.5 w-3.5 text-muted-foreground transition-transform shrink-0', isOpen && 'rotate-180')} />
                    </button>
                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-3 pb-3">
                            <div className="ornament-divider opacity-20 mb-2" />
                            <StatContentPreview content={stat.content as Record<string, unknown>} sectionKey={stat.sectionKey} />
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )
              })}
            </div>
          )}
        </Card>

        {/* Последние посты */}
        <Card className="border-border/40 bg-card/40 p-5">
          <h2 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <ScrollText className="h-4 w-4 text-accent" /> Последние посты
          </h2>
          {faction.recentPosts.length === 0 ? (
            <p className="text-sm text-muted-foreground italic py-8 text-center">Постов с вердиктами пока нет</p>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scroll pr-1">
              {faction.recentPosts.map((post) => (
                <div key={post.id} className="p-3 rounded-md bg-muted/20 border border-border/30">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[9px] gap-0.5">
                      <Shield className="h-2.5 w-2.5" /> Вердикт
                    </Badge>
                    {post.turnNumber && <Badge variant="outline" className="text-[9px] text-muted-foreground">Ход {post.turnNumber}</Badge>}
                    <span className="text-[10px] text-muted-foreground/60 ml-auto">
                      {new Date(post.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                    </span>
                  </div>
                  <h4 className="font-heading text-sm text-foreground mb-1">{post.title}</h4>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{post.content.slice(0, 150)}</p>
                  {post.verdict && (
                    <div className="pt-2 border-t border-border/30">
                      <p className="text-[10px] text-accent/80 italic line-clamp-2">
                        «{post.verdict.roleplayText.replace(/[#*`_]/g, '').slice(0, 140)}»
                      </p>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground/60">
                        <span>— {post.verdict.admin.name}</span>
                        {post.verdict.statChanges > 0 && (
                          <span className="flex items-center gap-0.5 text-amber-400">
                            <Coins className="h-2.5 w-2.5" /> {post.verdict.statChanges} секц.
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* История изменений */}
      {faction.recentChanges.length > 0 && (
        <Card className="border-border/40 bg-card/40 p-5">
          <h2 className="font-heading text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <History className="h-4 w-4 text-accent" /> История изменений статов
            <Badge variant="outline" className="text-[10px] text-muted-foreground ml-auto">{faction.recentChanges.length}</Badge>
          </h2>
          <div className="space-y-2 max-h-80 overflow-y-auto custom-scroll pr-1">
            {faction.recentChanges.map((change) => {
              const def = STAT_SECTIONS.find((s) => s.key === change.sectionKey)
              return (
                <div key={change.id} className="flex items-center gap-3 p-2.5 rounded-md bg-muted/20 border border-border/30">
                  <div className={cn(
                    'h-7 w-7 rounded-md flex items-center justify-center shrink-0 border',
                    change.changeType === 'CREATE' ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                    : change.changeType === 'DELETE' ? 'bg-red-500/15 border-red-500/30 text-red-400'
                    : 'bg-accent/15 border-accent/30 text-accent'
                  )}>
                    {change.changeType === 'CREATE' ? <TrendingUp className="h-3.5 w-3.5" />
                    : change.changeType === 'DELETE' ? <TrendingDown className="h-3.5 w-3.5" />
                    : <Coins className="h-3.5 w-3.5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-heading text-foreground">
                      {def?.title || change.sectionKey}
                      <span className="text-muted-foreground ml-1.5 text-[10px]">· {change.changeType}</span>
                    </p>
                    <p className="text-[10px] text-muted-foreground truncate">
                      {change.verdict?.post?.title || 'Прямое изменение'} · {change.admin.name}
                    </p>
                  </div>
                  <span className="text-[10px] text-muted-foreground/60 shrink-0 flex items-center gap-1">
                    <Clock className="h-2.5 w-2.5" />
                    {new Date(change.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                  </span>
                </div>
              )
            })}
          </div>
        </Card>
      )}
    </div>
  )
}

function StatContentPreview({ content, sectionKey }: { content: Record<string, unknown>; sectionKey: string }) {
  if (!content || typeof content !== 'object') {
    return <p className="text-sm text-muted-foreground italic">Нет данных</p>
  }

  const def = STAT_SECTIONS.find((s) => s.key === sectionKey)
  const entries = Object.entries(content)
  if (entries.length === 0) return <p className="text-sm text-muted-foreground italic">Нет данных</p>

  const labelOf = (key: string): string => {
    const f = def?.fields.find((sf) => sf.key === key)
    return f?.label || key
  }

  return (
    <div className="space-y-1.5">
      {entries.slice(0, 8).map(([key, value]) => {
        if (Array.isArray(value)) {
          if (value.length === 0) return null
          return (
            <div key={key} className="flex items-center gap-2 text-xs">
              <span className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground shrink-0">{labelOf(key)}:</span>
              <span className="text-foreground truncate">{value.length} записей</span>
            </div>
          )
        }
        if (typeof value === 'object' && value !== null) {
          return null
        }
        return (
          <div key={key} className="flex items-center gap-2 text-xs">
            <span className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground shrink-0">{labelOf(key)}:</span>
            <span className="text-foreground truncate">{String(value) || '—'}</span>
          </div>
        )
      })}
      {entries.length > 8 && (
        <p className="text-[10px] text-muted-foreground/60 italic">и ещё {entries.length - 8} полей...</p>
      )}
    </div>
  )
}
