'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Bookmark, ScrollText, Newspaper, Trash2, ChevronRight,
  Clock, Shield, Loader2, Filter,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'
import { useAppStore } from '@/stores/app-store'
import { cn } from '@/lib/utils'

interface BookmarkItem {
  id: string
  type: string
  createdAt: string
  post?: {
    id: string
    title: string
    content: string
    status: string
    createdAt: string
    author: { id: string; name: string }
    faction?: { id: string; name: string } | null
  }
  news?: {
    id: string
    title: string
    excerpt?: string | null
    category: string
    createdAt: string
  }
}

type FilterType = 'ALL' | 'post' | 'news'

export function BookmarksView() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const { setView } = useAppStore()
  const [filter, setFilter] = useState<FilterType>('ALL')

  const { data, isLoading } = useQuery<{ bookmarks: BookmarkItem[] }>({
    queryKey: ['bookmarks'],
    queryFn: async () => (await fetch('/api/bookmarks')).json(),
  })

  const bookmarks = data?.bookmarks || []
  const filtered = filter === 'ALL' ? bookmarks : bookmarks.filter((b) => b.type === filter)

  const handleRemove = async (type: string, entityId: string) => {
    try {
      const res = await fetch(`/api/bookmarks?type=${type}&entityId=${entityId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка')
      toast({ title: 'Удалено из закладок' })
      queryClient.invalidateQueries({ queryKey: ['bookmarks'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    }
  }

  const counts = {
    ALL: bookmarks.length,
    post: bookmarks.filter((b) => b.type === 'post').length,
    news: bookmarks.filter((b) => b.type === 'news').length,
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Закладки"
        description="Сохранённые посты и вести для последующего чтения"
      />

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="h-3.5 w-3.5 text-muted-foreground" />
        {([
          { key: 'ALL' as const, label: 'Все' },
          { key: 'post' as const, label: 'Посты' },
          { key: 'news' as const, label: 'Вести' },
        ]).map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              'px-3 py-1.5 rounded-md text-xs font-heading tracking-wide border transition-all',
              filter === f.key
                ? 'bg-accent text-accent-foreground border-accent shadow-sm'
                : 'border-border/40 text-muted-foreground hover:text-foreground hover:border-accent/30'
            )}
          >
            {f.label}
            <span className="ml-1.5 opacity-60">{counts[f.key]}</span>
          </button>
        ))}
      </div>

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Bookmark}
          title={filter === 'ALL' ? "Закладок пока нет" : "В этой категории пусто"}
          description={filter === 'ALL'
            ? "Сохраняйте посты и вести, нажимая на иконку закладки. Они появятся здесь для быстрого доступа."
            : "Сохраните записи этого типа, чтобы они появились здесь."}
        />
      ) : (
        <div className="space-y-2">
          {filtered.map((bookmark) => (
            <BookmarkCard
              key={bookmark.id}
              bookmark={bookmark}
              onRemove={() => handleRemove(bookmark.type, bookmark.post?.id || bookmark.news?.id || '')}
              onNavigate={() => setView(bookmark.type === 'post' ? 'posts' : 'news')}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function BookmarkCard({
  bookmark, onRemove, onNavigate,
}: {
  bookmark: BookmarkItem
  onRemove: () => void
  onNavigate: () => void
}) {
  const isPost = bookmark.type === 'post'
  const item = isPost ? bookmark.post : bookmark.news

  if (!item) return null

  return (
    <Card className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all p-4 group flex items-start gap-3">
      <div className={cn(
        'h-10 w-10 rounded-md border flex items-center justify-center shrink-0',
        isPost ? 'bg-accent/15 border-accent/30 text-accent' : 'bg-teal-500/15 border-teal-500/30 text-teal-300'
      )}>
        {isPost ? <ScrollText className="h-5 w-5" /> : <Newspaper className="h-5 w-5" />}
      </div>

      <button
        onClick={onNavigate}
        className="flex-1 min-w-0 text-left"
      >
        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <Badge variant="outline" className="text-[9px]">
            {isPost ? 'Пост' : 'Весть'}
          </Badge>
          {isPost && bookmark.post?.faction && (
            <Badge variant="outline" className="text-[9px] border-accent/30 text-accent gap-0.5">
              <Shield className="h-2.5 w-2.5" /> {bookmark.post.faction.name}
            </Badge>
          )}
          {!isPost && bookmark.news && (
            <Badge variant="outline" className="text-[9px] text-muted-foreground">
              {bookmark.news.category}
            </Badge>
          )}
          <span className="text-[10px] text-muted-foreground/60 ml-auto flex items-center gap-1">
            <Clock className="h-2.5 w-2.5" />
            {new Date(item.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
          </span>
        </div>
        <h3 className="font-heading text-sm text-foreground group-hover:text-accent transition-colors truncate">
          {item.title}
        </h3>
        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
          {isPost
            ? bookmark.post!.content.replace(/[#*`]/g, '').slice(0, 150)
            : bookmark.news!.excerpt?.slice(0, 150) || 'Без описания'
          }
        </p>
        {isPost && bookmark.post && (
          <p className="text-[10px] text-muted-foreground/60 mt-1">
            Автор: {bookmark.post.author.name}
          </p>
        )}
      </button>

      <div className="flex items-center gap-1 shrink-0">
        <Button
          variant="ghost"
          size="sm"
          onClick={onNavigate}
          className="h-8 text-xs text-muted-foreground hover:text-accent"
        >
          Открыть <ChevronRight className="h-3 w-3 ml-0.5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={onRemove}
          className="h-8 w-8 text-muted-foreground hover:text-destructive"
          aria-label="Удалить закладку"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </Card>
  )
}
