'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Swords, ChevronRight, Loader2, Clock, CheckCircle2, Users,
  Shield, Sword, Ship, Footprints, Flag, AlertCircle,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState, PageHeader, StatBadge } from '@/components/shared/ui-bits'
import { CardListSkeleton } from '@/components/shared/skeletons'

interface Battle {
  id: string
  name: string
  description?: string | null
  location?: string | null
  turnNumber?: number | null
  status: string
  postDeadline?: string | null
  createdAt: string
  forces: Array<{
    id: string
    commander: string
    infantry: number
    archers: number
    cavalry: number
    fleet: number
    special?: string | null
    description?: string | null
    faction: { id: string; name: string; shortName?: string | null }
  }>
  participants: Array<{
    id: string
    hasPosted: boolean
    postedAt?: string | null
    faction: { id: string; name: string }
  }>
  posts?: Array<{
    id: string
    title: string
    content: string
    createdAt: string
    author: { id: string; name: string }
    faction?: { id: string; name: string } | null
  }>
}

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  PREPARING: { label: 'Подготовка', color: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
  ACTIVE: { label: 'Активна', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  POSTING: { label: 'Сбор постов', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  RESOLVED: { label: 'Завершена', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
}

export function BattlesView() {
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const { data, isLoading } = useQuery<{ battles: Battle[] }>({
    queryKey: ['battles'],
    queryFn: async () => (await fetch('/api/battles')).json(),
  })

  const battles = data?.battles || []

  if (selectedId) {
    const battle = battles.find((b) => b.id === selectedId)
    if (battle) return <BattleDetail battleId={battle.id} onBack={() => setSelectedId(null)} />
  }

  return (
    <div className="space-y-5">
      <PageHeader title="Военные дела" description="Баталии и военные действия в Терском Мире" />

      {isLoading ? (
        <CardListSkeleton count={3} />
      ) : battles.length === 0 ? (
        <EmptyState
          icon={Swords}
          title="Баталий нет"
          description="Активных военных действий пока не объявлено. Когда начнётся конфликт, его подробности появятся здесь."
        />
      ) : (
        <div className="space-y-3">
          {battles.map((battle) => {
            const status = STATUS_CONFIG[battle.status] || STATUS_CONFIG.PREPARING
            const posted = battle.participants.filter((p) => p.hasPosted).length
            const total = battle.participants.length
            const deadline = battle.postDeadline ? new Date(battle.postDeadline) : null
            const timeLeft = deadline ? deadline.getTime() - Date.now() : null

            return (
              <Card
                key={battle.id}
                onClick={() => setSelectedId(battle.id)}
                className="border-border/40 bg-card/40 hover:bg-card/60 hover:border-accent/30 transition-all cursor-pointer p-4 group"
              >
                <div className="flex items-start gap-4">
                  <div className="h-11 w-11 rounded-md bg-red-500/15 border border-red-500/30 flex items-center justify-center shrink-0">
                    <Swords className="h-5 w-5 text-red-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="font-heading text-base text-foreground group-hover:text-accent transition-colors">{battle.name}</h3>
                      <Badge variant="outline" className={`text-[10px] ${status.color}`}>{status.label}</Badge>
                      {battle.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {battle.turnNumber}</Badge>}
                    </div>
                    {battle.location && <p className="text-xs text-muted-foreground flex items-center gap-1"><Flag className="h-3 w-3" /> {battle.location}</p>}
                    {battle.description && <p className="text-sm text-muted-foreground/80 mt-1 line-clamp-2">{battle.description}</p>}

                    <div className="flex items-center gap-4 mt-2 text-[10px] text-muted-foreground/70">
                      <span className="flex items-center gap-1"><Shield className="h-3 w-3" /> {battle.forces.length} фракций</span>
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" /> {posted}/{total} написали
                      </span>
                      {timeLeft !== null && timeLeft > 0 && (
                        <span className="flex items-center gap-1 text-amber-400">
                          <Clock className="h-3 w-3" /> {formatTimeLeft(timeLeft)}
                        </span>
                      )}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-accent shrink-0 mt-1" />
                </div>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}

function BattleDetail({ battleId, onBack }: { battleId: string; onBack: () => void }) {
  const { data, isLoading } = useQuery<{ battle: Battle }>({
    queryKey: ['battle', battleId],
    queryFn: async () => (await fetch(`/api/battles/${battleId}`)).json(),
  })

  if (isLoading) {
    return <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-accent" /></div>
  }

  const battle = data?.battle
  if (!battle) return <EmptyState icon={Swords} title="Баталия не найдена" />

  const status = STATUS_CONFIG[battle.status] || STATUS_CONFIG.PREPARING
  const deadline = battle.postDeadline ? new Date(battle.postDeadline) : null
  const timeLeft = deadline ? deadline.getTime() - Date.now() : null

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="text-sm text-muted-foreground hover:text-accent flex items-center gap-1">
        <ChevronRight className="h-3 w-3 rotate-180" /> Назад к баталиям
      </button>

      <Card className="ornate-border bg-card/40 border-border/40 p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="h-12 w-12 rounded-md bg-red-500/15 border border-red-500/30 flex items-center justify-center shrink-0">
            <Swords className="h-6 w-6 text-red-400" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h1 className="font-heading text-2xl font-bold text-foreground text-glow">{battle.name}</h1>
              <Badge variant="outline" className={`text-[10px] ${status.color}`}>{status.label}</Badge>
              {battle.turnNumber && <Badge variant="outline" className="text-[10px] border-border/40 text-muted-foreground">Ход {battle.turnNumber}</Badge>}
            </div>
            {battle.location && <p className="text-sm text-muted-foreground flex items-center gap-1"><Flag className="h-3.5 w-3.5" /> {battle.location}</p>}
            {battle.description && <p className="text-sm text-foreground/80 mt-2 leading-relaxed">{battle.description}</p>}
            {timeLeft !== null && timeLeft > 0 && (
              <div className="mt-3 p-2.5 rounded-md bg-amber-500/10 border border-amber-500/30 flex items-center gap-2">
                <Clock className="h-4 w-4 text-amber-400" />
                <span className="text-sm text-amber-200">До дедлайна постов: <strong>{formatTimeLeft(timeLeft)}</strong></span>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Силы сторон */}
      <Card className="border-border/40 bg-card/40 p-5">
        <h2 className="font-heading text-lg text-foreground mb-4 flex items-center gap-2">
          <Shield className="h-4 w-4 text-accent" /> Силы сторон
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {battle.forces.map((force) => (
            <div key={force.id} className="p-4 rounded-md bg-muted/20 border border-border/30">
              <div className="flex items-center gap-2 mb-3">
                <Flag className="h-4 w-4 text-accent" />
                <h3 className="font-heading text-sm text-foreground">{force.faction.name}</h3>
              </div>
              <p className="text-xs text-muted-foreground mb-3">Командир: <span className="text-foreground">{force.commander || 'Не указан'}</span></p>
              <div className="grid grid-cols-2 gap-2">
                <ForceStat icon={<Sword className="h-3.5 w-3.5" />} label="Пехота" value={force.infantry} />
                <ForceStat icon={<Users className="h-3.5 w-3.5" />} label="Лучники" value={force.archers} />
                <ForceStat icon={<Footprints className="h-3.5 w-3.5" />} label="Кавалерия" value={force.cavalry} />
                <ForceStat icon={<Ship className="h-3.5 w-3.5" />} label="Флот" value={force.fleet} />
              </div>
              {force.special && (
                <p className="text-xs text-muted-foreground mt-2 pt-2 border-t border-border/30">Особые: {force.special}</p>
              )}
              {force.description && (
                <p className="text-xs text-foreground/70 mt-2 italic">{force.description}</p>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Статус постов участников */}
      <Card className="border-border/40 bg-card/40 p-5">
        <h2 className="font-heading text-lg text-foreground mb-4 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-accent" /> Статус постов
        </h2>
        <div className="space-y-2">
          {battle.participants.map((p) => (
            <div key={p.id} className="flex items-center justify-between p-2.5 rounded-md bg-muted/20 border border-border/30">
              <div className="flex items-center gap-2">
                <Flag className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="text-sm text-foreground">{p.faction.name}</span>
              </div>
              {p.hasPosted ? (
                <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 gap-1 text-[10px]">
                  <CheckCircle2 className="h-3 w-3" /> Написал
                </Badge>
              ) : (
                <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 gap-1 text-[10px]">
                  <Clock className="h-3 w-3" /> Ожидает
                </Badge>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Посты участников */}
      {battle.posts && battle.posts.length > 0 && (
        <Card className="border-border/40 bg-card/40 p-5">
          <h2 className="font-heading text-lg text-foreground mb-4 flex items-center gap-2">
            <Swords className="h-4 w-4 text-accent" /> Посты участников
          </h2>
          <div className="space-y-3">
            {battle.posts.map((post) => (
              <div key={post.id} className="p-3 rounded-md bg-muted/20 border border-border/30">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-heading text-accent">{post.author.name}</span>
                  {post.faction && <span className="text-[10px] text-muted-foreground">· {post.faction.name}</span>}
                  <span className="text-[10px] text-muted-foreground/60 ml-auto">
                    {new Date(post.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <h4 className="font-heading text-sm text-foreground mb-1">{post.title}</h4>
                <p className="text-xs text-muted-foreground/80 line-clamp-3 whitespace-pre-wrap">{post.content}</p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  )
}

function ForceStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="flex items-center gap-2 p-2 rounded bg-background/40">
      <span className="text-accent">{icon}</span>
      <div>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="text-sm font-heading text-foreground">{value}</p>
      </div>
    </div>
  )
}

function formatTimeLeft(ms: number): string {
  const hours = Math.floor(ms / (1000 * 60 * 60))
  const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60))
  if (hours > 0) return `${hours}ч ${minutes}м`
  if (minutes > 0) return `${minutes}м`
  return 'Менее минуты'
}
