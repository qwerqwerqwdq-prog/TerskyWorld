'use client'

import { useState, use, useMemo } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Shield, Flag, Handshake, Coins, Swords, Church, Users, Sparkles,
  Building2, Crown, Loader2, Plus, Save, X, AlertCircle, History,
  TrendingUp, TrendingDown, ScrollText, ChevronRight,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import { EmptyState, PageHeader, StatBadge } from '@/components/shared/ui-bits'
import { STAT_SECTIONS, type StatFieldDef } from '@/lib/constants'
import { cn } from '@/lib/utils'

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Flag, Handshake, Coins, Swords, Church, Users, Sparkles, Building2, Crown,
}

interface Faction {
  id: string
  name: string
  shortName?: string | null
  motto?: string | null
  description?: string | null
  bannerColor?: string | null
  isApproved: boolean
  createdAt: string
  user: { id: string; name: string }
  stats: Array<{
    id: string
    sectionKey: string
    sectionTitle: string
    content: string
    order: number
  }>
}

interface ChangeLog {
  id: string
  sectionKey: string
  changeType: string
  oldValue: unknown
  newValue: unknown
  createdAt: string
  verdict?: { post: { id: string; title: string } } | null
  admin: { id: string; name: string }
}

export function FactionView({ selectedId }: { selectedId?: string | null }) {
  const queryClient = useQueryClient()
  const { data: session, isLoading: sessionLoading } = useQuery<{ id: string; faction?: { id: string; name: string; isApproved: boolean } | null }>({
    queryKey: ['session'],
    queryFn: async () => (await fetch('/api/session')).json().then((d) => d.user),
  })

  const factionId = selectedId || session?.faction?.id
  const { data, isLoading: factionLoading } = useQuery<{ faction: Faction | null }>({
    queryKey: ['faction', factionId],
    queryFn: async () => {
      if (!factionId) return { faction: null }
      const res = await fetch(`/api/factions/${factionId}`)
      if (!res.ok) return { faction: null }
      return res.json()
    },
    enabled: !!factionId,
  })

  const faction = data?.faction

  // Загружаем историю изменений
  const { data: changesData } = useQuery<{ changes: ChangeLog[] }>({
    queryKey: ['faction-changes', factionId],
    queryFn: async () => {
      if (!factionId) return { changes: [] }
      const res = await fetch(`/api/factions/${factionId}/changes`)
      if (!res.ok) return { changes: [] }
      return res.json()
    },
    enabled: !!factionId,
  })

  const recentChanges = changesData?.changes || []

  // Загрузка session ещё идёт — показываем скелетон, а не форму регистрации
  if (sessionLoading || (factionLoading && factionId)) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    )
  }

  if (!factionId || !faction) {
    return <RegisterFaction />
  }

  return <FactionDetails faction={faction} recentChanges={recentChanges} />
}

// === Форма регистрации фракции ===
function RegisterFaction() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '',
    shortName: '',
    motto: '',
    description: '',
    bannerColor: '#3a7d74',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.name.length < 3) {
      toast({ title: 'Ошибка', description: 'Название минимум 3 символа', variant: 'destructive' })
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/factions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast({ title: 'Княжество создано', description: data.message })
      queryClient.invalidateQueries({ queryKey: ['session'] })
      queryClient.invalidateQueries({ queryKey: ['faction'] })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Ошибка', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <PageHeader
        title="Регистрация княжества"
        description="Создайте своё государство в Терском Мире"
      />

      <Card className="ornate-border bg-card/60 border-border/40 p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Название государства *</Label>
            <Input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Великое Княжество Помское"
              className="bg-background/60"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground text-xs uppercase tracking-wider">Короткое название</Label>
              <Input
                value={form.shortName}
                onChange={(e) => setForm({ ...form, shortName: e.target.value })}
                placeholder="Пома"
                className="bg-background/60"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-muted-foreground text-xs uppercase tracking-wider">Цвет герба</Label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.bannerColor}
                  onChange={(e) => setForm({ ...form, bannerColor: e.target.value })}
                  className="h-10 w-14 rounded-md border border-border/40 bg-background/60 cursor-pointer"
                />
                <Input
                  value={form.bannerColor}
                  onChange={(e) => setForm({ ...form, bannerColor: e.target.value })}
                  className="bg-background/60"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Девиз</Label>
            <Input
              value={form.motto}
              onChange={(e) => setForm({ ...form, motto: e.target.value })}
              placeholder="Сила в единстве, мудрость в совете"
              className="bg-background/60"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-muted-foreground text-xs uppercase tracking-wider">Описание княжества</Label>
            <Textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Опишите географию, историю и особенности вашего государства..."
              className="bg-background/60 min-h-[120px]"
            />
          </div>

          <div className="p-3 rounded-md bg-amber-500/10 border border-amber-500/30 flex gap-2">
            <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-200/80">
              После регистрации княжество будет ожидать утверждения администратором. Статистика будет заполнена и обновляться администратором по итогам ваших постов.
            </p>
          </div>

          <Button type="submit" disabled={loading} className="w-full bg-accent hover:bg-accent/90 glow-teal h-11">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Зарегистрировать княжество'}
          </Button>
        </form>
      </Card>
    </div>
  )
}

// === Детали фракции со статистикой ===
function FactionDetails({ faction, recentChanges }: { faction: Faction; recentChanges: ChangeLog[] }) {
  const [expanded, setExpanded] = useState<string | null>('NAME')
  const [showHistory, setShowHistory] = useState(false)

  // Группируем изменения по секциям
  const changesBySection = useMemo(() => {
    const map: Record<string, ChangeLog[]> = {}
    for (const c of recentChanges) {
      if (!map[c.sectionKey]) map[c.sectionKey] = []
      map[c.sectionKey].push(c)
    }
    return map
  }, [recentChanges])

  return (
    <div className="space-y-6">
      {/* Шапка фракции */}
      <Card className="ornate-border overflow-hidden border-border/40 bg-card/40">
        <div
          className="h-2 w-full"
          style={{ background: faction.bannerColor || '#3a7d74' }}
        />
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-start gap-4">
            <div
              className="h-16 w-16 rounded-md flex items-center justify-center shrink-0 border-2"
              style={{ borderColor: faction.bannerColor || '#3a7d74', backgroundColor: `${faction.bannerColor || '#3a7d74'}22` }}
            >
              <Shield className="h-8 w-8" style={{ color: faction.bannerColor || '#3a7d74' }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="font-heading text-2xl font-bold text-foreground text-glow">{faction.name}</h1>
                {faction.isApproved ? (
                  <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">Утверждено</Badge>
                ) : (
                  <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30">На утверждении</Badge>
                )}
              </div>
              {faction.shortName && (
                <p className="text-sm text-muted-foreground mt-0.5">Короткое название: {faction.shortName}</p>
              )}
              {faction.motto && (
                <p className="text-sm italic text-accent/80 mt-2">«{faction.motto}»</p>
              )}
              {faction.description && (
                <p className="text-sm text-foreground/80 mt-2 leading-relaxed">{faction.description}</p>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Сводка изменений (если есть) */}
      {recentChanges.length > 0 && (
        <Card className="border-accent/30 bg-gradient-to-br from-accent/5 to-card/30 p-4">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="w-full flex items-center gap-3 text-left"
          >
            <div className="h-9 w-9 rounded-md bg-accent/20 border border-accent/40 flex items-center justify-center shrink-0">
              <History className="h-4 w-4 text-accent" />
            </div>
            <div className="flex-1">
              <h3 className="font-heading text-sm font-semibold text-foreground tracking-wide">
                Последние изменения государства
              </h3>
              <p className="text-xs text-muted-foreground">
                {recentChanges.length} {pluralRecords(recentChanges.length)} от вердиктов администратора
              </p>
            </div>
            <ChevronRight className={cn('h-4 w-4 text-muted-foreground transition-transform', showHistory && 'rotate-90')} />
          </button>
          {showHistory && (
            <div className="mt-3 pt-3 border-t border-border/30 space-y-2 max-h-80 overflow-y-auto pr-1 custom-scroll fade-in-up">
              {recentChanges.slice(0, 15).map((log) => (
                <ChangeLogRow key={log.id} log={log} />
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Секции статистики */}
      <div className="space-y-3">
        <h2 className="font-heading text-lg text-foreground tracking-wider flex items-center gap-2">
          <Crown className="h-4 w-4 text-accent" />
          Статистика государства
        </h2>

        {faction.stats.length === 0 ? (
          <EmptyState icon={Shield} title="Статистика пуста" description="Секции статистики появятся после утверждения княжества" />
        ) : (
          faction.stats.map((stat) => {
            const def = STAT_SECTIONS.find((s) => s.key === stat.sectionKey)
            const Icon = (def && ICON_MAP[def.icon]) || Flag
            const isOpen = expanded === stat.sectionKey
            let content: unknown = null
            try {
              content = JSON.parse(stat.content)
            } catch {
              content = stat.content
            }

            const sectionChanges = changesBySection[stat.sectionKey] || []
            const lastChange = sectionChanges[0]

            return (
              <Card key={stat.id} className="border-border/40 bg-card/30 overflow-hidden">
                <button
                  onClick={() => setExpanded(isOpen ? null : stat.sectionKey)}
                  className="w-full flex items-center gap-3 p-4 hover:bg-muted/20 transition-colors text-left"
                >
                  <div className="h-9 w-9 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0 relative">
                    <Icon className="h-4 w-4 text-accent" />
                    {sectionChanges.length > 0 && (
                      <span className="absolute -top-1 -right-1 h-3 min-w-3 px-1 rounded-full bg-accent text-accent-foreground text-[8px] font-bold flex items-center justify-center">
                        {sectionChanges.length}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-heading text-sm font-semibold text-foreground tracking-wide">
                      {stat.sectionTitle}
                    </h3>
                    {def && <p className="text-xs text-muted-foreground mt-0.5">{def.description}</p>}
                    {lastChange && (
                      <p className="text-[10px] text-accent/70 mt-1 truncate">
                        Последнее: {lastChange.verdict?.post?.title || 'прямое изменение'} · {new Date(lastChange.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                      </p>
                    )}
                  </div>
                  <div className="text-muted-foreground shrink-0">
                    {isOpen ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                  </div>
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 pt-0 fade-in-up">
                    <div className="ornament-divider opacity-30 mb-3" />
                    <StatContent sectionKey={stat.sectionKey} content={content} />
                    {sectionChanges.length > 0 && (
                      <div className="mt-4 pt-3 border-t border-border/30">
                        <p className="text-[10px] uppercase tracking-wider font-heading text-muted-foreground mb-2 flex items-center gap-1">
                          <History className="h-3 w-3" /> История секции ({sectionChanges.length})
                        </p>
                        <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1 custom-scroll">
                          {sectionChanges.slice(0, 8).map((log) => (
                            <ChangeLogRow key={log.id} log={log} compact />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}

function pluralRecords(n: number): string {
  if (n % 10 === 1 && n % 100 !== 11) return 'запись'
  if ([2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100)) return 'записи'
  return 'записей'
}

// Рендер содержимого секции в зависимости от типа
function StatContent({ sectionKey, content }: { sectionKey: string; content: unknown }) {
  if (!content || typeof content !== 'object') {
    return <p className="text-sm text-muted-foreground italic">Нет данных</p>
  }

  const data = content as Record<string, unknown>
  const def = STAT_SECTIONS.find((s) => s.key === sectionKey)

  switch (sectionKey) {
    case 'NAME':
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Field label="Государство" value={data.state as string} />
          <Field label="Правитель" value={data.ruler as string} />
          <div className="md:col-span-2">
            <Field label="Девиз" value={data.motto as string} />
          </div>
        </div>
      )
    case 'TREASURY':
      return (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatBadge label="Доходы/мес" value={`${data.income ?? 0} солей`} trend="up" />
          <StatBadge label="Расходы/мес" value={`${data.expenses ?? 0} солей`} trend="down" />
          <StatBadge label="Баланс/мес" value={`${data.balance ?? 0} солей`} />
          <StatBadge label="Алмазная казна" value={`${data.diamondTreasury ?? 0} солей`} />
          <StatBadge label="Резерв" value={`${data.reserve ?? 0} солей`} />
          <StatBadge label="Малые займы" value={`${data.smallLoans ?? 0} солей`} />
          {data.shares && <Field label="Паи" value={data.shares as string} />}
          {data.pending && <Field label="Ждут денег" value={data.pending as string} />}
        </div>
      )
    case 'ARMY':
      return (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <StatBadge label="Пехота ближнего боя" value={`${data.meleeInfantry ?? 0} копейщиков`} />
          <StatBadge label="Пехота дальнего боя" value={`${data.rangedInfantry ?? 0} лучников`} />
          <StatBadge label="Кавалерия" value={`${data.cavalry ?? 0} всадников`} />
          <StatBadge label="Флот" value={`${data.fleet ?? 0} ушкуев`} />
          {data.orders && <Field label="Ордена" value={data.orders as string} />}
          {data.convoyService && <Field label="Конвойная служба" value={data.convoyService as string} />}
          {data.cadres && <Field label="Кадры" value={data.cadres as string} />}
        </div>
      )
    case 'POPULATION':
      return (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatBadge label="Всего" value={data.total ?? 0} />
          <StatBadge label="Власти" value={data.authorities ?? 0} />
          <StatBadge label="Гарнизоны" value={data.militaryGarrisons ?? 0} />
          <StatBadge label="Торговцы" value={data.tradeFamilies ?? 0} />
          <StatBadge label="Город/село" value={data.ruralUrban ?? 0} />
          <StatBadge label="Монастыри" value={data.monastery ?? 0} />
          <StatBadge label="Маги" value={data.mages ?? 0} />
          <StatBadge label="Бродяги" value={data.vagrants ?? 0} />
        </div>
      )
    case 'HORSES':
      return (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <StatBadge label="Поголовье" value={data.total ?? 0} />
          <StatBadge label="Приплод/год" value={data.offspring ?? 0} />
          <StatBadge label="Экспорт" value={data.exportObligations ?? 0} />
          <StatBadge label="Дефицит" value={data.deficit ?? 0} />
          {data.expeditions && <Field label="Экспедиции" value={data.expeditions as string} />}
          {data.rules && <Field label="Правила" value={data.rules as string} />}
          {data.mageService && <Field label="Маги при деле" value={data.mageService as string} />}
        </div>
      )
    case 'GOVERNANCE':
      return (
        <div className="space-y-3">
          <StatBadge label="Рейтинг управления" value={`${data.rating ?? 0}%`} />
          {data.senateHouses && <Field label="Дома Сената" value={data.senateHouses as string} />}
          {data.bureaucracy && <Field label="Бюрократия" value={data.bureaucracy as string} />}
          {data.planning && <Field label="Планирование" value={data.planning as string} />}
          {data.secretCourse && <Field label="Тайный курс" value={data.secretCourse as string} />}
          {data.prince && <Field label="Князь" value={data.prince as string} />}
        </div>
      )
    case 'RELIGION':
    case 'RELATIONS':
    case 'INSTITUTIONS':
    default:
      return <JsonContent data={data} sectionFields={def?.fields} />
  }
}

function Field({ label, value }: { label: string; value?: string }) {
  if (!value) return null
  return (
    <div className="p-3 rounded-md bg-muted/20 border border-border/30">
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-1">{label}</p>
      <p className="text-sm text-foreground">{value}</p>
    </div>
  )
}

function JsonContent({ data, sectionFields }: { data: Record<string, unknown>; sectionFields?: StatFieldDef[] }) {
  const entries = Object.entries(data)
  if (entries.length === 0) return <p className="text-sm text-muted-foreground italic">Нет данных</p>

  // Используем метаданные полей для красивых лейблов
  const labelOf = (key: string): string => {
    const f = sectionFields?.find((sf) => sf.key === key)
    return f?.label || key
  }

  return (
    <div className="space-y-2">
      {entries.map(([key, value]) => {
        const label = labelOf(key)
        if (Array.isArray(value)) {
          if (value.length === 0) return null
          return (
            <div key={key} className="p-3 rounded-md bg-muted/20 border border-border/30">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-2">{label}</p>
              <ul className="space-y-1.5">
                {value.map((item, i) => (
                  <li key={i} className="text-sm text-foreground/90 flex gap-2">
                    <span className="text-accent">•</span>
                    <span>{typeof item === 'object' ? JSON.stringify(item) : String(item)}</span>
                  </li>
                ))}
              </ul>
            </div>
          )
        }
        if (typeof value === 'object' && value !== null) {
          return (
            <div key={key} className="p-3 rounded-md bg-muted/20 border border-border/30">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-heading mb-2">{label}</p>
              <JsonContent data={value as Record<string, unknown>} />
            </div>
          )
        }
        return <Field key={key} label={label} value={String(value)} />
      })}
    </div>
  )
}

// Компактная строка истории изменений
function ChangeLogRow({ log, compact = false }: { log: ChangeLog; compact?: boolean }) {
  const def = STAT_SECTIONS.find((s) => s.key === log.sectionKey)
  const oldC = (log.oldValue as Record<string, unknown>) ?? null
  const newC = (log.newValue as Record<string, unknown>) ?? null

  // Найдём первое числовое поле, где есть diff (для краткого превью)
  const previewField = def?.fields.find((f) => {
    if (f.type !== 'number') return false
    const o = Number(oldC?.[f.key] ?? 0)
    const n = Number(newC?.[f.key] ?? 0)
    return o !== n
  })
  const delta = previewField
    ? Number(newC?.[previewField.key] ?? 0) - Number(oldC?.[previewField.key] ?? 0)
    : null

  const typeColor = {
    CREATE: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    UPDATE: 'bg-accent/20 text-accent border-accent/30',
    DELETE: 'bg-red-500/20 text-red-300 border-red-500/30',
  }[log.changeType] || 'bg-muted text-muted-foreground border-border/40'

  if (compact) {
    return (
      <div className="flex items-center gap-2 text-[11px] py-1">
        <Badge variant="outline" className={cn('text-[9px] uppercase px-1 py-0', typeColor)}>{log.changeType[0]}</Badge>
        <span className="text-muted-foreground truncate flex-1">{log.verdict?.post?.title || 'Прямое изменение'}</span>
        {delta !== null && (
          <span className={cn('font-medium', delta > 0 ? 'text-emerald-300' : 'text-red-300')}>
            {delta > 0 ? '+' : ''}{delta.toLocaleString('ru-RU')}
          </span>
        )}
        <span className="text-muted-foreground/60 shrink-0">{new Date(log.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}</span>
      </div>
    )
  }

  return (
    <div className="p-2.5 rounded-md bg-muted/15 border border-border/30 text-xs">
      <div className="flex items-center gap-2 mb-1 flex-wrap">
        <Badge variant="outline" className={cn('text-[9px] uppercase', typeColor)}>{log.changeType}</Badge>
        <span className="font-heading text-foreground text-[11px]">{def?.title || log.sectionKey}</span>
        <span className="text-muted-foreground/60 ml-auto">{new Date(log.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
      </div>
      <p className="text-[10px] text-muted-foreground">
        {log.verdict?.post?.title || 'Прямое изменение'} · {log.admin.name}
      </p>
      {delta !== null && previewField && (
        <div className="mt-1 flex items-center gap-1">
          {delta > 0 ? <TrendingUp className="h-3 w-3 text-emerald-400" /> : <TrendingDown className="h-3 w-3 text-red-400" />}
          <span className="text-[10px] text-muted-foreground">{previewField.label}:</span>
          <span className={cn('text-[10px] font-medium', delta > 0 ? 'text-emerald-300' : 'text-red-300')}>
            {delta > 0 ? '+' : ''}{delta.toLocaleString('ru-RU')}
          </span>
        </div>
      )}
    </div>
  )
}
