'use client'

import { useState, useMemo, useEffect, useRef } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toast as sonnerToast } from 'sonner'
import {
  Trophy, ScrollText, Shield, MessageSquare, Crown, BookOpen,
  PawPrint, Bookmark, Calendar, Compass, Loader2, Lock, Award,
  TrendingUp, Filter, Sparkles, Clock,
} from 'lucide-react'
import { motion } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { PageHeader, EmptyState } from '@/components/shared/ui-bits'
import { cn } from '@/lib/utils'

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  ScrollText, Shield, MessageSquare, Crown, BookOpen, PawPrint, Bookmark, Calendar, Compass,
}

interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  category: string
  tier: 'bronze' | 'silver' | 'gold'
  unlocked: boolean
  unlockedAt?: string | null
  isNew?: boolean
  progress: { current: number; target: number; percent: number }
}

interface AchievementData {
  achievements: Achievement[]
  byCategory: Record<string, Achievement[]>
  stats: Record<string, number>
  summary: { unlocked: number; total: number; percent: number }
}

const CATEGORY_LABELS: Record<string, { label: string; icon: React.ComponentType<{ className?: string }> }> = {
  posts: { label: 'Посты', icon: ScrollText },
  social: { label: 'Общение', icon: MessageSquare },
  verdicts: { label: 'Вердикты', icon: Crown },
  chronicle: { label: 'Хроника', icon: BookOpen },
  bestiary: { label: 'Бестиарий', icon: PawPrint },
  special: { label: 'Особые', icon: Sparkles },
}

const TIER_CONFIG: Record<string, { label: string; color: string; border: string; glow: string }> = {
  bronze: { label: 'Бронза', color: 'text-amber-600', border: 'border-amber-700/40', glow: 'shadow-amber-700/20' },
  silver: { label: 'Серебро', color: 'text-slate-300', border: 'border-slate-400/40', glow: 'shadow-slate-400/20' },
  gold: { label: 'Золото', color: 'text-amber-300', border: 'border-amber-400/50', glow: 'shadow-amber-400/30' },
}

export function AchievementsView() {
  const [filter, setFilter] = useState<'ALL' | 'unlocked' | 'locked'>('ALL')

  const { data, isLoading } = useQuery<AchievementData>({
    queryKey: ['achievements'],
    queryFn: async () => (await fetch('/api/achievements')).json(),
  })

  const achievements = data?.achievements || []
  const summary = data?.summary

  // Toast для недавно открытых достижений
  const prevNewIdsRef = useRef<Set<string>>(new Set())
  useEffect(() => {
    const newOnes = achievements.filter((a) => a.isNew)
    if (newOnes.length > 0) {
      const prevSet = prevNewIdsRef.current
      const trulyNew = newOnes.filter((a) => !prevSet.has(a.id))
      for (const ach of trulyNew) {
        sonnerToast.success(`🏆 Достижение открыто: ${ach.title}`, {
          description: ach.description,
        })
      }
      // Обновляем ref после показа
      const newSet = new Set(prevSet)
      for (const a of newOnes) newSet.add(a.id)
      prevNewIdsRef.current = newSet
    }
  }, [achievements])

  const filtered = useMemo(() => {
    if (filter === 'ALL') return achievements
    if (filter === 'unlocked') return achievements.filter((a) => a.unlocked)
    return achievements.filter((a) => !a.unlocked)
  }, [achievements, filter])

  return (
    <div className="space-y-5">
      <PageHeader
        title="Достижения"
        description="Награды за активность в Терском Мире"
      />

      {/* Summary */}
      {summary && (
        <Card className="ornate-border border-border/40 bg-gradient-to-br from-card/60 to-secondary/20 p-5 ambient-gradient">
          <div className="flex items-center gap-5 flex-wrap">
            <div className="relative h-20 w-20 shrink-0">
              <svg className="h-20 w-20 -rotate-90" viewBox="0 0 80 80">
                <circle cx="40" cy="40" r="34" fill="none" stroke="oklch(0.24 0.018 172)" strokeWidth="6" />
                <circle
                  cx="40" cy="40" r="34" fill="none"
                  stroke="oklch(0.70 0.13 175)" strokeWidth="6" strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 34 * summary.percent / 100} ${2 * Math.PI * 34}`}
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-heading text-xl font-bold text-foreground leading-none">{summary.percent}%</span>
                <span className="text-[9px] text-muted-foreground uppercase tracking-wider mt-0.5">открыто</span>
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <Trophy className="h-5 w-5 text-amber-400" />
                <h2 className="font-heading text-xl font-semibold text-foreground tracking-wide">Зал славы</h2>
              </div>
              <p className="text-sm text-muted-foreground">
                Открыто <strong className="text-foreground">{summary.unlocked}</strong> из <strong className="text-foreground">{summary.total}</strong> достижений
              </p>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <Badge className="bg-amber-700/20 text-amber-500 border-amber-700/30 text-[10px] gap-1">
                  <Award className="h-3 w-3" /> Бронза: {achievements.filter((a) => a.tier === 'bronze' && a.unlocked).length}
                </Badge>
                <Badge className="bg-slate-400/20 text-slate-300 border-slate-400/30 text-[10px] gap-1">
                  <Award className="h-3 w-3" /> Серебро: {achievements.filter((a) => a.tier === 'silver' && a.unlocked).length}
                </Badge>
                <Badge className="bg-amber-400/20 text-amber-300 border-amber-400/30 text-[10px] gap-1">
                  <Award className="h-3 w-3" /> Золото: {achievements.filter((a) => a.tier === 'gold' && a.unlocked).length}
                </Badge>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="h-3.5 w-3.5 text-muted-foreground" />
        {([
          { key: 'ALL' as const, label: 'Все' },
          { key: 'unlocked' as const, label: 'Открытые' },
          { key: 'locked' as const, label: 'Закрытые' },
        ]).map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              'px-3 py-1.5 rounded-md text-xs font-heading tracking-wide border transition-all',
              filter === f.key
                ? 'bg-accent text-accent-foreground border-accent shadow-sm'
                : 'border-border/40 text-muted-foreground hover:text-foreground hover:border-accent/30'
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Achievements grid grouped by category */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-accent" />
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={Trophy} title="Ничего не найдено" description="В выбранном фильтре нет достижений" />
      ) : (
        <div className="space-y-6">
          {Object.entries(data?.byCategory || {}).map(([catKey, catAchievements]) => {
            const catFiltered = catAchievements.filter((a) =>
              filter === 'ALL' ? true : filter === 'unlocked' ? a.unlocked : !a.unlocked
            )
            if (catFiltered.length === 0) return null
            const catMeta = CATEGORY_LABELS[catKey] || { label: catKey, icon: Award }
            const CatIcon = catMeta.icon
            const catUnlocked = catFiltered.filter((a) => a.unlocked).length

            return (
              <div key={catKey}>
                <div className="flex items-center gap-2 mb-3">
                  <CatIcon className="h-4 w-4 text-accent" />
                  <h3 className="font-heading text-sm font-semibold text-foreground tracking-wide uppercase">
                    {catMeta.label}
                  </h3>
                  <Badge variant="outline" className="text-[10px] text-muted-foreground">
                    {catUnlocked}/{catFiltered.length}
                  </Badge>
                  <div className="h-px flex-1 bg-border/40 ml-2" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {catFiltered.map((achievement, idx) => (
                    <AchievementCard key={achievement.id} achievement={achievement} index={idx} />
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function AchievementCard({ achievement, index }: { achievement: Achievement; index: number }) {
  const Icon = ICON_MAP[achievement.icon] || Award
  const tier = TIER_CONFIG[achievement.tier]

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Card className={cn(
        'border p-4 transition-all relative overflow-hidden',
        achievement.unlocked
          ? `${tier.border} bg-card/60 shadow-lg ${tier.glow}`
          : 'border-border/40 bg-card/20 opacity-70'
      )}>
        {achievement.unlocked && (
          <div className="absolute top-0 right-0 w-16 h-16 -mr-8 -mt-8 rounded-full bg-accent/10 blur-xl pointer-events-none" />
        )}
        <div className="flex items-start gap-3 relative">
          {/* Icon */}
          <div className={cn(
            'h-12 w-12 rounded-md flex items-center justify-center shrink-0 border-2',
            achievement.unlocked
              ? `${tier.color} ${tier.border} bg-card`
              : 'text-muted-foreground/50 border-border/40 bg-muted/20'
          )}>
            {achievement.unlocked ? <Icon className="h-6 w-6" /> : <Lock className="h-5 w-5" />}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <h4 className={cn(
                'font-heading text-sm font-semibold truncate',
                achievement.unlocked ? 'text-foreground' : 'text-muted-foreground'
              )}>
                {achievement.title}
              </h4>
              <Badge variant="outline" className={cn('text-[9px] uppercase shrink-0', tier.color, tier.border)}>
                {tier.label}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{achievement.description}</p>

            {/* Progress */}
            {!achievement.unlocked && (
              <div className="mt-2">
                <div className="flex items-center justify-between text-[10px] mb-1">
                  <span className="text-muted-foreground">Прогресс</span>
                  <span className="text-foreground font-medium">{achievement.progress.current}/{achievement.progress.target}</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted/40 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-accent transition-all duration-500"
                    style={{ width: `${Math.max(2, achievement.progress.percent)}%` }}
                  />
                </div>
              </div>
            )}
            {achievement.unlocked && (
              <div className="flex items-center justify-between gap-2 mt-1">
                <div className="flex items-center gap-1 text-[10px] text-emerald-400">
                  <TrendingUp className="h-3 w-3" />
                  <span>Открыто</span>
                </div>
                {achievement.isNew && (
                  <Badge className="bg-amber-500/30 text-amber-200 border-amber-500/40 text-[9px] gap-0.5 badge-pulse">
                    <Sparkles className="h-2.5 w-2.5" /> NEW
                  </Badge>
                )}
                {achievement.unlockedAt && !achievement.isNew && (
                  <span className="text-[9px] text-muted-foreground/60 flex items-center gap-0.5">
                    <Clock className="h-2.5 w-2.5" />
                    {new Date(achievement.unlockedAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  )
}
