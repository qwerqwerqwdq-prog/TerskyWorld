'use client'

import { useState, useMemo } from 'react'
import {
  Flag, Handshake, Coins, Swords, Church, Users, Sparkles,
  Building2, Crown, ChevronDown, Plus, Minus, Check, X, AlertCircle,
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { STAT_SECTIONS, type StatFieldDef } from '@/lib/constants'

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Flag, Handshake, Coins, Swords, Church, Users, Sparkles, Building2, Crown,
}

export interface StatContent {
  [key: string]: unknown
}

export interface StatChange {
  sectionKey: string
  sectionTitle?: string
  oldContent?: unknown
  newContent: unknown
}

interface StatSectionEditorProps {
  sectionKey: string
  currentContent: StatContent | null
  initialContent?: StatContent | null
  onChange: (newContent: StatContent | null, isModified: boolean) => void
  defaultOpen?: boolean
}

export function StatSectionEditor({
  sectionKey,
  currentContent,
  initialContent,
  onChange,
  defaultOpen = false,
}: StatSectionEditorProps) {
  const def = STAT_SECTIONS.find((s) => s.key === sectionKey)
  const SectionIcon = useMemo(() => {
    if (!def) return Flag
    return ICON_MAP[def.icon] || Flag
  }, [def])

  const baseContent = (initialContent ?? currentContent ?? def?.defaultContent ?? {}) as StatContent
  const [open, setOpen] = useState(defaultOpen)
  const [enabled, setEnabled] = useState(initialContent !== undefined)
  const [content, setContent] = useState<StatContent>({ ...baseContent })

  const diff = useMemo(() => computeDiff(def?.fields || [], currentContent ?? {}, content), [content, currentContent, def])
  const hasChanges = diff.length > 0

  const toggleEnabled = () => {
    const next = !enabled
    setEnabled(next)
    if (!next) {
      onChange(null, false)
    } else {
      const d = computeDiff(def?.fields || [], currentContent ?? {}, content)
      onChange(content, d.length > 0)
    }
  }

  const updateField = (key: string, value: unknown) => {
    const next = { ...content, [key]: value }
    setContent(next)
    if (enabled) {
      const d = computeDiff(def?.fields || [], currentContent ?? {}, next)
      onChange(next, d.length > 0)
    }
  }

  if (!def) return null

  return (
    <div className={cn(
      'rounded-md border bg-card/30 transition-all overflow-hidden',
      enabled ? 'border-accent/40 shadow-sm' : 'border-border/40',
      hasChanges && enabled && 'ring-1 ring-accent/30'
    )}>
      <div className="flex items-center gap-3 p-3">
        <button
          type="button"
          onClick={toggleEnabled}
          className={cn(
            'h-5 w-5 rounded border flex items-center justify-center shrink-0 transition-colors',
            enabled ? 'bg-accent border-accent text-accent-foreground' : 'border-border/60 hover:border-accent/50'
          )}
          aria-label={enabled ? 'Исключить секцию' : 'Включить секцию'}
        >
          {enabled && <Check className="h-3 w-3" />}
        </button>
        <div className="h-8 w-8 rounded-md bg-accent/15 border border-accent/30 flex items-center justify-center shrink-0">
          <SectionIcon className="h-4 w-4 text-accent" />
        </div>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex-1 flex items-center gap-3 text-left min-w-0"
        >
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="font-heading text-sm font-semibold text-foreground tracking-wide truncate">{def.title}</h4>
              {hasChanges && enabled && (
                <Badge className="bg-accent/20 text-accent border-accent/30 text-[10px] gap-1">
                  <AlertCircle className="h-2.5 w-2.5" /> {diff.length} изм.
                </Badge>
              )}
              {!currentContent && (
                <Badge variant="outline" className="text-[10px] border-amber-500/30 text-amber-300">новая</Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground truncate">{def.description}</p>
          </div>
          <ChevronDown className={cn('h-4 w-4 text-muted-foreground transition-transform shrink-0', open && 'rotate-180')} />
        </button>
      </div>

      {enabled && hasChanges && (
        <div className="px-3 pb-2">
          <div className="rounded-md bg-accent/5 border border-accent/20 p-2.5 space-y-1.5">
            <p className="text-[10px] uppercase tracking-wider font-heading text-accent/80">Изменения</p>
            {diff.map((d, i) => (
              <div key={i} className="flex items-center gap-2 text-xs flex-wrap">
                <span className="text-muted-foreground">{d.label}:</span>
                <span className="text-red-300 line-through opacity-70">{d.oldValue}</span>
                <span className="text-accent">→</span>
                <span className="text-emerald-300 font-medium">{d.newValue}</span>
                {d.delta !== null && (
                  <Badge className={cn('text-[10px] gap-0.5', d.delta > 0 ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-red-500/20 text-red-300 border-red-500/30')}>
                    {d.delta > 0 ? '+' : ''}{d.delta}
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {open && enabled && (
        <div className="px-3 pb-3 fade-in-up">
          <div className="ornament-divider opacity-20 mb-3" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {def.fields.map((field) => (
              <FieldEditor
                key={field.key}
                field={field}
                value={content[field.key]}
                onChange={(v) => updateField(field.key, v)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function FieldEditor({
  field,
  value,
  onChange,
}: {
  field: StatFieldDef
  value: unknown
  onChange: (v: unknown) => void
}) {
  if (field.type === 'number') {
    return (
      <div className="space-y-1">
        <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-heading">{field.label}</label>
        <div className="flex items-center gap-1">
          <Input
            type="number"
            value={value as number ?? 0}
            onChange={(e) => onChange(Number(e.target.value) || 0)}
            className="bg-background/60 h-8 text-sm"
          />
          {field.unit && (
            <span className="text-[10px] text-muted-foreground shrink-0">{field.unit}</span>
          )}
        </div>
      </div>
    )
  }

  if (field.type === 'longtext') {
    return (
      <div className="space-y-1 md:col-span-2">
        <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-heading">{field.label}</label>
        <Textarea
          value={(value as string) || ''}
          onChange={(e) => onChange(e.target.value)}
          className="bg-background/60 text-sm min-h-[60px]"
          placeholder={field.placeholder}
        />
      </div>
    )
  }

  if (field.type === 'list') {
    const items = Array.isArray(value) ? value : []
    return (
      <div className="space-y-1 md:col-span-2">
        <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-heading">{field.label}</label>
        <ListEditor items={items as string[]} onChange={(v) => onChange(v)} />
      </div>
    )
  }

  return (
    <div className="space-y-1">
      <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-heading">{field.label}</label>
      <Input
        value={(value as string) || ''}
        onChange={(e) => onChange(e.target.value)}
        className="bg-background/60 h-8 text-sm"
        placeholder={field.placeholder}
      />
    </div>
  )
}

function ListEditor({ items, onChange }: { items: string[]; onChange: (v: string[]) => void }) {
  const [input, setInput] = useState('')

  const add = () => {
    const v = input.trim()
    if (!v) return
    onChange([...items, v])
    setInput('')
  }

  const remove = (idx: number) => {
    onChange(items.filter((_, i) => i !== idx))
  }

  return (
    <div className="space-y-2">
      {items.length > 0 && (
        <ul className="space-y-1">
          {items.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-sm bg-muted/20 border border-border/30 rounded p-1.5">
              <span className="text-accent shrink-0">•</span>
              <span className="flex-1 break-words">{item}</span>
              <button
                type="button"
                onClick={() => remove(i)}
                className="text-muted-foreground hover:text-destructive shrink-0"
              >
                <X className="h-3 w-3" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="flex items-center gap-1.5">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add() } }}
          placeholder="Добавить запись..."
          className="bg-background/60 h-8 text-sm"
        />
        <Button type="button" variant="outline" size="sm" onClick={add} className="h-8 px-2 shrink-0">
          <Plus className="h-3 w-3" />
        </Button>
      </div>
    </div>
  )
}

interface DiffEntry {
  label: string
  oldValue: string
  newValue: string
  delta: number | null
}

function computeDiff(fields: StatFieldDef[], old: StatContent, newC: StatContent): DiffEntry[] {
  const out: DiffEntry[] = []
  for (const f of fields) {
    const o = old[f.key]
    const n = newC[f.key]
    if (f.type === 'number') {
      const on = Number(o ?? 0)
      const nn = Number(n ?? 0)
      if (on !== nn) {
        out.push({ label: f.label, oldValue: formatNum(on), newValue: formatNum(nn), delta: nn - on })
      }
    } else if (f.type === 'list') {
      const oa = Array.isArray(o) ? o as string[] : []
      const na = Array.isArray(n) ? n as string[] : []
      if (JSON.stringify(oa) !== JSON.stringify(na)) {
        out.push({ label: f.label, oldValue: `${oa.length} зап.`, newValue: `${na.length} зап.`, delta: na.length - oa.length })
      }
    } else {
      const os = String(o ?? '')
      const ns = String(n ?? '')
      if (os !== ns) {
        out.push({ label: f.label, oldValue: os || '—', newValue: ns || '—', delta: null })
      }
    }
  }
  return out
}

function formatNum(n: number): string {
  return n.toLocaleString('ru-RU')
}
