'use client'

import { ReactNode, useEffect } from 'react'
import { ThemeProvider } from 'next-themes'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useState } from 'react'
import { FirebaseAuthProvider } from '@/lib/auth-context'

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30 * 1000,
            refetchOnWindowFocus: false,
            retry: 1,
          },
        },
      })
  )

  // Anti-scraping: блокировка контекстного меню, drag, копирования, горячих клавиш
  useEffect(() => {
    const blockContext = (e: MouseEvent) => {
      e.preventDefault()
      return false
    }
    const blockDrag = (e: DragEvent) => {
      e.preventDefault()
      return false
    }
    const blockCopy = (e: ClipboardEvent) => {
      const target = e.target as HTMLElement
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
        return
      }
      e.preventDefault()
      return false
    }
    const blockKeys = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase()
      if (e.key === 'F12') {
        e.preventDefault()
        return false
      }
      if (e.ctrlKey && e.shiftKey && (key === 'i' || key === 'j' || key === 'c')) {
        e.preventDefault()
        return false
      }
      if (e.ctrlKey && (key === 'u' || key === 's' || key === 'p')) {
        e.preventDefault()
        return false
      }
    }

    document.addEventListener('contextmenu', blockContext)
    document.addEventListener('dragstart', blockDrag)
    document.addEventListener('copy', blockCopy)
    document.addEventListener('cut', blockCopy)
    document.addEventListener('keydown', blockKeys)

    return () => {
      document.removeEventListener('contextmenu', blockContext)
      document.removeEventListener('dragstart', blockDrag)
      document.removeEventListener('copy', blockCopy)
      document.removeEventListener('cut', blockCopy)
      document.removeEventListener('keydown', blockKeys)
    }
  }, [])

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" forcedTheme="dark" enableSystem={false}>
      <FirebaseAuthProvider>
        <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
      </FirebaseAuthProvider>
    </ThemeProvider>
  )
}
