'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Lock, User, Loader2, Shield, ScrollText, ChevronRight, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'
import { Logo } from '@/components/layout/logo'
import { useAuth } from '@/lib/auth-context'

export function AuthScreen() {
  const { login, register } = useAuth()
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [loading, setLoading] = useState(false)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (mode === 'register') {
        const { role } = await register(name, email, password)
        toast({
          title: role === 'ADMIN' ? 'Аккаунт администратора создан' : 'Добро пожаловать',
          description: role === 'ADMIN' ? 'Вы первый игрок — вам присвоены права администратора мира.' : 'Да пребудет с вами мудрость предков.',
        })
        setPassword('')
      } else {
        await login(email, password)
        toast({ title: 'Вход выполнен', description: 'Да пребудет с вами мудрость предков' })
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Что-то пошло не так'
      // Более дружелюбные сообщения для типичных ошибок Firebase
      let friendly = msg
      if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password') || msg.includes('auth/user-not-found')) {
        friendly = 'Неверный email или пароль'
      } else if (msg.includes('auth/email-already-in-use')) {
        friendly = 'Пользователь с таким email уже существует'
      } else if (msg.includes('auth/weak-password')) {
        friendly = 'Пароль должен быть минимум 6 символов'
      } else if (msg.includes('auth/invalid-email')) {
        friendly = 'Некорректный email'
      } else if (msg.includes('auth/too-many-requests')) {
        friendly = 'Слишком много попыток. Попробуйте позже'
      } else if (msg.includes('auth/network-request-failed')) {
        friendly = 'Проблема с сетью. Проверьте подключение'
      } else if (msg.includes('заблокирован') || msg.includes('забанен')) {
        friendly = msg
      }
      toast({
        title: 'Ошибка',
        description: friendly,
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-background relative overflow-hidden">
      {/* Декоративный фон */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-secondary/30 via-background to-background" />
        <div className="absolute top-0 left-0 right-0 h-12 ornament-divider opacity-40" />
        <div className="absolute bottom-0 left-0 right-0 h-12 ornament-divider opacity-40" />
      </div>

      {/* Левая часть — герой */}
      <div className="hidden lg:flex flex-1 flex-col justify-center items-center p-12 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-md text-center space-y-8"
        >
          <div className="flex justify-center">
            <Logo size={120} className="flicker" />
          </div>
          <div className="space-y-3">
            <h1 className="font-heading text-5xl font-bold text-foreground text-glow tracking-wider">
              ТЕРСКИЙ МИР
            </h1>
            <p className="text-muted-foreground font-heading text-sm tracking-[0.3em] uppercase">
              Ролевая · Военно · Политическая · Игра
            </p>
          </div>
          <div className="ornament-divider w-full opacity-60" />
          <p className="text-muted-foreground text-lg italic leading-relaxed">
            «Великие княжества рождаются не мечом единым, но словом, золотом и мудростью
            правителей своих»
          </p>
          <div className="grid grid-cols-3 gap-4 pt-6">
            <Feature icon={<Shield className="h-5 w-5" />} label="Дипломатия" />
            <Feature icon={<ScrollText className="h-5 w-5" />} label="Хроника" />
            <Feature icon={<ChevronRight className="h-5 w-5" />} label="Война" />
          </div>
        </motion.div>
      </div>

      {/* Правая часть — форма */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full max-w-md"
        >
          <div className="lg:hidden flex flex-col items-center gap-4 mb-8">
            <Logo size={72} className="flicker" />
            <h1 className="font-heading text-3xl font-bold text-glow tracking-wider">ТЕРСКИЙ МИР</h1>
          </div>

          <div className="ornate-border bg-card/80 backdrop-blur-sm border border-border/60 rounded-lg p-8 shadow-2xl glow-teal">
            <div className="flex gap-2 mb-6 p-1 bg-muted/40 rounded-md">
              <button
                onClick={() => setMode('login')}
                className={`flex-1 py-2 text-sm font-heading tracking-wide rounded transition-colors ${
                  mode === 'login'
                    ? 'bg-accent text-accent-foreground shadow'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Вход
              </button>
              <button
                onClick={() => setMode('register')}
                className={`flex-1 py-2 text-sm font-heading tracking-wide rounded transition-colors ${
                  mode === 'register'
                    ? 'bg-accent text-accent-foreground shadow'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Регистрация
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div className="space-y-1.5">
                  <Label htmlFor="name" className="text-xs uppercase tracking-wider text-muted-foreground">
                    Имя правителя
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Князь Светослав"
                      className="pl-9"
                      required
                      minLength={2}
                      maxLength={50}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs uppercase tracking-wider text-muted-foreground">
                  Email
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="knyaz@tersky.ru"
                    className="pl-9"
                    required
                    autoComplete="email"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs uppercase tracking-wider text-muted-foreground">
                  Пароль
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="pl-9"
                    required
                    minLength={6}
                    autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  />
                </div>
                {mode === 'register' && (
                  <p className="text-[10px] text-muted-foreground/70">
                    Минимум 6 символов. Запомните пароль — восстановление через email.
                  </p>
                )}
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full btn-ornament"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    {mode === 'login' ? 'Входим в мир...' : 'Создаём княжество...'}
                  </>
                ) : (
                  <>
                    {mode === 'login' ? 'Войти в мир' : 'Создать княжество'}
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 flex items-center gap-2 justify-center text-[10px] text-muted-foreground/60">
              <AlertCircle className="h-3 w-3" />
              <span>Первый зарегистрированный игрок становится Администратором мира</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

function Feature({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex flex-col items-center gap-2 p-3 rounded-md border border-border/30 bg-card/40">
      <div className="text-accent">{icon}</div>
      <span className="text-[10px] font-heading tracking-wider uppercase text-muted-foreground">{label}</span>
    </div>
  )
}
