'use client'

import { useEffect, useState } from 'react'
import { Copy, ExternalLink, Flame, KeyRound, CheckCircle2, XCircle, AlertTriangle, RefreshCw } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { Logo } from '@/components/layout/logo'
import { Button } from '@/components/ui/button'
import { firebaseConfig, isFirebaseConfigured } from '@/lib/firebase-client'

const ENV_TEMPLATE = `# ===== Firebase Client (видимы в браузере) =====
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=

# ===== Firebase Admin (только сервер) =====
FIREBASE_PROJECT_ID=
FIREBASE_CLIENT_EMAIL=
FIREBASE_PRIVATE_KEY=
`

interface CheckResult {
  ok: boolean
  detail?: string
}

export function FirebaseSetupScreen() {
  const { toast } = useToast()
  const [serverCheck, setServerCheck] = useState<CheckResult | null>(null)
  const [checking, setChecking] = useState(false)

  // Проверка серверной части: /api/session без auth должен вернуть 200 с {"user":null}
  // Если 500 — серверный Firebase Admin SDK не инициализирован (скорее всего FIREBASE_PRIVATE_KEY)
  const checkServer = async () => {
    setChecking(true)
    try {
      const res = await fetch('/api/session', {
        headers: { 'Cache-Control': 'no-cache' },
      })
      if (res.ok) {
        const data = await res.json()
        setServerCheck({ ok: true, detail: 'Серверная часть работает' })
      } else if (res.status === 500) {
        let detail = 'HTTP 500'
        try {
          const data = await res.json()
          detail = data.error || data.message || 'HTTP 500'
        } catch { /* noop */ }
        setServerCheck({
          ok: false,
          detail: `Серверная ошибка: ${detail}. Проверьте FIREBASE_PRIVATE_KEY и FIREBASE_CLIENT_EMAIL на Vercel.`,
        })
      } else {
        setServerCheck({ ok: false, detail: `HTTP ${res.status}` })
      }
    } catch (e) {
      setServerCheck({ ok: false, detail: e instanceof Error ? e.message : 'Network error' })
    } finally {
      setChecking(false)
    }
  }

  useEffect(() => {
    // Автоматически проверяем сервер при загрузке (только если клиентские vars настроены)
    if (isFirebaseConfigured) {
      checkServer()
    }
  }, [])

  const copyEnv = () => {
    navigator.clipboard.writeText(ENV_TEMPLATE)
    toast({ title: 'Шаблон .env скопирован', description: 'Вставьте значения из Firebase Console' })
  }

  // Список клиентских env vars и их текущие значения
  const clientVars: Array<{ name: string; value: string | undefined; required: boolean }> = [
    { name: 'NEXT_PUBLIC_FIREBASE_API_KEY', value: firebaseConfig.apiKey, required: true },
    { name: 'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN', value: firebaseConfig.authDomain, required: true },
    { name: 'NEXT_PUBLIC_FIREBASE_PROJECT_ID', value: firebaseConfig.projectId, required: true },
    { name: 'NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET', value: firebaseConfig.storageBucket, required: false },
    { name: 'NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID', value: firebaseConfig.messagingSenderId, required: false },
    { name: 'NEXT_PUBLIC_FIREBASE_APP_ID', value: firebaseConfig.appId, required: true },
  ]

  const clientOk = clientVars.filter((v) => v.required && v.value).length === 4
  const serverOk = serverCheck?.ok ?? false

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="max-w-3xl w-full ornate-border bg-card/80 backdrop-blur-sm border border-border/60 rounded-lg p-8 shadow-2xl">
        <div className="flex items-center gap-3 mb-6">
          <Logo size={48} />
          <div>
            <h1 className="font-heading text-2xl font-bold text-foreground tracking-wider">ТЕРСКИЙ МИР</h1>
            <p className="text-xs text-muted-foreground uppercase tracking-widest">Настройка Firebase</p>
          </div>
        </div>

        {/* Статус проверки */}
        <div className="space-y-3 mb-6">
          {/* Клиентская часть */}
          <div className={`flex items-start gap-3 p-3 rounded-md border ${
            clientOk
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
              : 'bg-red-500/10 border-red-500/30 text-red-200'
          }`}>
            {clientOk ? (
              <CheckCircle2 className="h-5 w-5 mt-0.5 shrink-0" />
            ) : (
              <XCircle className="h-5 w-5 mt-0.5 shrink-0" />
            )}
            <div className="flex-1 text-sm">
              <p className="font-medium">
                {clientOk ? 'Клиентская часть настроена' : 'Клиентская часть НЕ настроена'}
              </p>
              <p className="text-xs opacity-80 mt-1">
                NEXT_PUBLIC_FIREBASE_* env vars {clientOk ? 'найдены в браузере' : 'отсутствуют в браузере'}
              </p>
              {!clientOk && (
                <p className="text-xs opacity-80 mt-1">
                  Добавьте их в <strong>Vercel → Settings → Environment Variables</strong> и сделайте <strong>Redeploy</strong>.
                </p>
              )}
            </div>
          </div>

          {/* Серверная часть */}
          <div className={`flex items-start gap-3 p-3 rounded-md border ${
            serverOk
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
              : serverCheck?.detail
                ? 'bg-red-500/10 border-red-500/30 text-red-200'
                : 'bg-muted/30 border-border/40 text-muted-foreground'
          }`}>
            {serverOk ? (
              <CheckCircle2 className="h-5 w-5 mt-0.5 shrink-0" />
            ) : serverCheck?.detail ? (
              <XCircle className="h-5 w-5 mt-0.5 shrink-0" />
            ) : (
              <AlertTriangle className="h-5 w-5 mt-0.5 shrink-0" />
            )}
            <div className="flex-1 text-sm">
              <div className="flex items-center gap-2">
                <p className="font-medium">
                  {serverOk ? 'Серверная часть работает' : 'Серверная часть: проблема с FIREBASE_*'}
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2 text-xs"
                  onClick={checkServer}
                  disabled={checking}
                >
                  {checking ? <RefreshCw className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                  <span className="ml-1">Проверить</span>
                </Button>
              </div>
              {serverCheck?.detail && (
                <p className="text-xs opacity-90 mt-1 break-words">{serverCheck.detail}</p>
              )}
              {!serverCheck && !checking && (
                <p className="text-xs opacity-80 mt-1">
                  Нажмите «Проверить» чтобы протестировать серверный Firebase Admin SDK
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Детали по переменным */}
        <details className="mb-6 group">
          <summary className="cursor-pointer text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2">
            <KeyRound className="h-3.5 w-3.5" />
            <span>Детали по переменным окружения</span>
          </summary>
          <div className="mt-3 space-y-1.5 text-xs">
            <p className="text-muted-foreground mb-2">Клиентские (видны в браузере):</p>
            {clientVars.map((v) => (
              <div key={v.name} className="flex items-center gap-2 font-mono">
                {v.value ? (
                  <CheckCircle2 className="h-3 w-3 text-emerald-400 shrink-0" />
                ) : (
                  <XCircle className="h-3 w-3 text-red-400 shrink-0" />
                )}
                <span className="text-foreground">{v.name}</span>
                <span className="text-muted-foreground ml-auto truncate">
                  {v.value ? `${v.value.slice(0, 12)}…` : '(пусто)'}
                </span>
              </div>
            ))}
            <p className="text-muted-foreground mt-3 mb-2">Серверные (только на Vercel):</p>
            {['FIREBASE_PROJECT_ID', 'FIREBASE_CLIENT_EMAIL', 'FIREBASE_PRIVATE_KEY'].map((name) => (
              <div key={name} className="flex items-center gap-2 font-mono">
                <AlertTriangle className="h-3 w-3 text-amber-400 shrink-0" />
                <span className="text-foreground">{name}</span>
                <span className="text-muted-foreground ml-auto text-[10px]">(проверьте в Vercel)</span>
              </div>
            ))}
          </div>
        </details>

        {/* Инструкция */}
        <div className="space-y-4 text-sm text-muted-foreground leading-relaxed">
          <div className="flex items-start gap-2 p-3 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
            <Flame className="h-4 w-4 mt-0.5 shrink-0" />
            <div>
              <p className="font-medium mb-1">Что нужно сделать на Vercel:</p>
              <ol className="list-decimal list-inside space-y-1 opacity-90">
                <li>Откройте <strong>Vercel → ваш проект → Settings → Environment Variables</strong></li>
                <li>Добавьте ВСЕ 9 переменных (6 клиентских + 3 серверных) из `.env.example`</li>
                <li>Для <code className="text-accent">FIREBASE_PRIVATE_KEY</code> вставьте значение целиком, с <code>\n</code> переносами</li>
                <li>Вернитесь в <strong>Deployments</strong> → нажмите <strong>Redeploy</strong> на последнем деплое</li>
                <li>После завершения редеплоя — обновите эту страницу</li>
              </ol>
            </div>
          </div>

          <details className="group">
            <summary className="cursor-pointer text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2">
              <ExternalLink className="h-3.5 w-3.5" />
              <span>Полная инструкция по настройке Firebase Console</span>
            </summary>
            <ol className="mt-3 space-y-2 list-decimal list-inside text-xs">
              <li>
                Откройте <a href="https://console.firebase.google.com/" target="_blank" rel="noreferrer" className="text-accent underline inline-flex items-center gap-1">
                  console.firebase.google.com <ExternalLink className="h-3 w-3" />
                </a> и нажмите <strong>«Add project»</strong>.
              </li>
              <li>В <strong>Build → Authentication → Get started</strong> включите <strong>Email/Password</strong>.</li>
              <li>В <strong>Build → Firestore Database → Create database</strong>. Регион: <code className="text-accent">europe-west1</code>. Режим: production.</li>
              <li>В <strong>Project settings → General → Your apps</strong> нажмите <code className="text-accent">&lt;/&gt;</code> (Web). Скопируйте <code className="text-accent">firebaseConfig</code>.</li>
              <li>В <strong>Project settings → Service accounts → Generate new private key</strong> — скачается JSON. Возьмите <code className="text-accent">project_id</code>, <code className="text-accent">client_email</code>, <code className="text-accent">private_key</code>.</li>
              <li>Добавьте эти значения в Vercel Environment Variables.</li>
            </ol>
          </details>

          <button
            onClick={copyEnv}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-md border border-border/50 bg-secondary/40 hover:bg-secondary/60 transition-colors text-sm"
          >
            <KeyRound className="h-4 w-4 text-accent" />
            <Copy className="h-4 w-4" />
            <span>Скопировать шаблон .env</span>
          </button>

          <Button
            onClick={() => window.location.reload()}
            className="w-full"
            variant="default"
            size="lg"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Я добавил переменные — обновить страницу
          </Button>
        </div>

        <p className="mt-6 text-center text-[10px] text-muted-foreground/60 italic">
          РВПИ Терский Мир · v1.0 · Powered by Firebase
        </p>
      </div>
    </div>
  )
}
