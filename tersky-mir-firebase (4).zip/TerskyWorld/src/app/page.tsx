'use client'

import { useAuth } from '@/lib/auth-context'
import { AuthScreen } from '@/components/auth/auth-screen'
import { AppShell } from '@/components/layout/app-shell'
import { LoadingScreen } from '@/components/layout/loading-screen'
import { FirebaseSetupScreen } from '@/components/auth/firebase-setup-screen'

export default function Home() {
  const { user, loading, error, isDemoMode } = useAuth()

  if (loading) return <LoadingScreen />

  // Если Firebase не настроен И не demo mode — показываем экран настройки
  if (error === 'FIREBASE_NOT_CONFIGURED' && !isDemoMode) return <FirebaseSetupScreen />

  // Demo mode: показываем обычный экран входа (auth-context сам переключится на demo)
  if (!user) return <AuthScreen />

  return <AppShell />
}
