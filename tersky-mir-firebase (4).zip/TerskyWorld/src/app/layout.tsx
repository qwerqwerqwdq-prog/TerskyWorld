import type { Metadata } from "next";
import { Cinzel, Cormorant_Garamond, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { Providers } from "@/components/providers";
import { DemoModeBadge } from "@/components/shared/demo-mode-badge";

const cinzel = Cinzel({
  variable: "--font-cinzel",
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800", "900"],
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-geist-mono",
  subsets: ["cyrillic", "latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Терский Мир — РВПИ",
  description: "Ролевая-Военно-Политическая Игра «Терский Мир»",
  keywords: ["Терский Мир", "РВПИ", "ролевая игра", "политика", "война"],
  authors: [{ name: "Терский Мир" }],
  robots: {
    index: false,
    follow: false,
    nocache: true,
    googleBot: {
      index: false,
      follow: false,
      noimageindex: true,
      "max-image-preview": "none",
      "max-snippet": 0,
      "max-video-preview": 0,
    },
  },
  xRobotsTag: "noindex, nofollow, noarchive, nosnippet, noimageindex",
  openGraph: {
    title: "Терский Мир",
    description: "Закрытая ролевая-военно-политическая игра",
    type: "website",
  },
  httpEquiv: {
    "Content-Security-Policy": "default-src 'self'",
  },
};

export const viewport = {
  themeColor: "#0a0f0f",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning className="dark">
      <head>
        {/* Anti-scraping: запрет индексации и кэширования */}
        <meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate" />
        <meta name="googlebot" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate" />
        <meta name="referrer" content="no-referrer" />
        <meta httpEquiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0" />
        <meta httpEquiv="Pragma" content="no-cache" />
        <meta httpEquiv="Expires" content="0" />
        <meta name="rating" content="restricted" />
        <meta name="distribution" content="private" />
      </head>
      <body
        className={`${cinzel.variable} ${cormorant.variable} ${jetbrainsMono.variable} antialiased dark noselect`}
      >
        <Providers>
          {children}
          <DemoModeBadge />
        </Providers>
        <Toaster />
        <SonnerToaster position="top-right" />
      </body>
    </html>
  );
}
