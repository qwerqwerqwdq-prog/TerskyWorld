import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi, toApiDate } from '@/lib/firestore'

function safeParse(s: string | null | undefined): unknown {
  if (!s) return null
  try { return JSON.parse(s) } catch { return s }
}

// GET /api/directory/[id] — публичные данные утверждённой фракции
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAuth(_req)
  const { id } = await params
  const db = getAdminDb()

  const factionSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
  if (!factionSnap.exists) return errorResponse('Фракция не найдена', 404)
  const factionData = factionSnap.data() as any
  if (!factionData.isApproved) return errorResponse('Княжество ещё не утверждено', 403)

  // Parallel: user, stats, recentPosts (last 5 VERDICTED), recentChanges (last 10)
  const [userSnap, statsSnap, recentPostsSnap, recentChangesSnap, postsCountSnap, statLogsCountSnap] = await Promise.all([
    factionData.userId ? db.collection(COLLECTIONS.users).doc(factionData.userId).get() : Promise.resolve(null),
    // composite index required: (factionId, order)
    db.collection(COLLECTIONS.factionStats).where('factionId', '==', id).orderBy('order', 'asc').get(),
    // composite index required: (factionId, status, createdAt)
    db.collection(COLLECTIONS.posts)
      .where('factionId', '==', id)
      .where('status', '==', 'VERDICTED')
      .orderBy('createdAt', 'desc')
      .limit(5)
      .get(),
    // composite index required: (factionId, createdAt)
    db.collection(COLLECTIONS.statChangeLogs)
      .where('factionId', '==', id)
      .orderBy('createdAt', 'desc')
      .limit(10)
      .get(),
    db.collection(COLLECTIONS.posts).where('factionId', '==', id).count().get(),
    db.collection(COLLECTIONS.statChangeLogs).where('factionId', '==', id).count().get(),
  ])

  // Build user object
  let user: any = null
  if (userSnap && userSnap.exists) {
    const uData = userSnap.data() as any
    user = {
      id: userSnap.id,
      name: uData.name,
      avatar: uData.avatar || null,
      bio: uData.bio || null,
      createdAt: toApiDate(uData.createdAt),
    }
  }

  const stats = statsSnap.docs.map((s) => {
    const d = docToApi(s as any) as any
    return { ...d, content: safeParse(d.content) }
  })

  // Recent posts: get verdict for each
  const recentPosts = recentPostsSnap.docs.map((d) => docToApi(d as any)) as any[]
  const postIds = recentPosts.map((p) => p.id)

  const verdictSnapsForPosts = await Promise.all(
    postIds.map((pid) =>
      db.collection(COLLECTIONS.verdicts).where('postId', '==', pid).limit(1).get()
    )
  )

  const verdictAdminIds: string[] = []
  const verdictsByPostId = new Map<string, any>()
  verdictSnapsForPosts.forEach((vs, i) => {
    if (!vs.empty) {
      const vDoc = vs.docs[0]
      const vData = vDoc.data() as any
      verdictsByPostId.set(postIds[i], {
        id: vDoc.id,
        roleplayText: vData.roleplayText,
        createdAt: toApiDate(vData.createdAt),
        statChanges: vData.statChanges ?? null,
      })
      if (vData.adminId) verdictAdminIds.push(vData.adminId)
    }
  })

  const verdictAdminSnaps = await Promise.all(
    [...new Set(verdictAdminIds)].map((aid) => db.collection(COLLECTIONS.users).doc(aid).get())
  )
  const adminMap = new Map<string, any>()
  verdictAdminSnaps.forEach((s) => {
    if (s.exists) adminMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  const postsWithVerdict = recentPosts.map((p) => {
    const verdict = verdictsByPostId.get(p.id)
    let verdictWithAdmin: any = null
    if (verdict) {
      // Find admin for this verdict
      const vSnap = verdictSnapsForPosts.find((vs) => !vs.empty && vs.docs[0].id === verdict.id)
      const vData = vSnap?.docs[0]?.data() as any
      const admin = vData?.adminId ? adminMap.get(vData.adminId) || null : null
      verdictWithAdmin = {
        ...verdict,
        admin,
      }
    }
    return {
      id: p.id,
      title: p.title,
      content: p.content,
      turnNumber: p.turnNumber ?? null,
      weekNumber: p.weekNumber ?? null,
      createdAt: p.createdAt,
      verdict: verdictWithAdmin
        ? {
            ...verdictWithAdmin,
            statChanges: verdictWithAdmin.statChanges
              ? (safeParse(verdictWithAdmin.statChanges) as unknown[])?.length || 0
              : 0,
          }
        : null,
    }
  })

  // Recent changes: include verdict (post + admin), admin
  const recentChanges = recentChangesSnap.docs.map((d) => docToApi(d as any)) as any[]
  const changeVerdictIds = [...new Set(recentChanges.map((c) => c.verdictId).filter(Boolean))]
  const changeAdminIds = [...new Set(recentChanges.map((c) => c.adminId).filter(Boolean))]

  const [changeVerdictSnaps, changeAdminSnaps] = await Promise.all([
    Promise.all(changeVerdictIds.map((vid) => db.collection(COLLECTIONS.verdicts).doc(vid!).get())),
    Promise.all(changeAdminIds.map((aid) => db.collection(COLLECTIONS.users).doc(aid!).get())),
  ])

  const changeVerdictMap = new Map<string, any>()
  const changeVerdictPostIds: string[] = []
  changeVerdictSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      changeVerdictMap.set(s.id, { ...docToApi(s as any) })
      if (data.postId) changeVerdictPostIds.push(data.postId)
    }
  })

  const changePostSnaps = await Promise.all(
    [...new Set(changeVerdictPostIds)].map((pid) => db.collection(COLLECTIONS.posts).doc(pid).get())
  )
  const changePostMap = new Map<string, any>()
  changePostSnaps.forEach((s) => {
    if (s.exists) changePostMap.set(s.id, { id: s.id, title: (s.data() as any).title })
  })

  const changeAdminMap = new Map<string, any>()
  changeAdminSnaps.forEach((s) => {
    if (s.exists) changeAdminMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  // For verdict.admin (need to fetch again since changeVerdictMap has adminId in data)
  const verdictAdminIds2: string[] = []
  changeVerdictSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      if (data.adminId) verdictAdminIds2.push(data.adminId)
    }
  })
  const verdictAdminSnaps2 = await Promise.all(
    [...new Set(verdictAdminIds2)].map((aid) => db.collection(COLLECTIONS.users).doc(aid).get())
  )
  const verdictAdminMap2 = new Map<string, any>()
  verdictAdminSnaps2.forEach((s) => {
    if (s.exists) verdictAdminMap2.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  const recentChangesWithIncludes = recentChanges.map((c) => {
    const v = c.verdictId ? changeVerdictMap.get(c.verdictId) : null
    let verdictWithIncludes = null
    if (v) {
      const vSnap = changeVerdictSnaps.find((s) => s.id === c.verdictId)
      const vData = vSnap?.data() as any
      verdictWithIncludes = {
        ...v,
        post: vData?.postId ? changePostMap.get(vData.postId) || null : null,
        admin: vData?.adminId ? verdictAdminMap2.get(vData.adminId) || null : null,
      }
    }
    return {
      ...c,
      oldValue: safeParse(c.oldValue),
      newValue: safeParse(c.newValue),
      admin: c.adminId ? changeAdminMap.get(c.adminId) || null : null,
      verdict: verdictWithIncludes,
    }
  })

  const faction = {
    ...docToApi(factionSnap as any),
    user,
    stats,
    recentPosts: postsWithVerdict,
    recentChanges: recentChangesWithIncludes,
    _count: {
      posts: postsCountSnap.data().count,
      statChangeLogs: statLogsCountSnap.data().count,
    },
  }

  return jsonResponse({ faction })
}
