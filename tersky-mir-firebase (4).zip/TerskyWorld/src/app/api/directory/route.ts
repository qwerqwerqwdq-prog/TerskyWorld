import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi, toApiDate } from '@/lib/firestore'

// GET /api/directory — публичный список утверждённых фракций и их правителей
export async function GET(req: NextRequest) {
  await requireAuth(req)
  const search = req.nextUrl.searchParams.get('search')
  const db = getAdminDb()

  const snap = await db.collection(COLLECTIONS.factions)
    .where('isApproved', '==', true)
    .orderBy('createdAt', 'asc')
    .get()

  let factions = snap.docs.map((d) => docToApi(d as any)) as any[]

  // Search filter (case-insensitive contains on name)
  if (search) {
    const lower = search.toLowerCase()
    factions = factions.filter((f) => (f.name || '').toLowerCase().includes(lower))
  }

  // Для каждой фракции: user (with avatar), _count.posts, _count.statChangeLogs
  const userIds = [...new Set(factions.map((f) => f.userId).filter(Boolean))]
  const userSnaps = await Promise.all(
    userIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get())
  )
  const userMap = new Map<string, any>()
  userSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      userMap.set(s.id, { id: s.id, name: data.name, avatar: data.avatar || null })
    }
  })

  // Count posts + statChangeLogs per faction (parallel)
  const postCounts = await Promise.all(
    factions.map((f) => db.collection(COLLECTIONS.posts).where('factionId', '==', f.id).count().get())
  )
  const statLogCounts = await Promise.all(
    factions.map((f) => db.collection(COLLECTIONS.statChangeLogs).where('factionId', '==', f.id).count().get())
  )

  factions = factions.map((f, i) => {
    const user = f.userId ? userMap.get(f.userId) || null : null
    return {
      id: f.id,
      name: f.name,
      shortName: f.shortName ?? null,
      motto: f.motto ?? null,
      description: f.description ?? null,
      bannerColor: f.bannerColor ?? null,
      emblemUrl: f.emblemUrl ?? null,
      isApproved: Boolean(f.isApproved),
      createdAt: toApiDate(f.createdAt),
      user: user
        ? {
            id: user.id,
            name: user.name,
            avatar: user.avatar,
            _count: { posts: postCounts[i].data().count },
          }
        : null,
      _count: {
        posts: postCounts[i].data().count,
        statChangeLogs: statLogCounts[i].data().count,
      },
    }
  })

  const totalFactions = factions.length
  const totalPosts = factions.reduce((acc, f) => acc + (f._count?.posts || 0), 0)
  const totalRulers = new Set(
    factions.map((f) => f.user?.id).filter(Boolean) as string[]
  ).size

  return jsonResponse({
    factions,
    stats: {
      totalFactions,
      totalPosts,
      totalRulers,
    },
  })
}
