import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, FieldValue } from '@/lib/firestore'
import { z } from 'zod'

// Вспомогательная функция — преобразование Firestore Timestamp → ISO
function toIso(ts: any): string | null {
  if (!ts) return null
  if (typeof ts === 'string') return ts
  if (typeof ts === 'number') return new Date(ts).toISOString()
  if (ts instanceof Date) return ts.toISOString()
  if (typeof ts === 'object' && ts !== null && '_seconds' in ts) {
    return new Date(
      ts._seconds * 1000 + (ts._nanoseconds || 0) / 1e6
    ).toISOString()
  }
  return null
}

// GET /api/profile — профиль текущего пользователя
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()

  const userSnap = await db.collection(COLLECTIONS.users).doc(ctx.userId).get()
  if (!userSnap.exists) return errorResponse('Пользователь не найден', 404)
  const data = userSnap.data() as any

  let faction: {
    id: string
    name: string
    shortName: string | null
    motto: string | null
    description: string | null
    bannerColor: string | null
    isApproved: boolean
    createdAt: string | null
  } | null = null
  if (data.factionId) {
    const fSnap = await db.collection(COLLECTIONS.factions).doc(data.factionId).get()
    if (fSnap.exists) {
      const f = fSnap.data()!
      faction = {
        id: fSnap.id,
        name: f.name,
        shortName: f.shortName || null,
        motto: f.motto || null,
        description: f.description || null,
        bannerColor: f.bannerColor || null,
        isApproved: Boolean(f.isApproved),
        createdAt: toIso(f.createdAt),
      }
    }
  }

  const [posts, chatMessages, verdicts, chronicle, bestiary] = await Promise.all([
    db.collection(COLLECTIONS.posts).where('authorId', '==', ctx.userId).count().get(),
    db.collection(COLLECTIONS.chatMessages).where('userId', '==', ctx.userId).count().get(),
    db.collection(COLLECTIONS.verdicts).where('adminId', '==', ctx.userId).count().get(),
    db.collection(COLLECTIONS.chronicle).where('authorId', '==', ctx.userId).count().get(),
    db.collection(COLLECTIONS.bestiary).where('authorId', '==', ctx.userId).count().get(),
  ])

  const user = {
    id: userSnap.id,
    name: data.name,
    email: data.email,
    role: data.role || 'PLAYER',
    avatar: data.avatar || null,
    bio: data.bio || null,
    createdAt: toIso(data.createdAt),
    lastLoginAt: toIso(data.lastLoginAt),
    faction,
    _count: {
      posts: posts.data().count,
      chatMessages: chatMessages.data().count,
      verdicts: verdicts.data().count,
      chronicle: chronicle.data().count,
      bestiary: bestiary.data().count,
    },
  }

  return jsonResponse({ user })
}

const updateProfileSchema = z.object({
  name: z.string().min(2, 'Имя минимум 2 символа').max(50, 'Имя максимум 50 символов').optional(),
  avatar: z.string().max(500, 'Слишком длинный URL').optional(),
  bio: z.string().max(500, 'Описание максимум 500 символов').optional(),
})

// PUT /api/profile — обновление профиля текущего пользователя
export async function PUT(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()
  const body = await req.json()
  const parsed = updateProfileSchema.safeParse(body)
  if (!parsed.success)
    return errorResponse(
      parsed.error.issues[0]?.message || 'Некорректные данные',
      422
    )

  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  if (parsed.data.name !== undefined) updateData.name = parsed.data.name
  if (parsed.data.avatar !== undefined) updateData.avatar = parsed.data.avatar || null
  if (parsed.data.bio !== undefined) updateData.bio = parsed.data.bio || null

  await db.collection(COLLECTIONS.users).doc(ctx.userId).update(updateData)

  const userSnap = await db.collection(COLLECTIONS.users).doc(ctx.userId).get()
  const data = userSnap.data()!
  const user = {
    id: userSnap.id,
    name: data.name,
    email: data.email,
    role: data.role || 'PLAYER',
    avatar: data.avatar || null,
    bio: data.bio || null,
  }
  return jsonResponse({ user, message: 'Профиль обновлён' })
}
