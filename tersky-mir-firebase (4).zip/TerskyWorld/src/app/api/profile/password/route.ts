import { NextRequest } from 'next/server'
import { getAdminDb, getAdminAuth } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse } from '@/lib/server-auth'
import { z } from 'zod'

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Введите текущий пароль'),
  newPassword: z.string().min(6, 'Новый пароль минимум 6 символов').max(100, 'Пароль слишком длинный'),
})

// Вспомогательная функция — проверка пароля через Firebase Auth REST API
async function verifyPassword(email: string, password: string): Promise<boolean> {
  const apiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY
  if (!apiKey) {
    console.error('[password] NEXT_PUBLIC_FIREBASE_API_KEY not configured')
    return false
  }
  try {
    const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email,
        password,
        returnSecureToken: true,
      }),
    })
    return res.ok
  } catch (e) {
    console.error('[password] verifyPassword failed:', e)
    return false
  }
}

// PUT /api/profile/password — смена пароля текущего пользователя
export async function PUT(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()
  const body = await req.json()
  const parsed = changePasswordSchema.safeParse(body)
  if (!parsed.success) {
    return errorResponse(
      parsed.error.issues[0]?.message || 'Некорректные данные',
      422
    )
  }

  const { currentPassword, newPassword } = parsed.data

  // Получаем email пользователя
  const userSnap = await db.collection('users').doc(ctx.userId).get()
  if (!userSnap.exists) return errorResponse('Пользователь не найден', 404)
  const data = userSnap.data()!
  const email = data.email as string

  // Проверяем текущий пароль через Firebase Auth REST API
  const isCurrentValid = await verifyPassword(email, currentPassword)
  if (!isCurrentValid) {
    return errorResponse('Неверный текущий пароль', 400)
  }

  // Проверяем, что новый пароль отличается от текущего
  const isSamePassword = await verifyPassword(email, newPassword)
  if (isSamePassword) {
    return errorResponse('Новый пароль должен отличаться от текущего', 400)
  }

  // Меняем пароль через Firebase Admin Auth
  try {
    await getAdminAuth().updateUser(ctx.userId, { password: newPassword })
  } catch (e) {
    console.error('[password] updateUser failed:', e)
    return errorResponse('Ошибка смены пароля', 500)
  }

  // Отзываем все старые токены — пользователь должен войти снова (опционально)
  try {
    await getAdminAuth().revokeRefreshTokens(ctx.userId)
  } catch (e) {
    console.error('[password] revoke tokens failed:', e)
  }

  return jsonResponse({ success: true, message: 'Пароль успешно изменён' })
}
