import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, FieldValue } from '@/lib/firestore'

// Определение достижений
interface AchievementDef {
  id: string
  title: string
  description: string
  icon: string
  category: 'posts' | 'social' | 'verdicts' | 'chronicle' | 'bestiary' | 'special'
  tier: 'bronze' | 'silver' | 'gold'
  check: (stats: UserStats) => boolean
  progress: (stats: UserStats) => { current: number; target: number }
}

interface UserStats {
  postsCount: number
  verdictedPostsCount: number
  chatMessagesCount: number
  verdictsGivenCount: number
  chronicleCount: number
  bestiaryCount: number
  bookmarksCount: number
  daysSinceRegistration: number
}

const ACHIEVEMENTS: AchievementDef[] = [
  // Posts
  { id: 'first_post', title: 'Первый шаг', description: 'Опубликовать первый пост', icon: 'ScrollText', category: 'posts', tier: 'bronze', check: (s) => s.postsCount >= 1, progress: (s) => ({ current: Math.min(s.postsCount, 1), target: 1 }) },
  { id: 'ten_posts', title: 'Летописец', description: 'Опубликовать 10 постов', icon: 'ScrollText', category: 'posts', tier: 'silver', check: (s) => s.postsCount >= 10, progress: (s) => ({ current: Math.min(s.postsCount, 10), target: 10 }) },
  { id: 'fifty_posts', title: 'Мастер слова', description: 'Опубликовать 50 постов', icon: 'ScrollText', category: 'posts', tier: 'gold', check: (s) => s.postsCount >= 50, progress: (s) => ({ current: Math.min(s.postsCount, 50), target: 50 }) },
  // Verdicted posts
  { id: 'first_verdict', title: 'Признание', description: 'Получить первый вердикт администратора', icon: 'Shield', category: 'posts', tier: 'bronze', check: (s) => s.verdictedPostsCount >= 1, progress: (s) => ({ current: Math.min(s.verdictedPostsCount, 1), target: 1 }) },
  { id: 'ten_verdicts', title: 'Утверждённый', description: 'Получить 10 вердиктов', icon: 'Shield', category: 'posts', tier: 'silver', check: (s) => s.verdictedPostsCount >= 10, progress: (s) => ({ current: Math.min(s.verdictedPostsCount, 10), target: 10 }) },
  // Social
  { id: 'first_message', title: 'Собеседник', description: 'Отправить первое сообщение в чате', icon: 'MessageSquare', category: 'social', tier: 'bronze', check: (s) => s.chatMessagesCount >= 1, progress: (s) => ({ current: Math.min(s.chatMessagesCount, 1), target: 1 }) },
  { id: 'fifty_messages', title: 'Дипломат', description: 'Отправить 50 сообщений в чатах', icon: 'MessageSquare', category: 'social', tier: 'silver', check: (s) => s.chatMessagesCount >= 50, progress: (s) => ({ current: Math.min(s.chatMessagesCount, 50), target: 50 }) },
  // Verdicts given (admin)
  { id: 'first_verdict_given', title: 'Судья', description: 'Вынести первый вердикт (для админа)', icon: 'Crown', category: 'verdicts', tier: 'bronze', check: (s) => s.verdictsGivenCount >= 1, progress: (s) => ({ current: Math.min(s.verdictsGivenCount, 1), target: 1 }) },
  { id: 'twenty_verdicts_given', title: 'Верховный судья', description: 'Вынести 20 вердиктов', icon: 'Crown', category: 'verdicts', tier: 'silver', check: (s) => s.verdictsGivenCount >= 20, progress: (s) => ({ current: Math.min(s.verdictsGivenCount, 20), target: 20 }) },
  // Chronicle
  { id: 'first_chronicle', title: 'Летописец мира', description: 'Добавить первую запись в Хронику', icon: 'BookOpen', category: 'chronicle', tier: 'bronze', check: (s) => s.chronicleCount >= 1, progress: (s) => ({ current: Math.min(s.chronicleCount, 1), target: 1 }) },
  // Bestiary
  { id: 'first_bestiary', title: 'Знаток тварей', description: 'Добавить первую запись в Бестиарий', icon: 'PawPrint', category: 'bestiary', tier: 'bronze', check: (s) => s.bestiaryCount >= 1, progress: (s) => ({ current: Math.min(s.bestiaryCount, 1), target: 1 }) },
  // Special
  { id: 'first_bookmark', title: 'Книгочей', description: 'Создать первую закладку', icon: 'Bookmark', category: 'special', tier: 'bronze', check: (s) => s.bookmarksCount >= 1, progress: (s) => ({ current: Math.min(s.bookmarksCount, 1), target: 1 }) },
  { id: 'veteran', title: 'Ветеран', description: 'Быть в игре 7 дней', icon: 'Calendar', category: 'special', tier: 'silver', check: (s) => s.daysSinceRegistration >= 7, progress: (s) => ({ current: Math.min(s.daysSinceRegistration, 7), target: 7 }) },
  { id: 'explorer', title: 'Исследователь', description: 'Создать 10 закладок', icon: 'Compass', category: 'special', tier: 'silver', check: (s) => s.bookmarksCount >= 10, progress: (s) => ({ current: Math.min(s.bookmarksCount, 10), target: 10 }) },
]

export const ACHIEVEMENT_DEFS = ACHIEVEMENTS

// Вспомогательная функция — count по коллекции с фильтром
async function countWhere(
  db: ReturnType<typeof getAdminDb>,
  col: string,
  field: string,
  value: string
): Promise<number> {
  const snap = await db.collection(col).where(field, '==', value).count().get()
  return snap.data().count
}

// Вспомогательная функция — count по двум фильтрам (равенства)
async function countWhereTwo(
  db: ReturnType<typeof getAdminDb>,
  col: string,
  field1: string,
  value1: string,
  field2: string,
  value2: string
): Promise<number> {
  const snap = await db
    .collection(col)
    .where(field1, '==', value1)
    .where(field2, '==', value2)
    .count()
    .get()
  return snap.data().count
}

// GET /api/achievements — достижения текущего пользователя
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()
  const adminParam = req.nextUrl.searchParams.get('admin')
  const targetUserId = adminParam === 'true' && ctx.role === 'ADMIN' ? null : ctx.userId

  // Собираем статистику пользователя
  const postsCount = targetUserId
    ? await countWhere(db, COLLECTIONS.posts, 'authorId', targetUserId)
    : (await db.collection(COLLECTIONS.posts).count().get()).data().count
  const verdictedPostsCount = targetUserId
    ? await countWhereTwo(db, COLLECTIONS.posts, 'authorId', targetUserId, 'status', 'VERDICTED')
    : (await db.collection(COLLECTIONS.posts).where('status', '==', 'VERDICTED').count().get()).data().count
  const chatMessagesCount = targetUserId
    ? await countWhere(db, COLLECTIONS.chatMessages, 'userId', targetUserId)
    : (await db.collection(COLLECTIONS.chatMessages).count().get()).data().count
  const verdictsGivenCount = targetUserId
    ? await countWhere(db, COLLECTIONS.verdicts, 'adminId', targetUserId)
    : (await db.collection(COLLECTIONS.verdicts).count().get()).data().count
  const chronicleCount = targetUserId
    ? await countWhere(db, COLLECTIONS.chronicle, 'authorId', targetUserId)
    : (await db.collection(COLLECTIONS.chronicle).count().get()).data().count
  const bestiaryCount = targetUserId
    ? await countWhere(db, COLLECTIONS.bestiary, 'authorId', targetUserId)
    : (await db.collection(COLLECTIONS.bestiary).count().get()).data().count
  const bookmarksCount = targetUserId
    ? await countWhere(db, COLLECTIONS.bookmarks, 'userId', targetUserId)
    : (await db.collection(COLLECTIONS.bookmarks).count().get()).data().count

  // Дни с регистрации
  const userSnap = await db
    .collection(COLLECTIONS.users)
    .doc(targetUserId || ctx.userId)
    .get()
  let daysSinceRegistration = 0
  if (userSnap.exists) {
    const data = userSnap.data()!
    let createdAtMs = 0
    if (data.createdAt) {
      try {
        if (typeof data.createdAt === 'object' && '_seconds' in data.createdAt) {
          createdAtMs =
            (data.createdAt as any)._seconds * 1000 +
            ((data.createdAt as any)._nanoseconds || 0) / 1e6
        } else if (data.createdAt instanceof Date) {
          createdAtMs = (data.createdAt as Date).getTime()
        } else if (typeof data.createdAt === 'string') {
          createdAtMs = new Date(data.createdAt).getTime()
        }
      } catch {
        /* noop */
      }
    }
    if (createdAtMs > 0) {
      daysSinceRegistration = Math.floor(
        (Date.now() - createdAtMs) / (1000 * 60 * 60 * 24)
      )
    }
  }

  const stats: UserStats = {
    postsCount,
    verdictedPostsCount,
    chatMessagesCount,
    verdictsGivenCount,
    chronicleCount,
    bestiaryCount,
    bookmarksCount,
    daysSinceRegistration,
  }

  // Вычисляем достижения
  const achievements = ACHIEVEMENTS.map((def) => {
    const unlocked = def.check(stats)
    const { current, target } = def.progress(stats)
    return {
      id: def.id,
      title: def.title,
      description: def.description,
      icon: def.icon,
      category: def.category,
      tier: def.tier,
      unlocked,
      progress: { current, target, percent: Math.round((current / target) * 100) },
    }
  })

  // Сохраняем открытые достижения в БД и находим недавно открытые
  const unlockedAchievementIds = achievements
    .filter((a) => a.unlocked)
    .map((a) => a.id)

  const existingRecordsSnap = await db
    .collection(COLLECTIONS.userAchievements)
    .where('userId', '==', ctx.userId)
    .get()
  const existingMap = new Map<string, any>()
  existingRecordsSnap.docs.forEach((d) => {
    const data = d.data() as any
    existingMap.set(data.achievementId, {
      achievementId: data.achievementId,
      unlockedAt: data.unlockedAt || null,
    })
  })

  // Создаём записи для вновь открытых достижений (которых ещё нет в БД)
  const newlyUnlocked: string[] = []
  const now = FieldValue.serverTimestamp()
  for (const achId of unlockedAchievementIds) {
    if (!existingMap.has(achId)) {
      try {
        const docId = `${ctx.userId}_${achId}`
        await db
          .collection(COLLECTIONS.userAchievements)
          .doc(docId)
          .set({
            userId: ctx.userId,
            achievementId: achId,
            unlockedAt: now,
          })
        newlyUnlocked.push(achId)
        // Записываем в existingMap текущее значение (только что создано)
        existingMap.set(achId, { achievementId: achId, unlockedAt: null })
      } catch {
        // race condition — уже существует
      }
    }
  }

  // Добавляем unlockedAt к достижениям
  const achievementsWithDates = achievements.map((a) => {
    const existing = existingMap.get(a.id)
    const isNew = newlyUnlocked.includes(a.id)
    let unlockedAt: string | null = null
    if (existing && existing.unlockedAt) {
      try {
        if (typeof existing.unlockedAt === 'object' && '_seconds' in existing.unlockedAt) {
          unlockedAt = new Date(
            (existing.unlockedAt as any)._seconds * 1000 +
              ((existing.unlockedAt as any)._nanoseconds || 0) / 1e6
          ).toISOString()
        } else if (existing.unlockedAt instanceof Date) {
          unlockedAt = (existing.unlockedAt as Date).toISOString()
        } else if (typeof existing.unlockedAt === 'string') {
          unlockedAt = existing.unlockedAt
        }
      } catch {
        unlockedAt = null
      }
    } else if (isNew) {
      unlockedAt = new Date().toISOString()
    }
    return {
      ...a,
      unlockedAt,
      isNew,
    }
  })

  const unlockedCount = achievementsWithDates.filter((a) => a.unlocked).length
  const totalCount = achievementsWithDates.length
  const totalPercent = Math.round((unlockedCount / totalCount) * 100)

  // Группировка по категориям
  const byCategory: Record<string, typeof achievementsWithDates> = {}
  for (const a of achievementsWithDates) {
    if (!byCategory[a.category]) byCategory[a.category] = []
    byCategory[a.category].push(a)
  }

  return jsonResponse({
    achievements: achievementsWithDates,
    byCategory,
    stats,
    summary: {
      unlocked: unlockedCount,
      total: totalCount,
      percent: totalPercent,
    },
  })
}
