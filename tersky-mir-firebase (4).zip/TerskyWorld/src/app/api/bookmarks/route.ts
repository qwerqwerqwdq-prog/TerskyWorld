import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'
import { z } from 'zod'

// GET /api/bookmarks — список закладок текущего пользователя
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()

  const snap = await db
    .collection(COLLECTIONS.bookmarks)
    .where('userId', '==', ctx.userId)
    .get()
  const bookmarks = snap.docs.map(docToApi) as any[]

  // Сортировка по createdAt desc
  bookmarks.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })

  // Загружаем связанные сущности отдельно
  const postIds = bookmarks.filter((b) => b.type === 'post').map((b) => b.entityId)
  const newsIds = bookmarks.filter((b) => b.type === 'news').map((b) => b.entityId)

  const postsMap = new Map<string, any>()
  const newsMap = new Map<string, any>()

  await Promise.all([
    ...postIds.map(async (id) => {
      const pSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
      if (!pSnap.exists) return
      const p = pSnap.data()!
      let author: { id: string; name: any } | null = null
      if (p.authorId) {
        const uSnap = await db.collection(COLLECTIONS.users).doc(p.authorId).get()
        if (uSnap.exists) {
          author = { id: uSnap.id, name: uSnap.data()!.name }
        }
      }
      let faction: { id: string; name: any } | null = null
      if (p.factionId) {
        const fSnap = await db.collection(COLLECTIONS.factions).doc(p.factionId).get()
        if (fSnap.exists) {
          faction = { id: fSnap.id, name: fSnap.data()!.name }
        }
      }
      postsMap.set(id, {
        id: pSnap.id,
        title: p.title,
        content: p.content,
        status: p.status,
        createdAt: null as string | null,
        author,
        faction,
      })
      // Преобразуем createdAt
      if (p.createdAt) {
        try {
          if (typeof p.createdAt === 'object' && '_seconds' in p.createdAt) {
            postsMap.get(id).createdAt = new Date(
              (p.createdAt as any)._seconds * 1000 +
                ((p.createdAt as any)._nanoseconds || 0) / 1e6
            ).toISOString()
          } else if (p.createdAt instanceof Date) {
            postsMap.get(id).createdAt = (p.createdAt as Date).toISOString()
          } else if (typeof p.createdAt === 'string') {
            postsMap.get(id).createdAt = p.createdAt
          }
        } catch {
          /* noop */
        }
      }
    }),
    ...newsIds.map(async (id) => {
      const nSnap = await db.collection(COLLECTIONS.news).doc(id).get()
      if (!nSnap.exists) return
      const n = nSnap.data()!
      const item: any = {
        id: nSnap.id,
        title: n.title,
        excerpt: n.excerpt || null,
        category: n.category || 'GENERAL',
        createdAt: null as string | null,
      }
      if (n.createdAt) {
        try {
          if (typeof n.createdAt === 'object' && '_seconds' in n.createdAt) {
            item.createdAt = new Date(
              (n.createdAt as any)._seconds * 1000 +
                ((n.createdAt as any)._nanoseconds || 0) / 1e6
            ).toISOString()
          } else if (n.createdAt instanceof Date) {
            item.createdAt = (n.createdAt as Date).toISOString()
          } else if (typeof n.createdAt === 'string') {
            item.createdAt = n.createdAt
          }
        } catch {
          /* noop */
        }
      }
      newsMap.set(id, item)
    }),
  ])

  const enriched = bookmarks.map((b) => ({
    id: b.id,
    userId: b.userId,
    type: b.type,
    entityId: b.entityId,
    createdAt: b.createdAt || null,
    post: b.type === 'post' ? postsMap.get(b.entityId) || null : null,
    news: b.type === 'news' ? newsMap.get(b.entityId) || null : null,
  }))

  return jsonResponse({ bookmarks: enriched })
}

const createBookmarkSchema = z.object({
  type: z.enum(['post', 'news']),
  entityId: z.string().min(1),
})

// POST /api/bookmarks — создать закладку
export async function POST(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()
  const body = await req.json()
  const parsed = createBookmarkSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  const { type, entityId } = parsed.data

  // Проверяем существование сущности
  if (type === 'post') {
    const pSnap = await db.collection(COLLECTIONS.posts).doc(entityId).get()
    if (!pSnap.exists) return errorResponse('Пост не найден', 404)
  } else {
    const nSnap = await db.collection(COLLECTIONS.news).doc(entityId).get()
    if (!nSnap.exists) return errorResponse('Новость не найдена', 404)
  }

  // Проверяем, нет ли уже такой закладки
  const bookmarkId = `${ctx.userId}_${type}_${entityId}`
  const existing = await db.collection(COLLECTIONS.bookmarks).doc(bookmarkId).get()
  if (existing.exists) return errorResponse('Уже в закладках', 400)

  await db
    .collection(COLLECTIONS.bookmarks)
    .doc(bookmarkId)
    .set({
      userId: ctx.userId,
      type,
      entityId,
      createdAt: FieldValue.serverTimestamp(),
    })

  const bookmarkSnap = await db.collection(COLLECTIONS.bookmarks).doc(bookmarkId).get()
  const bookmark = docToApi(bookmarkSnap as any)

  return jsonResponse({ bookmark, message: 'Добавлено в закладки' })
}

// DELETE /api/bookmarks — удалить закладку
export async function DELETE(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()
  const type = req.nextUrl.searchParams.get('type') as 'post' | 'news' | null
  const entityId = req.nextUrl.searchParams.get('entityId')

  if (!type || !entityId) return errorResponse('Не указан тип или ID', 422)

  const bookmarkId = `${ctx.userId}_${type}_${entityId}`
  await db.collection(COLLECTIONS.bookmarks).doc(bookmarkId).delete()

  return jsonResponse({ success: true, message: 'Удалено из закладок' })
}
