import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import {
  requireAuth,
  requireAdmin,
  jsonResponse,
  errorResponse,
} from '@/lib/server-auth'
import { COLLECTIONS, docToApi, toApiDate, FieldValue } from '@/lib/firestore'
import { randomUUID } from 'crypto'

// Загружаем пользователя с фракцией (для участников чата)
async function fetchUserWithFaction(db: ReturnType<typeof getAdminDb>, userId: string) {
  const userSnap = await db.collection(COLLECTIONS.users).doc(userId).get()
  if (!userSnap.exists) return null
  const data = userSnap.data()!
  let faction: { id: string; name: string } | null = null
  if (data.factionId) {
    const fSnap = await db.collection(COLLECTIONS.factions).doc(data.factionId).get()
    if (fSnap.exists) {
      const f = fSnap.data()!
      faction = { id: fSnap.id, name: f.name }
    }
  }
  return {
    id: userSnap.id,
    name: data.name,
    faction,
  }
}

// Загружаем участников чата (с пользователем + фракцией)
async function fetchChatParticipants(db: ReturnType<typeof getAdminDb>, chatRoomId: string) {
  const snap = await db
    .collection(COLLECTIONS.chatParticipants)
    .where('chatRoomId', '==', chatRoomId)
    .get()
  const participantsRaw = snap.docs.map(docToApi)
  // Для каждого участника загружаем пользователя с фракцией
  const participants = await Promise.all(
    participantsRaw.map(async (p: any) => {
      const user = await fetchUserWithFaction(db, p.userId)
      return {
        id: p.id,
        chatRoomId: p.chatRoomId,
        userId: p.userId,
        role: p.role || 'MEMBER',
        joinedAt: p.joinedAt || null,
        user,
      }
    })
  )
  return participants
}

// GET /api/chats — список чатов (для игрока — где участник; для админа — все)
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()

  let chatRoomIds: string[] = []
  if (ctx.role === 'ADMIN') {
    const allSnap = await db.collection(COLLECTIONS.chatRooms).get()
    chatRoomIds = allSnap.docs.map((d) => d.id)
  } else {
    const partSnap = await db
      .collection(COLLECTIONS.chatParticipants)
      .where('userId', '==', ctx.userId)
      .get()
    chatRoomIds = partSnap.docs.map((d) => d.get('chatRoomId') as string)
  }

  if (chatRoomIds.length === 0) {
    return jsonResponse({ chats: [] })
  }

  // Загружаем чаты
  const chatSnaps = await Promise.all(
    chatRoomIds.map((id) => db.collection(COLLECTIONS.chatRooms).doc(id).get())
  )
  const chats: any[] = chatSnaps.filter((s) => s.exists).map((s) => docToApi(s as any))

  // Сортировка по createdAt desc
  chats.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })

  // Параллельно загружаем участников и счётчик сообщений
  await Promise.all(
    chats.map(async (c) => {
      const [participants, msgCountSnap] = await Promise.all([
        fetchChatParticipants(db, c.id),
        db
          .collection(COLLECTIONS.chatMessages)
          .where('chatRoomId', '==', c.id)
          .count()
          .get(),
      ])
      c.participants = participants
      c._count = { messages: msgCountSnap.data().count }
    })
  )

  return jsonResponse({ chats })
}

// POST /api/chats — создание чата (только админ)
export async function POST(req: NextRequest) {
  const ctx = await requireAdmin(req)
  const db = getAdminDb()
  const body = await req.json()
  const { name, topic, description, participantIds } = body as {
    name: string
    topic?: string
    description?: string
    participantIds: string[]
  }

  if (!name || !participantIds?.length) {
    return errorResponse('Укажите название и участников', 400)
  }

  const chatId = randomUUID()
  const now = FieldValue.serverTimestamp()

  const chatData: Record<string, unknown> = {
    name,
    topic: topic || null,
    description: description || null,
    status: 'OPEN',
    summary: null,
    closedAt: null,
    createdAt: now,
    updatedAt: now,
  }

  await db.collection(COLLECTIONS.chatRooms).doc(chatId).set(chatData)

  // Создаём участников
  const allParticipants = [
    ...participantIds.map((userId) => ({ userId, role: 'MEMBER' })),
    { userId: ctx.userId, role: 'ADMIN' },
  ]
  const uniqParticipants = Array.from(
    new Map(allParticipants.map((p) => [p.userId, p])).values()
  )

  await Promise.all(
    uniqParticipants.map((p) => {
      const partId = `${chatId}_${p.userId}`
      return db
        .collection(COLLECTIONS.chatParticipants)
        .doc(partId)
        .set({
          chatRoomId: chatId,
          userId: p.userId,
          role: p.role,
          joinedAt: now,
        })
    })
  )

  // Системное сообщение о создании
  const sysMsgId = randomUUID()
  await db.collection(COLLECTIONS.chatMessages).doc(sysMsgId).set({
    chatRoomId: chatId,
    userId: ctx.userId,
    content: `Переговоры «${name}» начаты.`,
    isSystem: true,
    createdAt: now,
  })

  // Загружаем созданный чат с участниками (как в Prisma include)
  const chatSnap = await db.collection(COLLECTIONS.chatRooms).doc(chatId).get()
  const chat: any = docToApi(chatSnap as any)
  chat.participants = await fetchChatParticipants(db, chatId)

  return jsonResponse({ chat, message: 'Чат переговоров создан' })
}
