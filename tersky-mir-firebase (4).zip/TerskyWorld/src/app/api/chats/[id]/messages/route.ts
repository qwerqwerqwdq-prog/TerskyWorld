import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import {
  requireAuth,
  jsonResponse,
  errorResponse,
} from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'
import { z } from 'zod'
import { randomUUID } from 'crypto'

const messageSchema = z.object({
  content: z.string().min(1, 'Сообщение не может быть пустым').max(5000),
})

// Загружаем пользователя с фракцией
async function fetchUserWithFaction(db: ReturnType<typeof getAdminDb>, userId: string) {
  const userSnap = await db.collection(COLLECTIONS.users).doc(userId).get()
  if (!userSnap.exists) return null
  const data = userSnap.data()!
  let faction: { id: string; name: string } | null = null
  if (data.factionId) {
    const fSnap = await db.collection(COLLECTIONS.factions).doc(data.factionId).get()
    if (fSnap.exists) {
      const f = fSnap.data()!
      faction = { id: fSnap.id, name: f.name }
    }
  }
  return { id: userSnap.id, name: data.name, faction }
}

// GET /api/chats/[id]/messages — список сообщений
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(req)
  const { id } = await params
  const db = getAdminDb()

  // Проверка участия
  const partSnap = await db
    .collection(COLLECTIONS.chatParticipants)
    .doc(`${id}_${ctx.userId}`)
    .get()
  if (!partSnap.exists && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  const snap = await db
    .collection(COLLECTIONS.chatMessages)
    .where('chatRoomId', '==', id)
    .get()
  const messagesRaw = snap.docs.map(docToApi)
  messagesRaw.sort((a: any, b: any) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return aT - bT
  })
  const messages = await Promise.all(
    messagesRaw.map(async (m: any) => {
      const user = await fetchUserWithFaction(db, m.userId)
      return {
        id: m.id,
        chatRoomId: m.chatRoomId,
        userId: m.userId,
        content: m.content,
        isSystem: Boolean(m.isSystem),
        createdAt: m.createdAt || null,
        user,
      }
    })
  )

  return jsonResponse({ messages })
}

// POST /api/chats/[id]/messages — отправка сообщения
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(req)
  const { id } = await params
  const db = getAdminDb()

  const partSnap = await db
    .collection(COLLECTIONS.chatParticipants)
    .doc(`${id}_${ctx.userId}`)
    .get()
  if (!partSnap.exists && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  // Проверяем, что чат не закрыт
  const chatSnap = await db.collection(COLLECTIONS.chatRooms).doc(id).get()
  if (!chatSnap.exists) return errorResponse('Чат не найден', 404)
  const chatData = chatSnap.data()!
  if (chatData.status === 'CLOSED' || chatData.status === 'SUMMARIZED') {
    return errorResponse('Переговоры завершены', 403)
  }

  const body = await req.json()
  const parsed = messageSchema.safeParse(body)
  if (!parsed.success)
    return errorResponse(
      parsed.error.issues[0]?.message || 'Некорректные данные',
      422
    )

  const msgId = randomUUID()
  const now = FieldValue.serverTimestamp()
  await db.collection(COLLECTIONS.chatMessages).doc(msgId).set({
    chatRoomId: id,
    userId: ctx.userId,
    content: parsed.data.content,
    isSystem: false,
    createdAt: now,
  })

  // Обновляем чат (updatedAt)
  await db
    .collection(COLLECTIONS.chatRooms)
    .doc(id)
    .update({ updatedAt: now })

  // Записываем активность
  await db.collection(COLLECTIONS.activity).add({
    type: 'MESSAGE_SENT',
    userId: ctx.userId,
    targetId: id,
    data: { content: parsed.data.content.slice(0, 200) },
    createdAt: now,
  })

  // Загружаем пользователя для include
  const user = await fetchUserWithFaction(db, ctx.userId)
  const message = {
    id: msgId,
    chatRoomId: id,
    userId: ctx.userId,
    content: parsed.data.content,
    isSystem: false,
    createdAt: null, // serverTimestamp ещё не применён
    user,
  }

  return jsonResponse({ message })
}
