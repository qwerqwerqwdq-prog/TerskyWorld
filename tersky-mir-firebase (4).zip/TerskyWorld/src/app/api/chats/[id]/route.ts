import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import {
  requireAuth,
  requireAdmin,
  jsonResponse,
  errorResponse,
} from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'
import { randomUUID } from 'crypto'
import { z } from 'zod'

// Загружаем пользователя с фракцией
async function fetchUserWithFaction(db: ReturnType<typeof getAdminDb>, userId: string) {
  const userSnap = await db.collection(COLLECTIONS.users).doc(userId).get()
  if (!userSnap.exists) return null
  const data = userSnap.data()!
  let faction: { id: string; name: string } | null = null
  if (data.factionId) {
    const fSnap = await db.collection(COLLECTIONS.factions).doc(data.factionId).get()
    if (fSnap.exists) {
      const f = fSnap.data()!
      faction = { id: fSnap.id, name: f.name }
    }
  }
  return { id: userSnap.id, name: data.name, faction }
}

// Загружаем участников чата (с пользователем + фракцией)
async function fetchChatParticipants(db: ReturnType<typeof getAdminDb>, chatRoomId: string) {
  const snap = await db
    .collection(COLLECTIONS.chatParticipants)
    .where('chatRoomId', '==', chatRoomId)
    .get()
  const participantsRaw = snap.docs.map(docToApi)
  const participants = await Promise.all(
    participantsRaw.map(async (p: any) => {
      const user = await fetchUserWithFaction(db, p.userId)
      return {
        id: p.id,
        chatRoomId: p.chatRoomId,
        userId: p.userId,
        role: p.role || 'MEMBER',
        joinedAt: p.joinedAt || null,
        user,
      }
    })
  )
  return participants
}

// Загружаем сообщения чата (с пользователем + фракцией), asc по createdAt
async function fetchChatMessages(db: ReturnType<typeof getAdminDb>, chatRoomId: string) {
  const snap = await db
    .collection(COLLECTIONS.chatMessages)
    .where('chatRoomId', '==', chatRoomId)
    .get()
  const messagesRaw = snap.docs.map(docToApi)
  // Сортируем по createdAt asc
  messagesRaw.sort((a: any, b: any) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return aT - bT
  })
  const messages = await Promise.all(
    messagesRaw.map(async (m: any) => {
      const user = await fetchUserWithFaction(db, m.userId)
      return {
        id: m.id,
        chatRoomId: m.chatRoomId,
        userId: m.userId,
        content: m.content,
        isSystem: Boolean(m.isSystem),
        createdAt: m.createdAt || null,
        user,
      }
    })
  )
  return messages
}

// GET /api/chats/[id] — детали чата (участник или админ)
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(req)
  const { id } = await params
  const db = getAdminDb()

  const chatSnap = await db.collection(COLLECTIONS.chatRooms).doc(id).get()
  if (!chatSnap.exists) return errorResponse('Чат не найден', 404)

  const chat: any = docToApi(chatSnap as any)

  // Проверка доступа
  const partSnap = await db
    .collection(COLLECTIONS.chatParticipants)
    .doc(`${id}_${ctx.userId}`)
    .get()
  const isParticipant = partSnap.exists
  if (!isParticipant && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  const [participants, messages] = await Promise.all([
    fetchChatParticipants(db, id),
    fetchChatMessages(db, id),
  ])
  chat.participants = participants
  chat.messages = messages

  return jsonResponse({ chat })
}

const summarySchema = z.object({
  summary: z.string().min(10),
  closeChat: z.boolean().default(false),
})

// PUT /api/chats/[id] — обновление чата (итог встречи — только админ)
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const body = await req.json()

  // Если это итог встречи
  if (typeof body.summary === 'string') {
    const parsed = summarySchema.safeParse(body)
    if (!parsed.success) return errorResponse('Некорректные данные', 422)

    const updateData: Record<string, unknown> = {
      summary: parsed.data.summary,
      status: parsed.data.closeChat ? 'SUMMARIZED' : 'OPEN',
      closedAt: parsed.data.closeChat ? FieldValue.serverTimestamp() : null,
      updatedAt: FieldValue.serverTimestamp(),
    }
    await db.collection(COLLECTIONS.chatRooms).doc(id).update(updateData)

    // Системное сообщение об итоге
    const sysMsgId = randomUUID()
    await db.collection(COLLECTIONS.chatMessages).doc(sysMsgId).set({
      chatRoomId: id,
      userId: ctx.userId,
      content: `Итог встречи: ${parsed.data.summary}`,
      isSystem: true,
      createdAt: FieldValue.serverTimestamp(),
    })

    const chatSnap = await db.collection(COLLECTIONS.chatRooms).doc(id).get()
    const chat: any = docToApi(chatSnap as any)
    return jsonResponse({ chat, message: 'Итог встречи зафиксирован' })
  }

  // Обычное обновление (название, тема и т.д.)
  const { name, topic, description, status } = body as Record<string, unknown>
  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  if (name) updateData.name = String(name)
  if (topic !== undefined) updateData.topic = topic as string | null
  if (description !== undefined) updateData.description = description as string | null
  if (status) {
    updateData.status = String(status)
    if (status === 'CLOSED') updateData.closedAt = FieldValue.serverTimestamp()
  }

  await db.collection(COLLECTIONS.chatRooms).doc(id).update(updateData)
  const chatSnap = await db.collection(COLLECTIONS.chatRooms).doc(id).get()
  const chat: any = docToApi(chatSnap as any)
  return jsonResponse({ chat })
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()

  // Каскадное удаление участников и сообщений (Firestore не делает каскад)
  const [partSnap, msgSnap] = await Promise.all([
    db.collection(COLLECTIONS.chatParticipants).where('chatRoomId', '==', id).get(),
    db.collection(COLLECTIONS.chatMessages).where('chatRoomId', '==', id).get(),
  ])
  const batch = db.batch()
  partSnap.docs.forEach((d) => batch.delete(d.ref))
  msgSnap.docs.forEach((d) => batch.delete(d.ref))
  batch.delete(db.collection(COLLECTIONS.chatRooms).doc(id))
  await batch.commit()

  return jsonResponse({ success: true })
}
