import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'

function safeParse(s: string | null | undefined): unknown {
  if (!s) return null
  try {
    return JSON.parse(s)
  } catch {
    return s
  }
}

// Преобразование любого Firestore Timestamp-like значения в ISO-строку
function toIso(ts: any): string {
  if (!ts) return new Date(0).toISOString()
  if (typeof ts === 'string') return ts
  if (typeof ts === 'number') return new Date(ts).toISOString()
  if (ts instanceof Date) return ts.toISOString()
  if (typeof ts === 'object' && ts !== null && '_seconds' in ts) {
    return new Date(
      ts._seconds * 1000 + (ts._nanoseconds || 0) / 1e6
    ).toISOString()
  }
  return new Date(0).toISOString()
}

// Загружаем пользователя (id + name)
async function fetchUserShort(db: ReturnType<typeof getAdminDb>, userId: string) {
  const snap = await db.collection(COLLECTIONS.users).doc(userId).get()
  if (!snap.exists) return null
  return { id: snap.id, name: snap.data()!.name }
}

// Загружаем фракцию (id + name)
async function fetchFactionShort(db: ReturnType<typeof getAdminDb>, factionId: string | null) {
  if (!factionId) return null
  const snap = await db.collection(COLLECTIONS.factions).doc(factionId).get()
  if (!snap.exists) return null
  return { id: snap.id, name: snap.data()!.name }
}

// GET /api/activity — агрегированная лента всей активности (для Timeline view)
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const limitParam = req.nextUrl.searchParams.get('limit')
  const limit = Math.min(Number(limitParam) || 50, 100)
  const isAdmin = ctx.role === 'ADMIN'
  const db = getAdminDb()

  // 1. Посты текущего игрока (или все для admin)
  let posts: any[] = []
  if (isAdmin) {
    const allSnap = await db.collection(COLLECTIONS.posts).get()
    posts = allSnap.docs.map(docToApi)
  } else {
    const postsSnap = await db
      .collection(COLLECTIONS.posts)
      .where('authorId', '==', ctx.userId)
      .get()
    posts = postsSnap.docs.map(docToApi)
  }
  posts.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })
  posts = posts.slice(0, limit)

  // Для каждого поста загружаем автора/фракцию/вердикт
  const postsWithIncludes = await Promise.all(
    posts.map(async (p: any) => {
      const [author, faction] = await Promise.all([
        fetchUserShort(db, p.authorId),
        fetchFactionShort(db, p.factionId || null),
      ])
      let verdict: any = null
      const verdictSnap = await db
        .collection(COLLECTIONS.verdicts)
        .where('postId', '==', p.id)
        .limit(1)
        .get()
      if (!verdictSnap.empty) {
        const vRaw = docToApi(verdictSnap.docs[0] as any) as any
        const vAdmin = await fetchUserShort(db, vRaw.adminId as string)
        verdict = {
          id: vRaw.id,
          roleplayText: vRaw.roleplayText,
          technicalText: vRaw.technicalText || null,
          statChanges: vRaw.statChanges || null,
          createdAt: vRaw.createdAt || null,
          admin: vAdmin,
        }
      }
      return {
        ...p,
        author,
        faction,
        verdict,
      }
    })
  )

  // 2. Новости (для всех) — за последние 30 дней
  const newsSnap = await db
    .collection(COLLECTIONS.news)
    .where('createdAt', '>=', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
    .get()
  let news: any[] = newsSnap.docs.map(docToApi)
  news.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })
  news = news.slice(0, Math.min(limit, 20))

  const newsWithIncludes = await Promise.all(
    news.map(async (n: any) => {
      const author = await fetchUserShort(db, n.authorId)
      return { ...n, author }
    })
  )

  // 3. Изменения статов (для игрока — своей фракции; для admin — все)
  let factionIds: string[] = []
  if (!isAdmin) {
    const factionSnap = await db
      .collection(COLLECTIONS.factions)
      .where('userId', '==', ctx.userId)
      .limit(1)
      .get()
    if (!factionSnap.empty) {
      factionIds = [factionSnap.docs[0].id]
    }
  }

  let statChangesSnap: any
  if (isAdmin) {
    statChangesSnap = await db.collection(COLLECTIONS.statChangeLogs).get()
  } else if (factionIds.length > 0) {
    statChangesSnap = await db
      .collection(COLLECTIONS.statChangeLogs)
      .where('factionId', 'in', factionIds)
      .get()
  } else {
    statChangesSnap = { docs: [] as any[] }
  }
  let statChanges: any[] = statChangesSnap.docs.map(docToApi)
  statChanges.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })
  statChanges = statChanges.slice(0, Math.min(limit, 30))

  const statChangesWithIncludes = await Promise.all(
    statChanges.map(async (c: any) => {
      const [verdict, admin, faction] = await Promise.all([
        (async () => {
          if (!c.verdictId) return null
          const vSnap = await db.collection(COLLECTIONS.verdicts).doc(c.verdictId).get()
          if (!vSnap.exists) return null
          const v = vSnap.data()!
          const pSnap = await db.collection(COLLECTIONS.posts).doc(v.postId).get()
          const pTitle = pSnap.exists ? pSnap.data()!.title : null
          const vAdmin = await fetchUserShort(db, v.adminId)
          return {
            id: vSnap.id,
            post: { id: v.postId, title: pTitle },
            admin: vAdmin,
          }
        })(),
        fetchUserShort(db, c.adminId),
        fetchFactionShort(db, c.factionId),
      ])
      return { ...c, verdict, admin, faction }
    })
  )

  // 4. Новые чаты/сообщения (для игрока — где участвует; для admin — все)
  const chatParticipations = !isAdmin
    ? (await db
        .collection(COLLECTIONS.chatParticipants)
        .where('userId', '==', ctx.userId)
        .get()).docs.map((d) => d.get('chatRoomId') as string)
    : []
  const chatRoomIds = isAdmin ? [] : chatParticipations

  let chatMessages: any[] = []
  if (isAdmin) {
    const allMsgSnap = await db.collection(COLLECTIONS.chatMessages).get()
    chatMessages = allMsgSnap.docs.map(docToApi)
  } else if (chatRoomIds.length > 0) {
    // Firestore не поддерживает >10 значений в 'in' — разбиваем по чанкам по 10
    const chunks: string[][] = []
    for (let i = 0; i < chatRoomIds.length; i += 10) {
      chunks.push(chatRoomIds.slice(i, i + 10))
    }
    const snaps = await Promise.all(
      chunks.map((chunk) =>
        db.collection(COLLECTIONS.chatMessages).where('chatRoomId', 'in', chunk).get()
      )
    )
    chatMessages = snaps.flatMap((s) => s.docs.map(docToApi))
  }
  chatMessages.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })
  chatMessages = chatMessages.slice(0, Math.min(limit, 20))

  const chatMessagesWithIncludes = await Promise.all(
    chatMessages.map(async (m: any) => {
      const [user, chatRoom] = await Promise.all([
        fetchUserShort(db, m.userId),
        (async () => {
          const cSnap = await db.collection(COLLECTIONS.chatRooms).doc(m.chatRoomId).get()
          if (!cSnap.exists) return null
          return { id: cSnap.id, name: cSnap.data()!.name }
        })(),
      ])
      return { ...m, user, chatRoom }
    })
  )

  // Объединяем все события в единый timeline
  type TimelineEvent = {
    id: string
    type: 'post' | 'verdict' | 'news' | 'stat_change' | 'chat_message'
    createdAt: string
    [key: string]: unknown
  }

  const events: TimelineEvent[] = []

  for (const p of postsWithIncludes) {
    events.push({
      id: `post-${p.id}`,
      type: 'post',
      createdAt: toIso(p.createdAt),
      title: p.title,
      content: String(p.content).slice(0, 200),
      status: p.status,
      turnNumber: p.turnNumber ?? null,
      weekNumber: p.weekNumber ?? null,
      author: p.author,
      faction: p.faction,
    })

    if (p.verdict) {
      const statChangesCount = p.verdict.statChanges
        ? ((safeParse(p.verdict.statChanges) as unknown[]) || []).length
        : 0
      events.push({
        id: `verdict-${p.verdict.id}`,
        type: 'verdict',
        createdAt: toIso(p.verdict.createdAt),
        postId: p.id,
        postTitle: p.title,
        roleplayText: String(p.verdict.roleplayText).slice(0, 200),
        technicalText: p.verdict.technicalText
          ? String(p.verdict.technicalText).slice(0, 200)
          : null,
        statChangesCount,
        admin: p.verdict.admin,
        faction: p.faction,
      })
    }
  }

  for (const n of newsWithIncludes) {
    events.push({
      id: `news-${n.id}`,
      type: 'news',
      createdAt: toIso(n.createdAt),
      title: n.title,
      excerpt: n.excerpt || null,
      category: n.category || 'GENERAL',
      isPinned: Boolean(n.isPinned),
      turnNumber: n.turnNumber ?? null,
      author: n.author,
    })
  }

  for (const c of statChangesWithIncludes) {
    events.push({
      id: `stat-${c.id}`,
      type: 'stat_change',
      createdAt: toIso(c.createdAt),
      sectionKey: c.sectionKey,
      changeType: c.changeType,
      oldValue: safeParse(c.oldValue),
      newValue: safeParse(c.newValue),
      verdictPost: c.verdict?.post?.title || null,
      admin: c.admin,
      faction: c.faction,
    })
  }

  for (const m of chatMessagesWithIncludes) {
    events.push({
      id: `msg-${m.id}`,
      type: 'chat_message',
      createdAt: toIso(m.createdAt),
      content: String(m.content).slice(0, 150),
      isSystem: Boolean(m.isSystem),
      user: m.user,
      chatRoom: m.chatRoom,
    })
  }

  // Сортируем по дате (новые сверху) и ограничиваем
  events.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )
  const limited = events.slice(0, limit)

  return jsonResponse({
    events: limited,
    total: events.length,
    counts: {
      posts: postsWithIncludes.length,
      verdicts: postsWithIncludes.filter((p) => p.verdict).length,
      news: newsWithIncludes.length,
      statChanges: statChangesWithIncludes.length,
      messages: chatMessagesWithIncludes.length,
    },
  })
}
