import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse, isBotRequest } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

const articleSchema = z.object({
  title: z.string().min(3).max(200),
  content: z.string().min(10),
  category: z.string().default('CHRONICLE'),
  era: z.string().optional(),
  order: z.number().int().default(0),
})

// GET /api/chronicle — список статей хроники (все авторизованные)
export async function GET() {
  await requireAuth()
  const db = getAdminDb()

  // NOTE: orderBy order + createdAt requires composite index. To avoid index issues,
  // fetch all docs ordered by createdAt desc, then sort client-side.
  // For better performance at scale, create composite index (order asc, createdAt desc).
  const snap = await db.collection(COLLECTIONS.chronicle).orderBy('createdAt', 'desc').get()

  let articles = snap.docs.map((d) => docToApi(d as any)) as any[]

  // Includes: author
  const authorIds = [...new Set(articles.map((a) => a.authorId).filter(Boolean))]
  const authorSnaps = await Promise.all(
    authorIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get())
  )
  const authorMap = new Map<string, any>()
  authorSnaps.forEach((s) => {
    if (s.exists) authorMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  articles = articles.map((a) => ({
    ...a,
    author: a.authorId ? authorMap.get(a.authorId) || null : null,
  }))

  // Sort: order asc, then createdAt desc
  articles.sort((a, b) => {
    const aOrder = a.order ?? 0
    const bOrder = b.order ?? 0
    if (aOrder !== bOrder) return aOrder - bOrder
    const aDate = new Date(a.createdAt || 0).getTime()
    const bDate = new Date(b.createdAt || 0).getTime()
    return bDate - aDate
  })

  return jsonResponse({ articles })
}

// POST /api/chronicle — создание статьи (только админ)
export async function POST(req: NextRequest) {
  if (isBotRequest(req)) return errorResponse('Доступ запрещён', 403)
  const ctx = await requireAdmin(req)

  const body = await req.json()
  const parsed = articleSchema.safeParse(body)
  if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)

  const db = getAdminDb()
  const id = crypto.randomUUID()
  const data = parsed.data
  await db.collection(COLLECTIONS.chronicle).doc(id).set({
    title: data.title,
    content: data.content,
    category: data.category,
    era: data.era ?? null,
    order: data.order,
    authorId: ctx.userId,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  })

  const articleSnap = await db.collection(COLLECTIONS.chronicle).doc(id).get()
  const article = docToApi(articleSnap as any) as any
  const authorSnap = await db.collection(COLLECTIONS.users).doc(ctx.userId).get()
  article.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null

  return jsonResponse({ article, message: 'Статья хроники создана' })
}
