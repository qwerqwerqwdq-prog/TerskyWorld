import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAuth(_req)
  const { id } = await params
  const db = getAdminDb()

  const articleSnap = await db.collection(COLLECTIONS.chronicle).doc(id).get()
  if (!articleSnap.exists) return errorResponse('Статья не найдена', 404)
  const article = docToApi(articleSnap as any) as any

  if (article.authorId) {
    const authorSnap = await db.collection(COLLECTIONS.users).doc(article.authorId).get()
    article.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  } else {
    article.author = null
  }

  return jsonResponse({ article })
}

const updateSchema = z.object({
  title: z.string().min(3).max(200).optional(),
  content: z.string().min(10).optional(),
  category: z.string().optional(),
  era: z.string().optional(),
  order: z.number().int().optional(),
})

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const body = await req.json()
  const parsed = updateSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  for (const [k, v] of Object.entries(parsed.data)) {
    if (v !== undefined) updateData[k] = v
  }
  await db.collection(COLLECTIONS.chronicle).doc(id).set(updateData, { merge: true })

  const articleSnap = await db.collection(COLLECTIONS.chronicle).doc(id).get()
  if (!articleSnap.exists) return errorResponse('Статья не найдена', 404)
  const article = docToApi(articleSnap as any) as any

  if (article.authorId) {
    const authorSnap = await db.collection(COLLECTIONS.users).doc(article.authorId).get()
    article.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  } else {
    article.author = null
  }

  return jsonResponse({ article })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(_req)
  const { id } = await params
  const db = getAdminDb()
  await db.collection(COLLECTIONS.chronicle).doc(id).delete()
  return jsonResponse({ success: true })
}
