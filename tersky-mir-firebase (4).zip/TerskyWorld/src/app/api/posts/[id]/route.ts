import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

// GET /api/posts/[id] — детали поста (автор или админ)
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(_req)
  const { id } = await params

  const db = getAdminDb()
  const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  if (!postSnap.exists) return errorResponse('Пост не найден', 404)

  const post = docToApi(postSnap as any) as any
  if (post.authorId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  // Includes: author, faction, attachments, verdict (with admin), battle
  const [authorSnap, factionSnap, attachmentsSnap, verdictSnap, battleSnap] = await Promise.all([
    post.authorId ? db.collection(COLLECTIONS.users).doc(post.authorId).get() : Promise.resolve(null),
    post.factionId ? db.collection(COLLECTIONS.factions).doc(post.factionId).get() : Promise.resolve(null),
    db.collection(COLLECTIONS.attachments).where('postId', '==', id).get(),
    db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get(),
    post.battleId ? db.collection(COLLECTIONS.battles).doc(post.battleId).get() : Promise.resolve(null),
  ])

  post.author = authorSnap && authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  post.faction = factionSnap && factionSnap.exists ? { id: factionSnap.id, name: (factionSnap.data() as any).name } : null
  post.attachments = attachmentsSnap.docs.map(docToApi)

  const vDoc = verdictSnap.docs[0]
  if (vDoc) {
    const vData = vDoc.data() as any
    let vAdmin: any = null
    if (vData.adminId) {
      const adminSnap = await db.collection(COLLECTIONS.users).doc(vData.adminId).get()
      if (adminSnap.exists) vAdmin = { id: adminSnap.id, name: (adminSnap.data() as any).name }
    }
    post.verdict = { ...docToApi(vDoc), admin: vAdmin }
  } else {
    post.verdict = null
  }

  post.battle = battleSnap && battleSnap.exists ? { id: battleSnap.id, name: (battleSnap.data() as any).name } : null

  return jsonResponse({ post })
}

// PUT /api/posts/[id] — редактирование поста (автор, если нет вердикта; админ всегда)
const updatePostSchema = z.object({
  title: z.string().min(3).max(200).optional(),
  content: z.string().min(10).optional(),
  context: z.string().optional(),
  turnNumber: z.number().int().optional(),
  weekNumber: z.number().int().optional(),
})

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(req)
  const { id } = await params

  const db = getAdminDb()
  const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  if (!postSnap.exists) return errorResponse('Пост не найден', 404)
  const postData = postSnap.data() as any

  if (postData.authorId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  // Проверяем наличие вердикта
  const verdictSnap = await db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get()
  const hasVerdict = !verdictSnap.empty

  // Автор не может редактировать после вердикта
  if (postData.authorId === ctx.userId && hasVerdict && ctx.role !== 'ADMIN') {
    return errorResponse('Пост с вердиктом нельзя редактировать', 403)
  }

  const body = await req.json()
  const parsed = updatePostSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  const updateData: Record<string, unknown> = { ...parsed.data, updatedAt: FieldValue.serverTimestamp() }
  await db.collection(COLLECTIONS.posts).doc(id).set(updateData, { merge: true })

  const updatedSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  const updated = docToApi(updatedSnap as any)

  return jsonResponse({ post: updated })
}

// DELETE /api/posts/[id] — удаление (автор без вердикта или админ)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(_req)
  const { id } = await params

  const db = getAdminDb()
  const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  if (!postSnap.exists) return errorResponse('Пост не найден', 404)
  const postData = postSnap.data() as any

  if (postData.authorId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  const verdictSnap = await db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get()
  const hasVerdict = !verdictSnap.empty
  if (postData.authorId === ctx.userId && hasVerdict && ctx.role !== 'ADMIN') {
    return errorResponse('Нельзя удалить пост с вердиктом', 403)
  }

  // Cascade delete attachments + verdicts
  const batch = db.batch()
  const attachmentsSnap = await db.collection(COLLECTIONS.attachments).where('postId', '==', id).get()
  attachmentsSnap.forEach((d) => batch.delete(d.ref))
  verdictSnap.forEach((d) => batch.delete(d.ref))
  batch.delete(postSnap.ref)
  await batch.commit()

  return jsonResponse({ success: true })
}
