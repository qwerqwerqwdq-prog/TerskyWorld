import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAdmin, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

// Утилита: безопасный парсинг JSON
function safeParse(s: string | null | undefined): unknown {
  if (!s) return null
  try { return JSON.parse(s) } catch { return s }
}

function apCount(n: number): string {
  if (n % 10 === 1 && n % 100 !== 11) return 'секция'
  if ([2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100)) return 'секции'
  return 'секций'
}

// GET /api/posts/[id]/verdict — текущие статы фракции поста + существующий вердикт + история изменений
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(_req)
  const { id } = await params

  const db = getAdminDb()
  const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  if (!postSnap.exists) return errorResponse('Пост не найден', 404)
  const postData = docToApi(postSnap as any) as any
  if (!postData.factionId) return errorResponse('У поста нет привязанной фракции', 400)

  const factionId = postData.factionId

  const [factionSnap, statsSnap, verdictSnap, changeLogsSnap] = await Promise.all([
    db.collection(COLLECTIONS.factions).doc(factionId).get(),
    // composite index required: (factionId, order)
    db.collection(COLLECTIONS.factionStats).where('factionId', '==', factionId).orderBy('order', 'asc').get(),
    db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get(),
    // composite index required: (factionId, createdAt)
    db.collection(COLLECTIONS.statChangeLogs).where('factionId', '==', factionId).orderBy('createdAt', 'desc').limit(20).get(),
  ])

  const faction = factionSnap.exists ? docToApi(factionSnap as any) : null
  const verdictDoc = verdictSnap.docs[0]
  const verdict = verdictDoc ? docToApi(verdictDoc as any) : null

  const stats = statsSnap.docs.map((s) => {
    const d = docToApi(s as any) as any
    return { ...d, content: safeParse(d.content) }
  })

  // changeLogs: include verdict (with post + admin), admin
  const changeLogs = changeLogsSnap.docs.map((d) => docToApi(d as any) as any)
  const verdictIds = [...new Set(changeLogs.map((c) => c.verdictId).filter(Boolean))]
  const adminIds = [...new Set(changeLogs.map((c) => c.adminId).filter(Boolean))]

  const [verdictSnaps, adminSnaps] = await Promise.all([
    Promise.all(verdictIds.map((vid) => db.collection(COLLECTIONS.verdicts).doc(vid!).get())),
    Promise.all(adminIds.map((aid) => db.collection(COLLECTIONS.users).doc(aid!).get())),
  ])
  const verdictMap = new Map<string, any>()
  const verdictAdminIds: string[] = []
  verdictSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      verdictMap.set(s.id, { ...docToApi(s as any), postId: data.postId })
      if (data.postId) verdictAdminIds.push(data.postId) // for fetching post title
    }
  })
  const postIds = [...new Set(verdictSnaps.filter((s) => s.exists).map((s) => (s.data() as any).postId).filter(Boolean))]
  const postTitleSnaps = await Promise.all(postIds.map((pid) => db.collection(COLLECTIONS.posts).doc(pid).get()))
  const postMap = new Map<string, any>()
  postTitleSnaps.forEach((s) => {
    if (s.exists) postMap.set(s.id, { id: s.id, title: (s.data() as any).title })
  })

  const adminMap = new Map<string, any>()
  adminSnaps.forEach((s) => {
    if (s.exists) adminMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  // for each verdict, fetch admin
  const verdictAdminSnaps = await Promise.all(
    [...verdictMap.values()].map(async (v: any) => {
      // Need to fetch admin for verdict — but verdict doc may not have adminId exposed via docToApi
      const vSnap = await db.collection(COLLECTIONS.verdicts).doc(v.id).get()
      const vData = vSnap.data() as any
      let admin: any = null
      if (vData.adminId) {
        const adminSnap = await db.collection(COLLECTIONS.users).doc(vData.adminId).get()
        if (adminSnap.exists) admin = { id: adminSnap.id, name: (adminSnap.data() as any).name }
      }
      const post = vData.postId ? postMap.get(vData.postId) : null
      return { id: v.id, post, admin }
    })
  )
  const verdictMetaMap = new Map<string, any>()
  verdictAdminSnaps.forEach((m) => verdictMetaMap.set(m.id, m))

  const changeLogsWithIncludes = changeLogs.map((c) => ({
    ...c,
    oldValue: safeParse(c.oldValue),
    newValue: safeParse(c.newValue),
    admin: c.adminId ? adminMap.get(c.adminId) : null,
    verdict: c.verdictId
      ? {
          ...verdictMap.get(c.verdictId),
          post: verdictMetaMap.get(c.verdictId)?.post || null,
          admin: verdictMetaMap.get(c.verdictId)?.admin || null,
        }
      : null,
  }))

  return jsonResponse({
    faction,
    verdict,
    currentStats: stats,
    changeLogs: changeLogsWithIncludes,
    adminId: ctx.userId,
  })
}

// statChanges: массив { sectionKey, sectionTitle?, oldContent?, newContent }
const verdictSchema = z.object({
  roleplayText: z.string().min(5, 'Ролевая часть обязательна'),
  technicalText: z.string().optional(),
  statChanges: z.string().optional(),
})

// POST /api/posts/[id]/verdict — создание/обновление вердикта (только админ)
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req)
  const { id } = await params

  const db = getAdminDb()
  const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  if (!postSnap.exists) return errorResponse('Пост не найден', 404)
  const postData = docToApi(postSnap as any) as any
  if (!postData.factionId) return errorResponse('У поста нет привязанной фракции', 400)

  const factionId = postData.factionId

  const body = await req.json()
  const parsed = verdictSchema.safeParse(body)
  if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)

  const { roleplayText, technicalText, statChanges } = parsed.data

  // Находим существующий вердикт
  const existingVerdictSnap = await db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get()
  const existingVerdictDoc = existingVerdictSnap.docs[0]

  // Если есть существующий вердикт — откатим его предыдущие изменения статов
  if (existingVerdictDoc) {
    const existing = docToApi(existingVerdictDoc as any) as any
    if (existing.statChanges) {
      try {
        const prevChanges = JSON.parse(existing.statChanges) as Array<{
          sectionKey: string
          oldContent?: unknown
        }>
        for (const change of prevChanges) {
          if (change.sectionKey && change.oldContent !== undefined) {
            const statRef = db.collection(COLLECTIONS.factionStats).doc(`${factionId}_${change.sectionKey}`)
            const existingStatSnap = await statRef.get()
            if (existingStatSnap.exists) {
              await statRef.set({ content: JSON.stringify(change.oldContent), updatedAt: FieldValue.serverTimestamp() }, { merge: true })
            }
          }
        }
      } catch (e) {
        console.error('Rollback previous verdict changes error:', e)
      }
    }
  }

  // Создаём или обновляем вердикт
  const verdictId = existingVerdictDoc?.id || crypto.randomUUID()
  const verdictData: Record<string, unknown> = {
    postId: id,
    roleplayText,
    technicalText: technicalText ?? null,
    statChanges: statChanges ?? null,
    adminId: ctx.userId,
    isFinal: true,
    updatedAt: FieldValue.serverTimestamp(),
  }
  if (!existingVerdictDoc) {
    verdictData.createdAt = FieldValue.serverTimestamp()
  }
  await db.collection(COLLECTIONS.verdicts).doc(verdictId).set(verdictData, { merge: true })

  // Меняем статус поста
  await db.collection(COLLECTIONS.posts).doc(id).set(
    { status: 'VERDICTED', updatedAt: FieldValue.serverTimestamp() },
    { merge: true }
  )

  // Применяем изменения статистики с сохранением oldValue
  let appliedCount = 0
  if (statChanges) {
    try {
      const changes = JSON.parse(statChanges) as Array<{
        sectionKey: string
        sectionTitle?: string
        oldContent?: unknown
        newContent: unknown
      }>

      const enrichedChanges: Array<{
        sectionKey: string
        sectionTitle?: string
        oldContent: unknown
        newContent: unknown
      }> = []
      for (const change of changes) {
        if (!change.sectionKey || change.newContent === undefined) continue
        let oldContent = change.oldContent
        if (oldContent === undefined) {
          const statSnap = await db.collection(COLLECTIONS.factionStats).doc(`${factionId}_${change.sectionKey}`).get()
          oldContent = statSnap.exists ? safeParse((statSnap.data() as any).content) : null
        }
        enrichedChanges.push({
          sectionKey: change.sectionKey,
          sectionTitle: change.sectionTitle,
          oldContent,
          newContent: change.newContent,
        })
      }

      for (const change of enrichedChanges) {
        const statRef = db.collection(COLLECTIONS.factionStats).doc(`${factionId}_${change.sectionKey}`)
        const defSnap = await statRef.get()
        const existedBefore = defSnap.exists

        const statDocData: Record<string, unknown> = {
          factionId,
          sectionKey: change.sectionKey,
          sectionTitle: change.sectionTitle || change.sectionKey,
          content: JSON.stringify(change.newContent),
          updatedAt: FieldValue.serverTimestamp(),
        }
        if (!existedBefore) {
          // get order from STAT_SECTIONS or default to 0
          statDocData.order = 0
        }
        await statRef.set(statDocData, { merge: true })

        // Логируем с oldValue
        await db.collection(COLLECTIONS.statChangeLogs).add({
          factionId,
          verdictId,
          sectionKey: change.sectionKey,
          changeType: existedBefore ? 'UPDATE' : 'CREATE',
          oldValue: existedBefore ? (defSnap.data() as any).content : null,
          newValue: JSON.stringify(change.newContent),
          adminId: ctx.userId,
          createdAt: FieldValue.serverTimestamp(),
        })
        appliedCount++
      }

      // Сохраняем enriched statChanges в вердикте
      await db.collection(COLLECTIONS.verdicts).doc(verdictId).set(
        { statChanges: JSON.stringify(enrichedChanges) },
        { merge: true }
      )
    } catch (e) {
      console.error('Apply stat changes error:', e)
    }
  }

  // Активность
  await db.collection(COLLECTIONS.activity).add({
    type: 'VERDICT_CREATED',
    userId: ctx.userId,
    targetId: id,
    data: { postId: id, verdictId },
    createdAt: FieldValue.serverTimestamp(),
  })

  // Возвращаем полный вердикт с admin
  const fullVerdictSnap = await db.collection(COLLECTIONS.verdicts).doc(verdictId).get()
  const fullVerdict = docToApi(fullVerdictSnap as any) as any
  let admin: any = null
  if (fullVerdict.adminId) {
    const adminSnap = await db.collection(COLLECTIONS.users).doc(fullVerdict.adminId).get()
    if (adminSnap.exists) admin = { id: adminSnap.id, name: (adminSnap.data() as any).name }
  }
  fullVerdict.admin = admin

  return jsonResponse({
    verdict: fullVerdict,
    message: `Вердикт вынесен${appliedCount > 0 ? `, статистика обновлена (${appliedCount} ${apCount(appliedCount)})` : ''}`,
  })
}

// DELETE /api/posts/[id]/verdict — удаление вердикта с откатом статистики (только админ)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(_req)
  const { id } = await params

  const db = getAdminDb()
  const verdictSnap = await db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get()
  if (verdictSnap.empty) return errorResponse('Вердикт не найден', 404)

  const verdictDoc = verdictSnap.docs[0]
  const verdictId = verdictDoc.id
  const verdictData = docToApi(verdictDoc as any) as any

  // Нужно получить post.factionId
  const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
  const postData = postSnap.exists ? (postSnap.data() as any) : null
  const factionId = postData?.factionId

  if (verdictData.statChanges && factionId) {
    try {
      const changes = JSON.parse(verdictData.statChanges) as Array<{
        sectionKey: string
        oldContent?: unknown
        newContent?: unknown
      }>
      for (const change of changes) {
        if (!change.sectionKey) continue
        const statRef = db.collection(COLLECTIONS.factionStats).doc(`${factionId}_${change.sectionKey}`)
        const existingSnap = await statRef.get()
        if (!existingSnap.exists) continue

        if (change.oldContent === null || change.oldContent === undefined) {
          await statRef.delete()
        } else {
          await statRef.set(
            { content: JSON.stringify(change.oldContent), updatedAt: FieldValue.serverTimestamp() },
            { merge: true }
          )
        }

        await db.collection(COLLECTIONS.statChangeLogs).add({
          factionId,
          verdictId,
          sectionKey: change.sectionKey,
          changeType: 'DELETE',
          oldValue: (existingSnap.data() as any).content,
          newValue: change.oldContent ? JSON.stringify(change.oldContent) : null,
          adminId: ctx.userId,
          createdAt: FieldValue.serverTimestamp(),
        })
      }
    } catch (e) {
      console.error('Rollback stat changes on verdict delete error:', e)
    }
  }

  await db.collection(COLLECTIONS.verdicts).doc(verdictId).delete()
  await db.collection(COLLECTIONS.posts).doc(id).set(
    { status: 'PENDING', updatedAt: FieldValue.serverTimestamp() },
    { merge: true }
  )

  return jsonResponse({ success: true, message: 'Вердикт отозван, статистика возвращена к исходному состоянию' })
}
