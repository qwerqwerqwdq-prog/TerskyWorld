import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse, isBotRequest } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

const postSchema = z.object({
  title: z.string().min(3, 'Заголовок минимум 3 символа').max(200),
  content: z.string().min(10, 'Содержание слишком короткое'),
  context: z.string().optional(),
  turnNumber: z.number().int().optional(),
  weekNumber: z.number().int().optional(),
  battleId: z.string().optional(),
})

// GET /api/posts — список постов (игрок видит свои, админ — все)
// NOTE: requires composite indexes for (authorId, createdAt) and (status, createdAt) and (battleId, createdAt)
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const status = req.nextUrl.searchParams.get('status')
  const battleId = req.nextUrl.searchParams.get('battleId')

  const db = getAdminDb()
  let q: FirebaseFirestore.Query = db.collection(COLLECTIONS.posts)

  if (ctx.role !== 'ADMIN') {
    q = q.where('authorId', '==', ctx.userId)
  }
  if (status) q = q.where('status', '==', status)
  if (battleId) q = q.where('battleId', '==', battleId)

  // orderBy createdAt desc — requires composite index when combined with where
  q = q.orderBy('createdAt', 'desc')

  const snap = await q.get()
  const posts = snap.docs.map(docToApi) as any[]

  // Includes (manual fetch): author, faction, attachments, verdict
  const authorIds = [...new Set(posts.map((p) => p.authorId).filter(Boolean))]
  const factionIds = [...new Set(posts.map((p) => p.factionId).filter(Boolean))]
  const postIds = posts.map((p) => p.id)

  const [authorSnaps, factionSnaps, attachmentsSnaps, verdictSnaps] = await Promise.all([
    Promise.all(authorIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get())),
    Promise.all(factionIds.map((id) => db.collection(COLLECTIONS.factions).doc(id).get())),
    Promise.all(postIds.map((id) => db.collection(COLLECTIONS.attachments).where('postId', '==', id).get())),
    Promise.all(postIds.map((id) => db.collection(COLLECTIONS.verdicts).where('postId', '==', id).limit(1).get())),
  ])

  const authorMap = new Map<string, any>()
  authorSnaps.forEach((s) => {
    if (s.exists) authorMap.set(s.id, s.data() as any)
  })
  const factionMap = new Map<string, any>()
  factionSnaps.forEach((s) => {
    if (s.exists) factionMap.set(s.id, s.data() as any)
  })

  // Admin map for verdict.admin
  const adminIdsFromVerdicts: string[] = []
  verdictSnaps.forEach((vs) => {
    vs.forEach((v) => {
      const data = v.data() as any
      if (data.adminId) adminIdsFromVerdicts.push(data.adminId)
    })
  })
  const uniqueAdminIds = [...new Set(adminIdsFromVerdicts)]
  const adminSnaps = await Promise.all(
    uniqueAdminIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get())
  )
  const adminMap = new Map<string, any>()
  adminSnaps.forEach((s) => {
    if (s.exists) adminMap.set(s.id, s.data() as any)
  })

  posts.forEach((p, i) => {
    const author = authorMap.get(p.authorId)
    p.author = author ? { id: p.authorId, name: author.name } : null

    const faction = p.factionId ? factionMap.get(p.factionId) : null
    p.faction = faction ? { id: p.factionId, name: faction.name } : null

    p.attachments = attachmentsSnaps[i].docs.map(docToApi)

    const vSnap = verdictSnaps[i].docs[0]
    if (vSnap) {
      const vData = vSnap.data() as any
      const vAdmin = vData.adminId ? adminMap.get(vData.adminId) : null
      p.verdict = {
        ...docToApi(vSnap),
        admin: vAdmin ? { id: vData.adminId, name: vAdmin.name } : null,
      }
    } else {
      p.verdict = null
    }
  })

  return jsonResponse({ posts })
}

// POST /api/posts — создание поста
export async function POST(req: NextRequest) {
  if (isBotRequest(req)) return errorResponse('Доступ запрещён', 403)
  const ctx = await requireAuth(req)

  try {
    const body = await req.json()
    const parsed = postSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)
    }

    const data = parsed.data
    const db = getAdminDb()
    const id = crypto.randomUUID()
    const postData: Record<string, unknown> = {
      title: data.title,
      content: data.content,
      context: data.context ?? null,
      turnNumber: data.turnNumber ?? null,
      weekNumber: data.weekNumber ?? null,
      status: 'PENDING',
      isPublic: false,
      battleId: data.battleId ?? null,
      authorId: ctx.userId,
      factionId: ctx.factionId ?? null,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }

    await db.collection(COLLECTIONS.posts).doc(id).set(postData)

    const postSnap = await db.collection(COLLECTIONS.posts).doc(id).get()
    const post = docToApi(postSnap as any)

    return jsonResponse({ post, message: 'Пост отправлен на рассмотрение администратора' })
  } catch (e) {
    console.error('Create post error:', e)
    return errorResponse('Ошибка создания поста', 500)
  }
}
