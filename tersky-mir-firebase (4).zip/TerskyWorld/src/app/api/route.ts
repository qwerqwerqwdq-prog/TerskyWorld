// Root health-check endpoint
export async function GET() {
  return Response.json({
    status: 'ok',
    service: 'Терский Мир',
    version: '1.0-firebase',
  })
}
