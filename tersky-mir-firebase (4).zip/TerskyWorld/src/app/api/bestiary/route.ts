import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse, isBotRequest } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

const entrySchema = z.object({
  name: z.string().min(2).max(200),
  title: z.string().optional(),
  content: z.string().min(10),
  category: z.string().default('CREATURE'),
  danger: z.string().optional(),
  habitat: z.string().optional(),
  imageUrl: z.string().optional(),
  order: z.number().int().default(0),
})

// GET /api/bestiary — список записей бестиария (все авторизованные)
export async function GET(req: NextRequest) {
  await requireAuth(req)
  const category = req.nextUrl.searchParams.get('category')

  const db = getAdminDb()
  let q: FirebaseFirestore.Query = db.collection(COLLECTIONS.bestiary)
  if (category) q = q.where('category', '==', category)

  // NOTE: orderBy order + createdAt requires composite index. Sort client-side to avoid index requirement.
  q = q.orderBy('createdAt', 'desc')
  const snap = await q.get()

  let entries = snap.docs.map((d) => docToApi(d as any)) as any[]

  const authorIds = [...new Set(entries.map((e) => e.authorId).filter(Boolean))]
  const authorSnaps = await Promise.all(
    authorIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get())
  )
  const authorMap = new Map<string, any>()
  authorSnaps.forEach((s) => {
    if (s.exists) authorMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  entries = entries.map((e) => ({
    ...e,
    author: e.authorId ? authorMap.get(e.authorId) || null : null,
  }))

  // Sort: order asc, createdAt desc
  entries.sort((a, b) => {
    const aOrder = a.order ?? 0
    const bOrder = b.order ?? 0
    if (aOrder !== bOrder) return aOrder - bOrder
    const aDate = new Date(a.createdAt || 0).getTime()
    const bDate = new Date(b.createdAt || 0).getTime()
    return bDate - aDate
  })

  return jsonResponse({ entries })
}

// POST /api/bestiary — создание записи (только админ)
export async function POST(req: NextRequest) {
  if (isBotRequest(req)) return errorResponse('Доступ запрещён', 403)
  const ctx = await requireAdmin(req)

  const body = await req.json()
  const parsed = entrySchema.safeParse(body)
  if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)

  const db = getAdminDb()
  const id = crypto.randomUUID()
  const data = parsed.data
  await db.collection(COLLECTIONS.bestiary).doc(id).set({
    name: data.name,
    title: data.title ?? null,
    content: data.content,
    category: data.category,
    danger: data.danger ?? null,
    habitat: data.habitat ?? null,
    imageUrl: data.imageUrl ?? null,
    order: data.order,
    authorId: ctx.userId,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  })

  const entrySnap = await db.collection(COLLECTIONS.bestiary).doc(id).get()
  const entry = docToApi(entrySnap as any) as any
  const authorSnap = await db.collection(COLLECTIONS.users).doc(ctx.userId).get()
  entry.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null

  return jsonResponse({ entry, message: 'Запись бестиария создана' })
}
