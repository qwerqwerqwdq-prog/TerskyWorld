import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAuth(_req)
  const { id } = await params
  const db = getAdminDb()

  const entrySnap = await db.collection(COLLECTIONS.bestiary).doc(id).get()
  if (!entrySnap.exists) return errorResponse('Запись не найдена', 404)
  const entry = docToApi(entrySnap as any) as any

  if (entry.authorId) {
    const authorSnap = await db.collection(COLLECTIONS.users).doc(entry.authorId).get()
    entry.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  } else {
    entry.author = null
  }

  return jsonResponse({ entry })
}

const updateSchema = z.object({
  name: z.string().min(2).max(200).optional(),
  title: z.string().optional(),
  content: z.string().min(10).optional(),
  category: z.string().optional(),
  danger: z.string().optional(),
  habitat: z.string().optional(),
  imageUrl: z.string().optional(),
  order: z.number().int().optional(),
})

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const body = await req.json()
  const parsed = updateSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  for (const [k, v] of Object.entries(parsed.data)) {
    if (v !== undefined) updateData[k] = v
  }
  await db.collection(COLLECTIONS.bestiary).doc(id).set(updateData, { merge: true })

  const entrySnap = await db.collection(COLLECTIONS.bestiary).doc(id).get()
  if (!entrySnap.exists) return errorResponse('Запись не найдена', 404)
  const entry = docToApi(entrySnap as any) as any

  if (entry.authorId) {
    const authorSnap = await db.collection(COLLECTIONS.users).doc(entry.authorId).get()
    entry.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  } else {
    entry.author = null
  }

  return jsonResponse({ entry })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(_req)
  const { id } = await params
  const db = getAdminDb()
  await db.collection(COLLECTIONS.bestiary).doc(id).delete()
  return jsonResponse({ success: true })
}
