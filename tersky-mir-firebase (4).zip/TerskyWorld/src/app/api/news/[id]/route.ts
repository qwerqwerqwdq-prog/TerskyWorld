import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAuth(_req)
  const { id } = await params
  const db = getAdminDb()

  const newsSnap = await db.collection(COLLECTIONS.news).doc(id).get()
  if (!newsSnap.exists) return errorResponse('Новость не найдена', 404)
  const news = docToApi(newsSnap as any) as any

  // Include author
  if (news.authorId) {
    const authorSnap = await db.collection(COLLECTIONS.users).doc(news.authorId).get()
    news.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  } else {
    news.author = null
  }

  return jsonResponse({ news })
}

const updateNewsSchema = z.object({
  title: z.string().min(3).max(200).optional(),
  content: z.string().min(10).optional(),
  excerpt: z.string().optional(),
  category: z.string().optional(),
  isPinned: z.boolean().optional(),
  turnNumber: z.number().int().optional(),
})

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const body = await req.json()
  const parsed = updateNewsSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  // Filter undefined values
  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  for (const [k, v] of Object.entries(parsed.data)) {
    if (v !== undefined) updateData[k] = v
  }
  await db.collection(COLLECTIONS.news).doc(id).set(updateData, { merge: true })

  const newsSnap = await db.collection(COLLECTIONS.news).doc(id).get()
  if (!newsSnap.exists) return errorResponse('Новость не найдена', 404)
  const news = docToApi(newsSnap as any) as any

  if (news.authorId) {
    const authorSnap = await db.collection(COLLECTIONS.users).doc(news.authorId).get()
    news.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null
  } else {
    news.author = null
  }

  return jsonResponse({ news })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(_req)
  const { id } = await params
  const db = getAdminDb()
  await db.collection(COLLECTIONS.news).doc(id).delete()
  return jsonResponse({ success: true })
}
