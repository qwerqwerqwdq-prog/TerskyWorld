import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse, isBotRequest } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

const newsSchema = z.object({
  title: z.string().min(3).max(200),
  content: z.string().min(10),
  excerpt: z.string().optional(),
  category: z.string().default('GENERAL'),
  isPinned: z.boolean().default(false),
  turnNumber: z.number().int().optional(),
})

// GET /api/news — список новостей (доступен всем авторизованным)
export async function GET(req: NextRequest) {
  await requireAuth(req)
  const category = req.nextUrl.searchParams.get('category')

  const db = getAdminDb()
  let q: FirebaseFirestore.Query = db.collection(COLLECTIONS.news)
  if (category) q = q.where('category', '==', category)

  // NOTE: orderBy isPinned + createdAt requires composite index. To avoid index requirement issues,
  // we fetch and sort client-side. For large datasets consider creating an index instead.
  q = q.orderBy('createdAt', 'desc')
  const snap = await q.get()

  let news = snap.docs.map((d) => docToApi(d as any)) as any[]

  // Includes: author
  const authorIds = [...new Set(news.map((n) => n.authorId).filter(Boolean))]
  const authorSnaps = await Promise.all(
    authorIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get())
  )
  const authorMap = new Map<string, any>()
  authorSnaps.forEach((s) => {
    if (s.exists) authorMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  news = news.map((n) => ({
    ...n,
    author: n.authorId ? authorMap.get(n.authorId) || null : null,
  }))

  // Sort: pinned first, then by createdAt desc
  news.sort((a, b) => {
    const aPinned = a.isPinned ? 1 : 0
    const bPinned = b.isPinned ? 1 : 0
    if (aPinned !== bPinned) return bPinned - aPinned
    const aDate = new Date(a.createdAt || 0).getTime()
    const bDate = new Date(b.createdAt || 0).getTime()
    return bDate - aDate
  })

  return jsonResponse({ news })
}

// POST /api/news — создание новости (только админ)
export async function POST(req: NextRequest) {
  if (isBotRequest(req)) return errorResponse('Доступ запрещён', 403)
  const ctx = await requireAdmin(req)

  const body = await req.json()
  const parsed = newsSchema.safeParse(body)
  if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)

  const db = getAdminDb()
  const id = crypto.randomUUID()
  const data = parsed.data
  await db.collection(COLLECTIONS.news).doc(id).set({
    title: data.title,
    content: data.content,
    excerpt: data.excerpt ?? null,
    category: data.category,
    isPinned: data.isPinned,
    turnNumber: data.turnNumber ?? null,
    authorId: ctx.userId,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  })

  const newsSnap = await db.collection(COLLECTIONS.news).doc(id).get()
  const news = docToApi(newsSnap as any) as any
  const authorSnap = await db.collection(COLLECTIONS.users).doc(ctx.userId).get()
  news.author = authorSnap.exists ? { id: authorSnap.id, name: (authorSnap.data() as any).name } : null

  return jsonResponse({ news, message: 'Новость опубликована' })
}
