import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'

function safeParse(s: string | null | undefined): unknown {
  if (!s) return null
  try {
    return JSON.parse(s)
  } catch {
    return s
  }
}

// Вспомогательная функция — преобразование Firestore Timestamp → ISO
function toIso(ts: any): string {
  if (!ts) return new Date(0).toISOString()
  if (typeof ts === 'string') return ts
  if (typeof ts === 'number') return new Date(ts).toISOString()
  if (ts instanceof Date) return ts.toISOString()
  if (typeof ts === 'object' && ts !== null && '_seconds' in ts) {
    return new Date(
      ts._seconds * 1000 + (ts._nanoseconds || 0) / 1e6
    ).toISOString()
  }
  return new Date(0).toISOString()
}

// Загружаем пользователя (id + name)
async function fetchUserShort(db: ReturnType<typeof getAdminDb>, userId: string) {
  const snap = await db.collection(COLLECTIONS.users).doc(userId).get()
  if (!snap.exists) return null
  return { id: snap.id, name: snap.data()!.name }
}

// Загружаем фракцию (id + name)
async function fetchFactionShort(db: ReturnType<typeof getAdminDb>, factionId: string | null) {
  if (!factionId) return null
  const snap = await db.collection(COLLECTIONS.factions).doc(factionId).get()
  if (!snap.exists) return null
  return { id: snap.id, name: snap.data()!.name }
}

// GET /api/notifications — агрегированная лента уведомлений для текущего пользователя
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const sinceParam = req.nextUrl.searchParams.get('since')
  const since = sinceParam ? new Date(sinceParam) : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)

  const db = getAdminDb()
  const isAdmin = ctx.role === 'ADMIN'

  // 1. Вердикты на посты текущего игрока (или все для admin)
  let verdictsSnap
  if (isAdmin) {
    verdictsSnap = await db
      .collection(COLLECTIONS.verdicts)
      .where('createdAt', '>=', since)
      .limit(10)
      .get()
  } else {
    // Сначала получаем все вердикты за период, потом фильтруем по автору поста
    verdictsSnap = await db
      .collection(COLLECTIONS.verdicts)
      .where('createdAt', '>=', since)
      .get()
  }
  const verdicts: any[] = []

  // Для каждого вердикта загружаем пост + admin
  for (const vDoc of verdictsSnap.docs) {
    const v = docToApi(vDoc as any) as any
    const pSnap = await db.collection(COLLECTIONS.posts).doc(v.postId as string).get()
    if (!pSnap.exists) continue
    const p = pSnap.data()!
    // Для player — только его посты
    if (!isAdmin && p.authorId !== ctx.userId) continue

    const [author, faction, admin] = await Promise.all([
      fetchUserShort(db, p.authorId as string),
      fetchFactionShort(db, (p.factionId as string) || null),
      fetchUserShort(db, v.adminId as string),
    ])

    const statChanges = v.statChanges ? (safeParse(v.statChanges as string) as unknown[]) : []

    verdicts.push({
      id: v.id,
      type: 'verdict' as const,
      createdAt: toIso(v.createdAt),
      post: { id: pSnap.id, title: p.title },
      author,
      faction,
      admin,
      roleplayText: String(v.roleplayText).slice(0, 150),
      statChangesCount: statChanges.length,
    })

    if (isAdmin && verdicts.length >= 10) break
  }

  // 2. Новости (для всех)
  const newsSnap = await db
    .collection(COLLECTIONS.news)
    .where('createdAt', '>=', since)
    .limit(5)
    .get()
  const news: any[] = newsSnap.docs.map((d) => {
    const n = docToApi(d as any)
    return {
      id: n.id,
      type: 'news' as const,
      createdAt: toIso(n.createdAt),
      title: n.title,
      excerpt: n.excerpt || null,
      category: n.category || 'GENERAL',
      isPinned: Boolean(n.isPinned),
    }
  })

  // 3. Новые сообщения в чатах, где участвует игрок
  const chatPartSnap = await db
    .collection(COLLECTIONS.chatParticipants)
    .where('userId', '==', ctx.userId)
    .get()
  const chatRoomIds = chatPartSnap.docs.map((d) => d.get('chatRoomId') as string)

  let recentMessages: any[] = []
  if (chatRoomIds.length > 0) {
    // Firestore 'in' — максимум 10 значений. Бьём на чанки.
    const chunks: string[][] = []
    for (let i = 0; i < chatRoomIds.length; i += 10) {
      chunks.push(chatRoomIds.slice(i, i + 10))
    }
    const snaps = await Promise.all(
      chunks.map((chunk) =>
        db.collection(COLLECTIONS.chatMessages).where('chatRoomId', 'in', chunk).get()
      )
    )
    let allMsgs = snaps.flatMap((s) => s.docs.map(docToApi)) as any[]
    // Фильтр: не свои + не системные + новее since
    allMsgs = allMsgs.filter(
      (m) =>
        m.userId !== ctx.userId &&
        !m.isSystem &&
        m.createdAt &&
        new Date(toIso(m.createdAt)).getTime() >= since.getTime()
    )
    allMsgs.sort((a, b) => {
      const aT = a.createdAt ? new Date(toIso(a.createdAt)).getTime() : 0
      const bT = b.createdAt ? new Date(toIso(b.createdAt)).getTime() : 0
      return bT - aT
    })
    allMsgs = allMsgs.slice(0, 10)
    recentMessages = await Promise.all(
      allMsgs.map(async (m) => {
        const [user, chatRoom] = await Promise.all([
          fetchUserShort(db, m.userId),
          (async () => {
            const cSnap = await db.collection(COLLECTIONS.chatRooms).doc(m.chatRoomId).get()
            if (!cSnap.exists) return null
            return { id: cSnap.id, name: cSnap.data()!.name }
          })(),
        ])
        return {
          id: m.id,
          type: 'message' as const,
          createdAt: toIso(m.createdAt),
          content: String(m.content).slice(0, 120),
          user,
          chatRoom,
        }
      })
    )
  }

  // 4. Посты ожидающие вердикта (для admin)
  let pendingPosts: any[] = []
  if (isAdmin) {
    const pendingSnap = await db
      .collection(COLLECTIONS.posts)
      .where('status', '==', 'PENDING')
      .get()
    let pending = pendingSnap.docs.map(docToApi) as any[]
    pending.sort((a, b) => {
      const aT = a.createdAt ? new Date(toIso(a.createdAt)).getTime() : 0
      const bT = b.createdAt ? new Date(toIso(b.createdAt)).getTime() : 0
      return bT - aT
    })
    pending = pending.slice(0, 5)
    pendingPosts = await Promise.all(
      pending.map(async (p) => {
        const [author, faction] = await Promise.all([
          fetchUserShort(db, p.authorId),
          fetchFactionShort(db, p.factionId || null),
        ])
        return {
          id: p.id,
          type: 'pending_post' as const,
          createdAt: toIso(p.createdAt),
          title: p.title,
          author,
          faction,
        }
      })
    )
  }

  // Объединяем и сортируем по дате
  const allItems = [...verdicts, ...news, ...recentMessages, ...pendingPosts]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 20)

  // Считаем "непрочитанные" — все, что новее 24 часов
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000)
  const unreadCount = allItems.filter((i) => new Date(i.createdAt) > yesterday).length

  return jsonResponse({
    notifications: allItems,
    unreadCount,
    total: allItems.length,
  })
}

// PATCH /api/notifications — отметка уведомлений как прочитанных
// Сохраняет notificationsLastReadAt на doc пользователя
export async function PATCH(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()

  await db.collection('users').doc(ctx.userId).update({
    notificationsLastReadAt: FieldValue.serverTimestamp(),
  })

  return jsonResponse({ success: true, message: 'Уведомления отмечены как прочитанные' })
}
