import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import {
  requireAuth,
  requireAdmin,
  jsonResponse,
  errorResponse,
} from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'
import { randomUUID } from 'crypto'

// Загружаем фракцию (краткий формат)
async function fetchFactionShort(db: ReturnType<typeof getAdminDb>, factionId: string) {
  if (!factionId) return null
  const snap = await db.collection(COLLECTIONS.factions).doc(factionId).get()
  if (!snap.exists) return null
  const data = snap.data()!
  return {
    id: snap.id,
    name: data.name,
    shortName: data.shortName || null,
  }
}

async function fetchUserShort(db: ReturnType<typeof getAdminDb>, userId: string) {
  const snap = await db.collection(COLLECTIONS.users).doc(userId).get()
  if (!snap.exists) return null
  const data = snap.data()!
  return { id: snap.id, name: data.name }
}

// Загружаем силы фракций в бою (с полем faction: { id, name, shortName })
async function fetchBattleForces(db: ReturnType<typeof getAdminDb>, battleId: string) {
  const snap = await db
    .collection(COLLECTIONS.battleForces)
    .where('battleId', '==', battleId)
    .get()
  const forcesRaw = snap.docs.map(docToApi)
  const forces = await Promise.all(
    forcesRaw.map(async (f: any) => ({
      id: f.id,
      battleId: f.battleId,
      factionId: f.factionId,
      commander: f.commander || '',
      infantry: Number(f.infantry) || 0,
      archers: Number(f.archers) || 0,
      cavalry: Number(f.cavalry) || 0,
      fleet: Number(f.fleet) || 0,
      special: f.special || null,
      description: f.description || null,
      faction: await fetchFactionShort(db, f.factionId),
    }))
  )
  return forces
}

async function fetchBattleParticipants(db: ReturnType<typeof getAdminDb>, battleId: string) {
  const snap = await db
    .collection(COLLECTIONS.battleParticipants)
    .where('battleId', '==', battleId)
    .get()
  const partsRaw = snap.docs.map(docToApi)
  const parts = await Promise.all(
    partsRaw.map(async (p: any) => ({
      id: p.id,
      battleId: p.battleId,
      factionId: p.factionId,
      hasPosted: Boolean(p.hasPosted),
      postedAt: p.postedAt || null,
      faction: await fetchFactionShort(db, p.factionId),
    }))
  )
  return parts
}

async function fetchBattlePosts(db: ReturnType<typeof getAdminDb>, battleId: string) {
  const snap = await db
    .collection(COLLECTIONS.posts)
    .where('battleId', '==', battleId)
    .get()
  const postsRaw = snap.docs.map(docToApi)
  postsRaw.sort((a: any, b: any) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })
  const posts = await Promise.all(
    postsRaw.map(async (p: any) => ({
      id: p.id,
      title: p.title,
      content: p.content,
      status: p.status,
      battleId: p.battleId,
      authorId: p.authorId,
      factionId: p.factionId,
      createdAt: p.createdAt || null,
      author: await fetchUserShort(db, p.authorId),
      faction: await fetchFactionShort(db, p.factionId),
    }))
  )
  return posts
}

// GET /api/battles/[id]
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(req)
  const { id } = await params
  const db = getAdminDb()

  const battleSnap = await db.collection(COLLECTIONS.battles).doc(id).get()
  if (!battleSnap.exists) return errorResponse('Баталия не найдена', 404)

  const battle: any = docToApi(battleSnap as any)

  // Игрок видит только если его фракция участвует
  if (ctx.role !== 'ADMIN') {
    const participants = await fetchBattleParticipants(db, id)
    const isParticipant = participants.some((p) => p.factionId === ctx.factionId)
    if (!isParticipant) return errorResponse('Доступ запрещён', 403)
    battle.forces = await fetchBattleForces(db, id)
    battle.participants = participants
    battle.posts = await fetchBattlePosts(db, id)
    return jsonResponse({ battle })
  }

  const [forces, participants, posts] = await Promise.all([
    fetchBattleForces(db, id),
    fetchBattleParticipants(db, id),
    fetchBattlePosts(db, id),
  ])
  battle.forces = forces
  battle.participants = participants
  battle.posts = posts

  return jsonResponse({ battle })
}

// PUT /api/battles/[id]
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const body = await req.json()
  const { name, description, location, turnNumber, status, postDeadline, forces, participants } =
    body as Record<string, unknown>

  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  if (name) updateData.name = String(name)
  if (description !== undefined) updateData.description = description as string | null
  if (location !== undefined) updateData.location = location as string | null
  if (turnNumber !== undefined) updateData.turnNumber = Number(turnNumber)
  if (status) updateData.status = String(status)
  if (postDeadline) updateData.postDeadline = new Date(String(postDeadline))

  await db.collection(COLLECTIONS.battles).doc(id).update(updateData)

  // Обновление сил фракций: удаляем старые + создаём новые
  if (Array.isArray(forces)) {
    const oldForcesSnap = await db
      .collection(COLLECTIONS.battleForces)
      .where('battleId', '==', id)
      .get()
    const batch = db.batch()
    oldForcesSnap.docs.forEach((d) => batch.delete(d.ref))
    await batch.commit()
    for (const f of forces as any[]) {
      if (f.factionId) {
        const forceId = randomUUID()
        await db.collection(COLLECTIONS.battleForces).doc(forceId).set({
          battleId: id,
          factionId: f.factionId,
          commander: f.commander || '',
          infantry: Number(f.infantry) || 0,
          archers: Number(f.archers) || 0,
          cavalry: Number(f.cavalry) || 0,
          fleet: Number(f.fleet) || 0,
          special: f.special || null,
          description: f.description || null,
        })
      }
    }
  }

  // Обновление участников
  if (Array.isArray(participants)) {
    const oldPartsSnap = await db
      .collection(COLLECTIONS.battleParticipants)
      .where('battleId', '==', id)
      .get()
    const batch = db.batch()
    oldPartsSnap.docs.forEach((d) => batch.delete(d.ref))
    await batch.commit()
    for (const factionId of participants as string[]) {
      const partId = `${id}_${factionId}`
      await db
        .collection(COLLECTIONS.battleParticipants)
        .doc(partId)
        .set({
          battleId: id,
          factionId,
          hasPosted: false,
          postedAt: null,
        })
    }
  }

  // Загружаем обновлённую баталию
  const updatedSnap = await db.collection(COLLECTIONS.battles).doc(id).get()
  const updated: any = docToApi(updatedSnap as any)
  updated.forces = await fetchBattleForces(db, id)
  updated.participants = await fetchBattleParticipants(db, id)

  return jsonResponse({ battle: updated })
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()

  // Каскадное удаление сил и участников
  const [forcesSnap, partsSnap] = await Promise.all([
    db.collection(COLLECTIONS.battleForces).where('battleId', '==', id).get(),
    db.collection(COLLECTIONS.battleParticipants).where('battleId', '==', id).get(),
  ])
  const batch = db.batch()
  forcesSnap.docs.forEach((d) => batch.delete(d.ref))
  partsSnap.docs.forEach((d) => batch.delete(d.ref))
  batch.delete(db.collection(COLLECTIONS.battles).doc(id))
  await batch.commit()

  return jsonResponse({ success: true })
}
