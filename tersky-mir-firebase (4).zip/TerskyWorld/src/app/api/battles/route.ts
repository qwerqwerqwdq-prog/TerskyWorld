import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import {
  requireAuth,
  requireAdmin,
  jsonResponse,
  errorResponse,
  isBotRequest,
} from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'
import { z } from 'zod'
import { randomUUID } from 'crypto'

const battleSchema = z.object({
  name: z.string().min(3).max(200),
  description: z.string().optional(),
  location: z.string().optional(),
  turnNumber: z.number().int().optional(),
  postDeadline: z.string().optional(),
})

// Загружаем фракцию (краткий формат)
async function fetchFactionShort(db: ReturnType<typeof getAdminDb>, factionId: string) {
  if (!factionId) return null
  const snap = await db.collection(COLLECTIONS.factions).doc(factionId).get()
  if (!snap.exists) return null
  const data = snap.data()!
  return {
    id: snap.id,
    name: data.name,
    shortName: data.shortName || null,
  }
}

// Загружаем силы фракций в бою
async function fetchBattleForces(db: ReturnType<typeof getAdminDb>, battleId: string) {
  const snap = await db
    .collection(COLLECTIONS.battleForces)
    .where('battleId', '==', battleId)
    .get()
  const forcesRaw = snap.docs.map(docToApi)
  const forces = await Promise.all(
    forcesRaw.map(async (f: any) => ({
      id: f.id,
      battleId: f.battleId,
      factionId: f.factionId,
      commander: f.commander || '',
      infantry: Number(f.infantry) || 0,
      archers: Number(f.archers) || 0,
      cavalry: Number(f.cavalry) || 0,
      fleet: Number(f.fleet) || 0,
      special: f.special || null,
      description: f.description || null,
      faction: await fetchFactionShort(db, f.factionId),
    }))
  )
  return forces
}

// Загружаем участников боя (фракции)
async function fetchBattleParticipants(db: ReturnType<typeof getAdminDb>, battleId: string) {
  const snap = await db
    .collection(COLLECTIONS.battleParticipants)
    .where('battleId', '==', battleId)
    .get()
  const partsRaw = snap.docs.map(docToApi)
  const parts = await Promise.all(
    partsRaw.map(async (p: any) => ({
      id: p.id,
      battleId: p.battleId,
      factionId: p.factionId,
      hasPosted: Boolean(p.hasPosted),
      postedAt: p.postedAt || null,
      faction: await fetchFactionShort(db, p.factionId),
    }))
  )
  return parts
}

// Загружаем список баталий с include
async function fetchBattlesList(db: ReturnType<typeof getAdminDb>, includePostCount = false) {
  const snap = await db.collection(COLLECTIONS.battles).get()
  const battlesRaw = snap.docs.map(docToApi)
  battlesRaw.sort((a: any, b: any) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })
  const battles = await Promise.all(
    battlesRaw.map(async (b: any) => {
      const [forces, participants] = await Promise.all([
        fetchBattleForces(db, b.id),
        fetchBattleParticipants(db, b.id),
      ])
      const out: any = { ...b, forces, participants }
      if (includePostCount) {
        const postCountSnap = await db
          .collection(COLLECTIONS.posts)
          .where('battleId', '==', b.id)
          .count()
          .get()
        out._count = { posts: postCountSnap.data().count }
      }
      return out
    })
  )
  return battles
}

// GET /api/battles — список баталий
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const db = getAdminDb()
  let battles

  if (ctx.role === 'ADMIN') {
    battles = await fetchBattlesList(db, true)
  } else {
    // Игрок видит баталии, где его фракция участвует
    const partSnap = await db
      .collection(COLLECTIONS.battleParticipants)
      .where('factionId', '==', ctx.factionId || 'none')
      .get()
    const battleIds = Array.from(
      new Set(partSnap.docs.map((d) => d.get('battleId') as string))
    )
    if (battleIds.length === 0) {
      return jsonResponse({ battles: [] })
    }
    const battleSnaps = await Promise.all(
      battleIds.map((id) => db.collection(COLLECTIONS.battles).doc(id).get())
    )
    const battlesRaw = battleSnaps
      .filter((s) => s.exists)
      .map((s) => docToApi(s as any))
    battlesRaw.sort((a: any, b: any) => {
      const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
      const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
      return bT - aT
    })
    battles = await Promise.all(
      battlesRaw.map(async (b: any) => {
        const [forces, participants] = await Promise.all([
          fetchBattleForces(db, b.id),
          fetchBattleParticipants(db, b.id),
        ])
        return { ...b, forces, participants }
      })
    )
  }

  return jsonResponse({ battles })
}

// POST /api/battles — создание баталии (только админ)
export async function POST(req: NextRequest) {
  if (isBotRequest(req)) return errorResponse('Доступ запрещён', 403)
  const ctx = await requireAdmin(req)
  const db = getAdminDb()

  const body = await req.json()
  const parsed = battleSchema.safeParse(body)
  if (!parsed.success)
    return errorResponse(
      parsed.error.issues[0]?.message || 'Некорректные данные',
      422
    )

  const { postDeadline, ...data } = parsed.data
  const battleId = randomUUID()
  const now = FieldValue.serverTimestamp()

  const battleDoc: Record<string, unknown> = {
    name: data.name,
    description: data.description || null,
    location: data.location || null,
    turnNumber: data.turnNumber ?? null,
    status: 'PREPARING',
    postDeadline:
      postDeadline ? new Date(postDeadline) : null,
    createdAt: now,
    updatedAt: now,
  }

  await db.collection(COLLECTIONS.battles).doc(battleId).set(battleDoc)

  // Активность
  await db.collection(COLLECTIONS.activity).add({
    type: 'BATTLE_STARTED',
    userId: ctx.userId,
    targetId: battleId,
    data: { name: data.name, location: data.location || null },
    createdAt: now,
  })

  const battleSnap = await db.collection(COLLECTIONS.battles).doc(battleId).get()
  const battle: any = docToApi(battleSnap as any)
  battle.forces = []
  battle.participants = []

  return jsonResponse({ battle, message: 'Баталия создана' })
}
