import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, toApiDate } from '@/lib/firestore'

export async function GET(req: NextRequest) {
  // getAuthContext уже верифицировал токен — просто загружаем профиль по uid
  const authHeader = req.headers.get('authorization') || ''
  if (!authHeader.startsWith('Bearer ')) {
    return jsonResponse({ user: null })
  }

  // Извлекаем uid из verifyIdToken (через общий helper)
  const ctx = await import('@/lib/server-auth').then((m) => m.getAuthContext(req))
  if (!ctx) {
    return jsonResponse({ user: null })
  }

  const db = getAdminDb()
  const userSnap = await db.collection(COLLECTIONS.users).doc(ctx.userId).get()
  if (!userSnap.exists) {
    return jsonResponse({ user: null })
  }

  const data = userSnap.data()!
  let faction = null
  if (data.factionId) {
    const fSnap = await db.collection(COLLECTIONS.factions).doc(data.factionId).get()
    if (fSnap.exists) {
      const f = fSnap.data()!
      faction = {
        id: fSnap.id,
        name: f.name,
        shortName: f.shortName || null,
        isApproved: Boolean(f.isApproved),
      }
    }
  }

  return jsonResponse({
    user: {
      id: userSnap.id,
      name: data.name,
      email: data.email,
      role: data.role || 'PLAYER',
      avatar: data.avatar || null,
      bio: data.bio || null,
      faction,
    },
  })
}
