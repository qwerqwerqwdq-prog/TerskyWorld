import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'

interface UserStats {
  id: string
  name: string
  avatar?: string | null
  createdAt: string | null
  role?: string
  faction?: {
    id: string
    name: string
    shortName?: string | null
    bannerColor?: string | null
    isApproved: boolean
  } | null
  _count: {
    posts: number
    chatMessages: number
    verdicts: number
    chronicle: number
    bestiary: number
    bookmarks: number
  }
}

function computeScore(u: UserStats) {
  // Веса для каждой активности
  const postsScore = u._count.posts * 10
  const messagesScore = u._count.chatMessages * 2
  const verdictsScore = u._count.verdicts * 15
  const chronicleScore = u._count.chronicle * 8
  const bestiaryScore = u._count.bestiary * 8
  const bookmarksScore = u._count.bookmarks * 1

  const totalScore =
    postsScore + messagesScore + verdictsScore + chronicleScore + bestiaryScore + bookmarksScore

  const createdMs = u.createdAt ? new Date(u.createdAt).getTime() : Date.now()
  const daysSince = Math.floor((Date.now() - createdMs) / (1000 * 60 * 60 * 24))
  const veteranScore = Math.min(daysSince, 90)

  const score = totalScore + veteranScore

  let level = 'Новичок'
  let levelColor = 'text-slate-400'
  if (score >= 500) {
    level = 'Легенда'
    levelColor = 'text-amber-300'
  } else if (score >= 200) {
    level = 'Мастер'
    levelColor = 'text-purple-300'
  } else if (score >= 50) {
    level = 'Опытный'
    levelColor = 'text-accent'
  }

  return {
    id: u.id,
    name: u.name,
    avatar: u.avatar,
    role: u.role,
    faction: u.faction,
    score,
    level,
    levelColor,
    stats: {
      posts: u._count.posts,
      messages: u._count.chatMessages,
      verdicts: u._count.verdicts,
      chronicle: u._count.chronicle,
      bestiary: u._count.bestiary,
      bookmarks: u._count.bookmarks,
    },
    breakdown: {
      posts: postsScore,
      messages: messagesScore,
      verdicts: verdictsScore,
      chronicle: chronicleScore,
      bestiary: bestiaryScore,
      bookmarks: bookmarksScore,
      veteran: veteranScore,
    },
    daysSince,
  }
}

// GET /api/leaderboard — рейтинг игроков по достижениям и активности
// Query params: period = "week" | "month" | "all" (default: all)
export async function GET(req: NextRequest) {
  const ctx = await requireAuth(req)
  const period = req.nextUrl.searchParams.get('period') || 'all'
  const db = getAdminDb()

  // Определяем период для трендов
  let periodMs = 7 * 24 * 60 * 60 * 1000 // week by default
  if (period === 'month') periodMs = 30 * 24 * 60 * 60 * 1000
  if (period === 'all') periodMs = 365 * 24 * 60 * 60 * 1000 // 1 year for "all"

  // Получаем всех пользователей
  const usersSnap = await db.collection(COLLECTIONS.users).get()
  const usersRaw = usersSnap.docs.map(docToApi) as any[]

  // Сортировка по createdAt asc (как в оригинале)
  usersRaw.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return aT - bT
  })

  // Параллельно считаем счётчики для каждого пользователя
  const userStats: UserStats[] = await Promise.all(
    usersRaw.map(async (u: any) => {
      let faction: UserStats['faction'] = null
      if (u.factionId) {
        const fSnap = await db.collection(COLLECTIONS.factions).doc(u.factionId).get()
        if (fSnap.exists) {
          const f = fSnap.data()!
          faction = {
            id: fSnap.id,
            name: f.name,
            shortName: f.shortName || null,
            bannerColor: f.bannerColor || null,
            isApproved: Boolean(f.isApproved),
          }
        }
      }

      const [posts, chatMessages, verdicts, chronicle, bestiary, bookmarks] = await Promise.all([
        db.collection(COLLECTIONS.posts).where('authorId', '==', u.id).count().get(),
        db.collection(COLLECTIONS.chatMessages).where('userId', '==', u.id).count().get(),
        db.collection(COLLECTIONS.verdicts).where('adminId', '==', u.id).count().get(),
        db.collection(COLLECTIONS.chronicle).where('authorId', '==', u.id).count().get(),
        db.collection(COLLECTIONS.bestiary).where('authorId', '==', u.id).count().get(),
        db.collection(COLLECTIONS.bookmarks).where('userId', '==', u.id).count().get(),
      ])

      return {
        id: u.id,
        name: u.name,
        avatar: u.avatar || null,
        createdAt: u.createdAt || null,
        role: u.role || 'PLAYER',
        faction,
        _count: {
          posts: posts.data().count,
          chatMessages: chatMessages.data().count,
          verdicts: verdicts.data().count,
          chronicle: chronicle.data().count,
          bestiary: bestiary.data().count,
          bookmarks: bookmarks.data().count,
        },
      }
    })
  )

  // Вычисляем score для каждого пользователя
  const ranked = userStats.map((u) => computeScore(u))
  ranked.sort((a, b) => b.score - a.score)

  // Добавляем rank
  const leaderboard = ranked.map((u, i) => ({ ...u, rank: i + 1 }))

  // Получаем снимки рангов за выбранный период
  const periodAgo = new Date(Date.now() - periodMs)
  const recentSnapshotsSnap = await db
    .collection(COLLECTIONS.rankSnapshots)
    .where('createdAt', '>=', periodAgo)
    .get()
  const recentSnapshots = recentSnapshotsSnap.docs.map(docToApi) as any[]

  // Сортируем по createdAt asc — самый старый снимок в начале
  recentSnapshots.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return aT - bT
  })

  // Для каждого user берём самый старый снимок за период
  const oldestSnapshotByUser = new Map<string, { rank: number; score: number }>()
  for (const snap of recentSnapshots) {
    if (!oldestSnapshotByUser.has(snap.userId)) {
      oldestSnapshotByUser.set(snap.userId, { rank: snap.rank, score: snap.score })
    }
  }

  // Добавляем trend (изменение ранга)
  const leaderboardWithTrend = leaderboard.map((u) => {
    const oldSnapshot = oldestSnapshotByUser.get(u.id)
    let trend: 'up' | 'down' | 'same' | 'new' = 'new'
    let rankChange = 0
    if (oldSnapshot) {
      rankChange = oldSnapshot.rank - u.rank // positive = improved (moved up)
      if (rankChange > 0) trend = 'up'
      else if (rankChange < 0) trend = 'down'
      else trend = 'same'
    }
    return {
      ...u,
      trend,
      rankChange,
      previousRank: oldSnapshot?.rank || null,
    }
  })

  // Сохраняем текущие ранги как snapshot (раз в час)
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000)
  const recentSnapshotCountSnap = await db
    .collection(COLLECTIONS.rankSnapshots)
    .where('createdAt', '>=', oneHourAgo)
    .count()
    .get()
  const recentSnapshotCount = recentSnapshotCountSnap.data().count

  if (recentSnapshotCount === 0) {
    // Создаём снимки для всех пользователей (batch)
    try {
      const batch = db.batch()
      const now = FieldValue.serverTimestamp()
      leaderboardWithTrend.forEach((u) => {
        const ref = db.collection(COLLECTIONS.rankSnapshots).doc()
        batch.set(ref, {
          userId: u.id,
          rank: u.rank,
          score: u.score,
          createdAt: now,
        })
      })
      await batch.commit()
    } catch (e) {
      // ignore — snapshots are not critical
      console.error('[leaderboard] snapshot save failed:', e)
    }
  }

  return jsonResponse({ leaderboard: leaderboardWithTrend })
}
