import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

// GET /api/factions/[id] — детали фракции (владелец или админ)
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(_req)
  const { id } = await params

  const db = getAdminDb()
  const factionSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
  if (!factionSnap.exists) return errorResponse('Фракция не найдена', 404)

  const faction = docToApi(factionSnap as any) as any

  // Доступ: владелец или админ
  if (faction.userId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  // Include user (with email) and stats ordered
  const [userSnap, statsSnap] = await Promise.all([
    faction.userId ? db.collection(COLLECTIONS.users).doc(faction.userId).get() : Promise.resolve(null),
    // composite index required: (factionId, order)
    db.collection(COLLECTIONS.factionStats).where('factionId', '==', id).orderBy('order', 'asc').get(),
  ])

  if (userSnap && userSnap.exists) {
    const uData = userSnap.data() as any
    faction.user = { id: userSnap.id, name: uData.name, email: uData.email }
  } else {
    faction.user = null
  }

  faction.stats = statsSnap.docs.map((d) => docToApi(d as any))

  return jsonResponse({ faction })
}

// PUT /api/factions/[id] — обновление основной информации фракции
const updateFactionSchema = z.object({
  name: z.string().min(3).max(100).optional(),
  shortName: z.string().max(20).optional(),
  motto: z.string().max(200).optional(),
  description: z.string().max(2000).optional(),
  bannerColor: z.string().max(20).optional(),
  emblemUrl: z.string().optional(),
  isApproved: z.boolean().optional(),
})

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(req)
  const { id } = await params

  const db = getAdminDb()
  const factionSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
  if (!factionSnap.exists) return errorResponse('Фракция не найдена', 404)
  const factionData = factionSnap.data() as any

  // Редактировать может владелец (только если не утверждена) или админ
  if (factionData.userId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }
  if (factionData.userId === ctx.userId && factionData.isApproved && ctx.role !== 'ADMIN') {
    return errorResponse('Утверждённое княжество может редактировать только администратор', 403)
  }

  const body = await req.json()
  const parsed = updateFactionSchema.safeParse(body)
  if (!parsed.success) return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)

  // Удаляем undefined значения, чтобы не затереть их в Firestore
  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  for (const [k, v] of Object.entries(parsed.data)) {
    if (v !== undefined) updateData[k] = v
  }

  await db.collection(COLLECTIONS.factions).doc(id).set(updateData, { merge: true })

  const updatedSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
  const updated = docToApi(updatedSnap as any)

  return jsonResponse({ faction: updated })
}

// DELETE /api/factions/[id] — удаление (только админ)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(_req)
  const { id } = await params

  const db = getAdminDb()
  // Cascade: удаляем stat sections, обнуляем factionId у пользователя
  const batch = db.batch()
  batch.delete(db.collection(COLLECTIONS.factions).doc(id))

  const statsSnap = await db.collection(COLLECTIONS.factionStats).where('factionId', '==', id).get()
  statsSnap.forEach((d) => batch.delete(d.ref))

  // Posts with this factionId — set factionId = null (SetNull behavior)
  const postsSnap = await db.collection(COLLECTIONS.posts).where('factionId', '==', id).get()
  postsSnap.forEach((d) => batch.set(d.ref, { factionId: null }, { merge: true }))

  await batch.commit()

  // Удаляем factionId у пользователя
  const userSnap = await db.collection(COLLECTIONS.users).where('factionId', '==', id).limit(1).get()
  if (!userSnap.empty) {
    await userSnap.docs[0].ref.set({ factionId: null }, { merge: true })
  }

  return jsonResponse({ success: true })
}
