import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, requireAdmin, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

function safeParse(s: string | null | undefined): unknown {
  if (!s) return null
  try { return JSON.parse(s) } catch { return s }
}

// GET /api/factions/[id]/stats — все секции статистики
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(_req)
  const { id } = await params

  const db = getAdminDb()
  const factionSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
  if (!factionSnap.exists) return errorResponse('Фракция не найдена', 404)
  const factionData = factionSnap.data() as any

  if (factionData.userId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  // composite index required: (factionId, order)
  const statsSnap = await db.collection(COLLECTIONS.factionStats)
    .where('factionId', '==', id)
    .orderBy('order', 'asc')
    .get()

  const stats = statsSnap.docs.map((s) => {
    const d = docToApi(s as any) as any
    return { ...d, content: safeParse(d.content) }
  })

  return jsonResponse({ stats })
}

// PUT /api/factions/[id]/stats — обновление/создание секции (только админ)
const updateStatSchema = z.object({
  sectionKey: z.string(),
  sectionTitle: z.string().optional(),
  content: z.unknown(), // JSON содержимое
})

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req)
  const { id } = await params

  const db = getAdminDb()
  const body = await req.json()
  const parsed = updateStatSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  const { sectionKey, sectionTitle, content } = parsed.data
  const statId = `${id}_${sectionKey}`
  const statRef = db.collection(COLLECTIONS.factionStats).doc(statId)
  const existingSnap = await statRef.get()
  const existedBefore = existingSnap.exists

  const statData: Record<string, unknown> = {
    factionId: id,
    sectionKey,
    sectionTitle: sectionTitle || sectionKey,
    content: JSON.stringify(content),
    updatedAt: FieldValue.serverTimestamp(),
  }
  if (!existedBefore) {
    statData.order = 0
  }
  await statRef.set(statData, { merge: true })

  // Лог изменения
  await db.collection(COLLECTIONS.statChangeLogs).add({
    factionId: id,
    verdictId: null,
    sectionKey,
    changeType: 'UPDATE',
    oldValue: existedBefore ? (existingSnap.data() as any).content : null,
    newValue: JSON.stringify(content),
    adminId: ctx.userId,
    createdAt: FieldValue.serverTimestamp(),
  })

  const updatedSnap = await statRef.get()
  const stat = docToApi(updatedSnap as any) as any

  return jsonResponse({ stat: { ...stat, content: safeParse(stat.content) } })
}

// DELETE /api/factions/[id]/stats?sectionKey=... — удаление секции (только админ)
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const sectionKey = req.nextUrl.searchParams.get('sectionKey')

  if (sectionKey) {
    await db.collection(COLLECTIONS.factionStats).doc(`${id}_${sectionKey}`).delete()
  }

  return jsonResponse({ success: true })
}
