import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'

function safeParse(s: string | null | undefined): unknown {
  if (!s) return null
  try { return JSON.parse(s) } catch { return s }
}

// GET /api/factions/[id]/changes — лента изменений статов фракции (для timeline)
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAuth(_req)
  const { id } = await params

  const db = getAdminDb()
  const factionSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
  if (!factionSnap.exists) return errorResponse('Фракция не найдена', 404)
  const factionData = factionSnap.data() as any

  if (factionData.userId !== ctx.userId && ctx.role !== 'ADMIN') {
    return errorResponse('Доступ запрещён', 403)
  }

  // composite index required: (factionId, createdAt)
  const changesSnap = await db.collection(COLLECTIONS.statChangeLogs)
    .where('factionId', '==', id)
    .orderBy('createdAt', 'desc')
    .limit(30)
    .get()

  const changes = changesSnap.docs.map((d) => docToApi(d as any)) as any[]

  // Includes: verdict (with post + admin), admin
  const verdictIds = [...new Set(changes.map((c) => c.verdictId).filter(Boolean))]
  const adminIds = [...new Set(changes.map((c) => c.adminId).filter(Boolean))]

  const [verdictSnaps, adminSnaps] = await Promise.all([
    Promise.all(verdictIds.map((vid) => db.collection(COLLECTIONS.verdicts).doc(vid!).get())),
    Promise.all(adminIds.map((aid) => db.collection(COLLECTIONS.users).doc(aid!).get())),
  ])

  const verdictMap = new Map<string, any>()
  const postIdsForVerdicts: string[] = []
  verdictSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      verdictMap.set(s.id, { ...docToApi(s as any) })
      if (data.postId) postIdsForVerdicts.push(data.postId)
    }
  })

  const postSnaps = await Promise.all(
    [...new Set(postIdsForVerdicts)].map((pid) => db.collection(COLLECTIONS.posts).doc(pid).get())
  )
  const postMap = new Map<string, any>()
  postSnaps.forEach((s) => {
    if (s.exists) postMap.set(s.id, { id: s.id, title: (s.data() as any).title })
  })

  // For verdict.admin we need to fetch admins for each verdict
  const verdictAdminIds: string[] = []
  verdictSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      if (data.adminId) verdictAdminIds.push(data.adminId)
    }
  })
  const verdictAdminSnaps = await Promise.all(
    [...new Set(verdictAdminIds)].map((aid) => db.collection(COLLECTIONS.users).doc(aid).get())
  )
  const verdictAdminMap = new Map<string, any>()
  verdictAdminSnaps.forEach((s) => {
    if (s.exists) verdictAdminMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  const adminMap = new Map<string, any>()
  adminSnaps.forEach((s) => {
    if (s.exists) adminMap.set(s.id, { id: s.id, name: (s.data() as any).name })
  })

  const changesWithIncludes = changes.map((c) => {
    const v = c.verdictId ? verdictMap.get(c.verdictId) : null
    let verdictWithIncludes = null
    if (v) {
      const vData = verdictSnaps.find((s) => s.id === c.verdictId)?.data() as any
      verdictWithIncludes = {
        ...v,
        post: vData?.postId ? postMap.get(vData.postId) || null : null,
        admin: vData?.adminId ? verdictAdminMap.get(vData.adminId) || null : null,
      }
    }
    return {
      ...c,
      oldValue: safeParse(c.oldValue),
      newValue: safeParse(c.newValue),
      admin: c.adminId ? adminMap.get(c.adminId) || null : null,
      verdict: verdictWithIncludes,
    }
  })

  return jsonResponse({ changes: changesWithIncludes })
}
