import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAuth, jsonResponse, errorResponse, isBotRequest } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'
import { STAT_SECTIONS } from '@/lib/constants'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

const factionSchema = z.object({
  name: z.string().min(3, 'Название минимум 3 символа').max(100),
  shortName: z.string().max(20).optional(),
  motto: z.string().max(200).optional(),
  description: z.string().max(2000).optional(),
  bannerColor: z.string().max(20).optional(),
})

// GET /api/factions — список фракций (для админа — все, для игрока — только своя)
export async function GET() {
  const ctx = await requireAuth()
  const db = getAdminDb()

  let snaps: FirebaseFirestore.QuerySnapshot
  if (ctx.role === 'ADMIN') {
    // composite index required: (createdAt)
    snaps = await db.collection(COLLECTIONS.factions).orderBy('createdAt', 'desc').get()
  } else {
    snaps = await db.collection(COLLECTIONS.factions).where('userId', '==', ctx.userId).get()
  }

  const factions = snaps.docs.map((d) => docToApi(d as any)) as any[]

  // Include user
  const userIds = [...new Set(factions.map((f) => f.userId).filter(Boolean))]
  const userSnaps = await Promise.all(userIds.map((id) => db.collection(COLLECTIONS.users).doc(id).get()))
  const userMap = new Map<string, any>()
  userSnaps.forEach((s) => {
    if (s.exists) {
      const data = s.data() as any
      userMap.set(s.id, { id: s.id, name: data.name, email: data.email })
    }
  })

  factions.forEach((f) => {
    f.user = f.userId ? userMap.get(f.userId) || null : null
  })

  return jsonResponse({ factions })
}

// POST /api/factions — создание фракции (игрок регистрирует княжество)
export async function POST(req: NextRequest) {
  if (isBotRequest(req)) return errorResponse('Доступ запрещён', 403)

  const ctx = await requireAuth(req)
  try {
    const body = await req.json()
    const parsed = factionSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)
    }

    const db = getAdminDb()
    // Игрок может иметь только одну фракцию
    const existingSnap = await db.collection(COLLECTIONS.factions).where('userId', '==', ctx.userId).limit(1).get()
    if (!existingSnap.empty) {
      return errorResponse('У вас уже есть княжество', 409)
    }

    const data = parsed.data
    const id = crypto.randomUUID()
    const factionData: Record<string, unknown> = {
      name: data.name,
      shortName: data.shortName ?? null,
      motto: data.motto ?? null,
      description: data.description ?? null,
      bannerColor: data.bannerColor ?? null,
      emblemUrl: null,
      isApproved: false,
      userId: ctx.userId,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }

    // Используем batch для создания фракции + 8 секций статистики
    const batch = db.batch()
    batch.set(db.collection(COLLECTIONS.factions).doc(id), factionData)

    STAT_SECTIONS.forEach((s, i) => {
      const statId = `${id}_${s.key}`
      batch.set(db.collection(COLLECTIONS.factionStats).doc(statId), {
        factionId: id,
        sectionKey: s.key,
        sectionTitle: s.title,
        content: JSON.stringify(s.defaultContent),
        order: i,
        updatedAt: FieldValue.serverTimestamp(),
      })
    })

    await batch.commit()

    const factionSnap = await db.collection(COLLECTIONS.factions).doc(id).get()
    const faction = docToApi(factionSnap as any)

    return jsonResponse({ faction, message: 'Княжество зарегистрировано и ожидает утверждения администратором' })
  } catch (e) {
    console.error('Create faction error:', e)
    return errorResponse('Ошибка создания фракции', 500)
  }
}
