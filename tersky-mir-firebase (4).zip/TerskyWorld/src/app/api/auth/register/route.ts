import { NextRequest } from 'next/server'
import { getAdminAuth } from '@/lib/firebase-admin'
import { getAdminDb } from '@/lib/firebase-admin'
import { jsonResponse, errorResponse, isBotRequest } from '@/lib/server-auth'
import { COLLECTIONS } from '@/lib/firestore'
import { FieldValue } from 'firebase-admin/firestore'
import { z } from 'zod'

const registerSchema = z.object({
  uid: z.string().min(20, 'UID обязателен (создаётся Firebase Auth)'),
  name: z.string().min(2, 'Имя слишком короткое').max(50),
  email: z.string().email('Некорректный email'),
})

export async function POST(req: NextRequest) {
  if (isBotRequest(req)) {
    return errorResponse('Доступ запрещён', 403)
  }

  try {
    const body = await req.json()
    const parsed = registerSchema.safeParse(body)
    if (!parsed.success) {
      return errorResponse(parsed.error.issues[0]?.message || 'Некорректные данные', 422)
    }

    const { uid, name, email } = parsed.data
    const normalizedEmail = email.toLowerCase()
    const db = getAdminDb()

    // Проверяем что Firebase-пользователь реально существует
    try {
      await getAdminAuth().getUser(uid)
    } catch {
      return errorResponse('Firebase-пользователь не найден', 404)
    }

    // Проверяем, что email ещё не занят (Firestore unique-через query)
    const existingByEmail = await db.collection(COLLECTIONS.users).where('email', '==', normalizedEmail).limit(1).get()
    if (!existingByEmail.empty) {
      return errorResponse('Пользователь с таким email уже существует', 409)
    }

    // Считаем существующих пользователей — первый = админ
    const usersSnap = await db.collection(COLLECTIONS.users).count().get()
    const userCount = usersSnap.data().count
    const role = userCount === 0 ? 'ADMIN' : 'PLAYER'

    const userDoc = {
      name,
      email: normalizedEmail,
      role,
      avatar: null,
      bio: null,
      isBanned: false,
      bannedAt: null,
      bannedReason: null,
      bannedBy: null,
      factionId: null,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      lastLoginAt: FieldValue.serverTimestamp(),
    }

    await db.collection(COLLECTIONS.users).doc(uid).set(userDoc)

    // Запись в активность
    await db.collection(COLLECTIONS.activity).add({
      type: 'USER_REGISTERED',
      userId: uid,
      targetId: uid,
      data: { name, role },
      createdAt: FieldValue.serverTimestamp(),
    })

    return jsonResponse({
      user: { id: uid, name, email: normalizedEmail, role },
      message: role === 'ADMIN' ? 'Аккаунт администратора создан' : 'Аккаунт создан',
    })
  } catch (e) {
    console.error('Register error:', e)
    return errorResponse('Ошибка регистрации', 500)
  }
}
