import { NextRequest } from 'next/server'
import { getAdminDb } from '@/lib/firebase-admin'
import { requireAdmin, jsonResponse } from '@/lib/server-auth'
import { COLLECTIONS, docToApi } from '@/lib/firestore'

// GET /api/admin/users — список всех пользователей (только админ)
export async function GET(req: NextRequest) {
  await requireAdmin(req)
  const search = req.nextUrl.searchParams.get('search')?.toLowerCase() || ''
  const db = getAdminDb()

  const snap = await db.collection(COLLECTIONS.users).get()
  let users = snap.docs.map(docToApi) as any[]

  // Фильтр по поиску (имя/email) — Prisma использует contains, мы делаем это в памяти
  if (search) {
    users = users.filter(
      (u) =>
        (typeof u.name === 'string' && u.name.toLowerCase().includes(search)) ||
        (typeof u.email === 'string' && u.email.toLowerCase().includes(search))
    )
  }

  // Сортировка по createdAt desc
  users.sort((a, b) => {
    const aT = a.createdAt ? new Date(a.createdAt).getTime() : 0
    const bT = b.createdAt ? new Date(b.createdAt).getTime() : 0
    return bT - aT
  })

  // Параллельно загружаем фракцию и счётчик постов
  const enriched = await Promise.all(
    users.map(async (u) => {
      let faction: { id: string; name: string; isApproved: boolean } | null = null
      if (u.factionId) {
        const fSnap = await db.collection(COLLECTIONS.factions).doc(u.factionId).get()
        if (fSnap.exists) {
          const f = fSnap.data()!
          faction = {
            id: fSnap.id,
            name: f.name,
            isApproved: Boolean(f.isApproved),
          }
        }
      }
      const postCountSnap = await db
        .collection(COLLECTIONS.posts)
        .where('authorId', '==', u.id)
        .count()
        .get()
      return {
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role || 'PLAYER',
        avatar: u.avatar || null,
        isBanned: Boolean(u.isBanned),
        bannedAt: u.bannedAt || null,
        bannedReason: u.bannedReason || null,
        createdAt: u.createdAt || null,
        lastLoginAt: u.lastLoginAt || null,
        faction,
        _count: { posts: postCountSnap.data().count },
      }
    })
  )

  return jsonResponse({ users: enriched })
}
