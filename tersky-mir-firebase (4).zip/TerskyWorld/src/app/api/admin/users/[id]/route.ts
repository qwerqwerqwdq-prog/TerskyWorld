import { NextRequest } from 'next/server'
import { getAdminDb, getAdminAuth } from '@/lib/firebase-admin'
import {
  requireAdmin,
  jsonResponse,
  errorResponse,
} from '@/lib/server-auth'
import { COLLECTIONS, docToApi, FieldValue } from '@/lib/firestore'
import { z } from 'zod'

// GET /api/admin/users/[id] — детали пользователя
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()

  const userSnap = await db.collection(COLLECTIONS.users).doc(id).get()
  if (!userSnap.exists) return errorResponse('Пользователь не найден', 404)
  const data: any = userSnap.data()

  let faction: {
    id: string
    name: string
    shortName: string | null
    isApproved: boolean
    createdAt: string | null
  } | null = null
  if (data.factionId) {
    const fSnap = await db.collection(COLLECTIONS.factions).doc(data.factionId).get()
    if (fSnap.exists) {
      const f = fSnap.data()!
      faction = {
        id: fSnap.id,
        name: f.name,
        shortName: f.shortName || null,
        isApproved: Boolean(f.isApproved),
        createdAt: null,
      }
      // Приводим createdAt фракции к ISO
      if (f.createdAt) {
        try {
          if (typeof f.createdAt === 'object' && '_seconds' in f.createdAt) {
            faction.createdAt = new Date(
              (f.createdAt as any)._seconds * 1000 +
                ((f.createdAt as any)._nanoseconds || 0) / 1e6
            ).toISOString()
          } else if (f.createdAt instanceof Date) {
            faction.createdAt = (f.createdAt as Date).toISOString()
          } else if (typeof f.createdAt === 'string') {
            faction.createdAt = f.createdAt
          }
        } catch {
          faction.createdAt = null
        }
      }
    }
  }

  const [postCountSnap, msgCountSnap] = await Promise.all([
    db.collection(COLLECTIONS.posts).where('authorId', '==', id).count().get(),
    db.collection(COLLECTIONS.chatMessages).where('userId', '==', id).count().get(),
  ])

  const user = {
    id: userSnap.id,
    name: data.name,
    email: data.email,
    role: data.role || 'PLAYER',
    avatar: data.avatar || null,
    bio: data.bio || null,
    createdAt: null as string | null,
    lastLoginAt: null as string | null,
    faction,
    _count: {
      posts: postCountSnap.data().count,
      chatMessages: msgCountSnap.data().count,
    },
  }
  // Приводим даты
  if (data.createdAt) {
    try {
      if (typeof data.createdAt === 'object' && '_seconds' in data.createdAt) {
        user.createdAt = new Date(
          (data.createdAt as any)._seconds * 1000 +
            ((data.createdAt as any)._nanoseconds || 0) / 1e6
        ).toISOString()
      } else if (data.createdAt instanceof Date) {
        user.createdAt = (data.createdAt as Date).toISOString()
      } else if (typeof data.createdAt === 'string') {
        user.createdAt = data.createdAt
      }
    } catch {
      user.createdAt = null
    }
  }
  if (data.lastLoginAt) {
    try {
      if (typeof data.lastLoginAt === 'object' && '_seconds' in data.lastLoginAt) {
        user.lastLoginAt = new Date(
          (data.lastLoginAt as any)._seconds * 1000 +
            ((data.lastLoginAt as any)._nanoseconds || 0) / 1e6
        ).toISOString()
      } else if (data.lastLoginAt instanceof Date) {
        user.lastLoginAt = (data.lastLoginAt as Date).toISOString()
      } else if (typeof data.lastLoginAt === 'string') {
        user.lastLoginAt = data.lastLoginAt
      }
    } catch {
      user.lastLoginAt = null
    }
  }

  return jsonResponse({ user })
}

const updateUserSchema = z.object({
  name: z.string().min(2).max(50).optional(),
  role: z.enum(['PLAYER', 'ADMIN']).optional(),
  avatar: z.string().optional(),
  bio: z.string().optional(),
})

// PUT /api/admin/users/[id] — обновление пользователя (роль, имя и т.д.)
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const body = await req.json()
  const parsed = updateUserSchema.safeParse(body)
  if (!parsed.success) return errorResponse('Некорректные данные', 422)

  // Нельзя менять свою роль
  if (parsed.data.role && ctx.userId === id) {
    return errorResponse('Нельзя изменить свою роль', 400)
  }

  const updateData: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() }
  if (parsed.data.name !== undefined) updateData.name = parsed.data.name
  if (parsed.data.role !== undefined) updateData.role = parsed.data.role
  if (parsed.data.avatar !== undefined) updateData.avatar = parsed.data.avatar || null
  if (parsed.data.bio !== undefined) updateData.bio = parsed.data.bio || null

  await db.collection(COLLECTIONS.users).doc(id).update(updateData)

  const userSnap = await db.collection(COLLECTIONS.users).doc(id).get()
  const data = userSnap.data()!
  const user = {
    id: userSnap.id,
    name: data.name,
    email: data.email,
    role: data.role || 'PLAYER',
    avatar: data.avatar || null,
  }
  return jsonResponse({ user, message: 'Пользователь обновлён' })
}

const banSchema = z.object({
  reason: z.string().max(500).optional(),
})

// POST /api/admin/users/[id]/ban — забанить пользователя
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()

  // Нельзя забанить себя
  if (ctx.userId === id) return errorResponse('Нельзя забанить себя', 400)

  const body = await req.json().catch(() => ({}))
  const parsed = banSchema.safeParse(body)

  await db.collection(COLLECTIONS.users).doc(id).update({
    isBanned: true,
    bannedAt: FieldValue.serverTimestamp(),
    bannedReason: parsed.success ? parsed.data.reason || null : null,
    bannedBy: ctx.userId,
    updatedAt: FieldValue.serverTimestamp(),
  })

  // Отзываем все токены пользователя — принудительный logout
  try {
    await getAdminAuth().revokeRefreshTokens(id)
  } catch (e) {
    console.error('[ban] revoke tokens failed:', e)
  }

  // Активность
  const userSnap = await db.collection(COLLECTIONS.users).doc(id).get()
  const data = userSnap.data()!
  await db.collection(COLLECTIONS.activity).add({
    type: 'USER_BANNED',
    userId: ctx.userId,
    targetId: id,
    data: { name: data.name, reason: parsed.success ? parsed.data.reason || null : null },
    createdAt: FieldValue.serverTimestamp(),
  })

  const user = {
    id: userSnap.id,
    name: data.name,
    isBanned: true,
    bannedReason: parsed.success ? parsed.data.reason || null : null,
  }
  return jsonResponse({ user, message: `Пользователь «${user.name}» заблокирован` })
}

// DELETE /api/admin/users/[id] — удаление ИЛИ разбан пользователя
// Если query ?action=unban — разбан, иначе — удаление
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const ctx = await requireAdmin(req)
  const { id } = await params
  const db = getAdminDb()
  const action = req.nextUrl.searchParams.get('action')

  // Разбан
  if (action === 'unban') {
    await db.collection(COLLECTIONS.users).doc(id).update({
      isBanned: false,
      bannedAt: null,
      bannedReason: null,
      bannedBy: null,
      updatedAt: FieldValue.serverTimestamp(),
    })

    const userSnap = await db.collection(COLLECTIONS.users).doc(id).get()
    const data = userSnap.data()!

    await db.collection(COLLECTIONS.activity).add({
      type: 'USER_UNBANNED',
      userId: ctx.userId,
      targetId: id,
      data: { name: data.name },
      createdAt: FieldValue.serverTimestamp(),
    })

    const user = { id: userSnap.id, name: data.name, isBanned: false }
    return jsonResponse({
      user,
      message: `Пользователь «${user.name}» разблокирован`,
    })
  }

  // Нельзя удалить себя
  if (ctx.userId === id) return errorResponse('Нельзя удалить себя', 400)

  // Загружаем имя для activity (до удаления)
  const userSnap = await db.collection(COLLECTIONS.users).doc(id).get()
  const userName = userSnap.exists ? userSnap.data()!.name : 'Unknown'

  await db.collection(COLLECTIONS.users).doc(id).delete()

  // Удаляем пользователя из Firebase Auth
  try {
    await getAdminAuth().deleteUser(id)
  } catch (e) {
    console.error('[delete] firebase auth delete failed:', e)
  }

  // Активность (для аудита)
  await db.collection(COLLECTIONS.activity).add({
    type: 'USER_DELETED',
    userId: ctx.userId,
    targetId: id,
    data: { name: userName },
    createdAt: FieldValue.serverTimestamp(),
  })

  return jsonResponse({ success: true, message: 'Пользователь удалён' })
}
