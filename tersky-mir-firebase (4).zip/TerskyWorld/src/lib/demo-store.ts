// Demo data layer — работает в браузере через localStorage, когда Firebase не настроен.
// Полностью повторяет API всех 30 endpoint'ов проекта «Терский Мир».
// Первый зарегистрированный пользователь = ADMIN.
// Все данные хранятся в localStorage под ключом tersky-mir-demo:v1.

const STORAGE_KEY = 'tersky-mir-demo:v1'

interface DemoUser {
  id: string
  name: string
  email: string
  password: string // в demo mode храним как есть (это демо!)
  role: 'ADMIN' | 'PLAYER'
  avatar: string | null
  bio: string | null
  isBanned: boolean
  bannedAt: string | null
  bannedReason: string | null
  bannedBy: string | null
  factionId: string | null
  createdAt: string
  updatedAt: string
  lastLoginAt: string | null
}

interface DemoFaction {
  id: string
  name: string
  shortName: string | null
  motto: string | null
  description: string | null
  bannerColor: string | null
  emblemUrl: string | null
  isApproved: boolean
  userId: string
  createdAt: string
  updatedAt: string
}

interface DemoFactionStat {
  id: string // `${factionId}_${sectionKey}`
  factionId: string
  sectionKey: string
  sectionTitle: string
  content: string // JSON
  order: number
  updatedAt: string
}

interface DemoPost {
  id: string
  title: string
  content: string
  context: string | null
  turnNumber: number | null
  weekNumber: number | null
  status: 'PENDING' | 'VERDICTED' | 'ARCHIVED'
  isPublic: boolean
  battleId: string | null
  authorId: string
  factionId: string | null
  verdict: DemoVerdict | null
  createdAt: string
  updatedAt: string
}

interface DemoVerdict {
  id: string
  postId: string
  roleplayText: string
  technicalText: string | null
  statChanges: string | null
  isFinal: boolean
  adminId: string
  createdAt: string
  updatedAt: string
}

interface DemoChatRoom {
  id: string
  name: string
  topic: string | null
  description: string | null
  status: 'OPEN' | 'CLOSED' | 'SUMMARIZED'
  summary: string | null
  createdAt: string
  updatedAt: string
  closedAt: string | null
}

interface DemoChatMessage {
  id: string
  chatRoomId: string
  userId: string
  content: string
  isSystem: boolean
  createdAt: string
}

interface DemoNews {
  id: string
  title: string
  content: string
  excerpt: string | null
  category: 'GENERAL' | 'WAR' | 'DIPLOMACY' | 'ECONOMY' | 'RELIGION'
  isPinned: boolean
  turnNumber: number | null
  authorId: string
  createdAt: string
  updatedAt: string
}

interface DemoBattle {
  id: string
  name: string
  description: string | null
  location: string | null
  turnNumber: number | null
  status: 'PREPARING' | 'ACTIVE' | 'POSTING' | 'RESOLVED'
  postDeadline: string | null
  createdAt: string
  updatedAt: string
}

interface DemoChronicle {
  id: string
  title: string
  content: string
  category: 'CHRONICLE' | 'HISTORY' | 'EVENT'
  era: string | null
  order: number
  authorId: string
  createdAt: string
  updatedAt: string
}

interface DemoBestiary {
  id: string
  name: string
  title: string | null
  content: string
  category: 'CREATURE' | 'FACTION' | 'PERSON' | 'PLACE'
  danger: string | null
  habitat: string | null
  imageUrl: string | null
  order: number
  authorId: string
  createdAt: string
  updatedAt: string
}

interface DemoBookmark {
  id: string // `${userId}_${type}_${entityId}`
  userId: string
  type: 'post' | 'news'
  entityId: string
  createdAt: string
}

interface DemoActivity {
  id: string
  type: string
  userId: string
  targetId: string
  data: Record<string, unknown>
  createdAt: string
}

interface DemoDB {
  users: DemoUser[]
  factions: DemoFaction[]
  factionStats: DemoFactionStat[]
  posts: DemoPost[]
  verdicts: DemoVerdict[]
  chatRooms: DemoChatRoom[]
  chatMessages: DemoChatMessage[]
  news: DemoNews[]
  battles: DemoBattle[]
  chronicle: DemoChronicle[]
  bestiary: DemoBestiary[]
  bookmarks: DemoBookmark[]
  activity: DemoActivity[]
  session: { userId: string | null }
}

const emptyDB: DemoDB = {
  users: [],
  factions: [],
  factionStats: [],
  posts: [],
  verdicts: [],
  chatRooms: [],
  chatMessages: [],
  news: [],
  battles: [],
  chronicle: [],
  bestiary: [],
  bookmarks: [],
  activity: [],
  session: { userId: null },
}

let cache: DemoDB | null = null

function loadDB(): DemoDB {
  if (cache) return cache
  if (typeof window === 'undefined') return emptyDB
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) {
      // First init — seed demo content
      const db = seedDemoData({ ...emptyDB })
      saveDB(db)
      return db
    }
    cache = { ...emptyDB, ...JSON.parse(raw) }
    return cache
  } catch {
    return emptyDB
  }
}

function saveDB(db: DemoDB) {
  cache = db
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db))
  } catch (e) {
    console.error('Demo saveDB failed:', e)
  }
}

function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
}

function now(): string {
  return new Date().toISOString()
}

// ====== Seed: начальные данные (новости, бестиарий, хроника, достижения) ======
function seedDemoData(db: DemoDB): DemoDB {
  const adminId = 'system'
  const ts = now()

  // Новости
  db.news = [
    {
      id: uid('news'),
      title: 'Перемирие в долине Серебряной реки',
      content: '## Перемирие\n\nПосле трёх лун кровопролитных боёв княжества **Лодерфес** и **Поморье** заключили перемирие. Границы восстановлены по состоянию на прошлую зиму.\n\n### Условия\n- Обмен пленными\n- Взаимный отказ от репараций\n- Совместный патруль на нейтральных землях',
      excerpt: 'После трёх лун кровопролитных боёв княжества заключили перемирие.',
      category: 'DIPLOMACY',
      isPinned: true,
      turnNumber: 12,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
    {
      id: uid('news'),
      title: 'Нашествие волкодлаков на северные рубежи',
      content: 'Стражи северных рубежей сообщают о небывалом скоплении **волкодлаков** в Тёмном Бору. Жителям окрестных деревень рекомендовано не покидать стены поселений после заката.',
      excerpt: 'Стражи сообщают о небывалом скоплении волкодлаков в Тёмном Бору.',
      category: 'WAR',
      isPinned: false,
      turnNumber: 12,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
    {
      id: uid('news'),
      title: 'Ярмарка в Поморье открыла торговый сезон',
      content: 'В столице Поморского княжества открылась ежегодная весенняя ярмарка. Купцы из десятка княжеств привезли товары: меха, мёд, янтарь, оружие, коней.',
      excerpt: 'В столице Поморского княжества открылась ежегодная весенняя ярмарка.',
      category: 'ECONOMY',
      isPinned: false,
      turnNumber: 12,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
  ]

  // Бестиарий
  db.bestiary = [
    {
      id: uid('best'),
      name: 'Волкодлак',
      title: 'Оборотень Тёмного Бора',
      content: '**Волкодлак** — древнее проклятие, обращающее человека в зверя в полнолуние. Живёт в глухих лесах, избегает серебра и рябиновых колов. Сильнее всего в ночь полнолуния.',
      category: 'CREATURE',
      danger: '4',
      habitat: 'Тёмный Бор, северные леса',
      imageUrl: null,
      order: 1,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
    {
      id: uid('best'),
      name: 'Лесной дух',
      title: 'Хранитель рощ',
      content: '**Леший** — хозяин леса. Принимает облик старца, опутанного мхом, или огромного медведя. Благоволит тем, кто не вредит лесу, и сбивает с пути браконьеров.',
      category: 'CREATURE',
      danger: '2',
      habitat: 'Все леса Терского мира',
      imageUrl: null,
      order: 2,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
    {
      id: uid('best'),
      name: 'Водяной',
      title: 'Владыка озёр',
      content: '**Водяной** — дух рек и озёр. Требует дани рыбой, утаскивает на дно неосторожных купальщиков. Может заключить договор с князем, обещая мирную воду в обмен на ежегодную жертву.',
      category: 'CREATURE',
      danger: '3',
      habitat: 'Реки, озёра, болота',
      imageUrl: null,
      order: 3,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
    {
      id: uid('best'),
      name: 'Лодерфес',
      title: 'Великое Княжество',
      content: 'Могущественное северное княжество у моря. Известно своими судостроителями и воинами-мореплавателями. Столица — город Лодерфес.',
      category: 'FACTION',
      danger: null,
      habitat: 'Северное побережье',
      imageUrl: null,
      order: 4,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
  ]

  // Хроника
  db.chronicle = [
    {
      id: uid('chr'),
      title: 'Основание Терского мира',
      content: '## Начало времён\n\nВ год Первый от Сотворения Мира собрались князья земель на Великий Сход. Каждый принёс свой сосуд с землёй, и слили их в один — так был заложен Терский мир.',
      category: 'HISTORY',
      era: 'I Эпоха',
      order: 1,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
    {
      id: uid('chr'),
      title: 'Битва у Туманного Брода',
      content: '## Битва у Туманного Брода\n\nВ третью луну второй весны сошлись войска Лодерфеса и Поморья у брода через Серебряную реку. Битва длилась три дня и завершилась перемирием.',
      category: 'EVENT',
      era: 'I Эпоха',
      order: 2,
      authorId: adminId,
      createdAt: ts,
      updatedAt: ts,
    },
  ]

  // Пример фракции (для демо)
  const demoFactionId = uid('fact')
  db.factions = [
    {
      id: demoFactionId,
      name: 'Великое Княжество Поморское',
      shortName: 'Поморье',
      motto: 'Сила в единстве',
      description: 'Северное княжество у моря. Известно своими мореходами и торговцами.',
      bannerColor: '#2d8a7e',
      emblemUrl: null,
      isApproved: true,
      userId: 'system',
      createdAt: ts,
      updatedAt: ts,
    },
  ]
  // Статы для демо-фракции
  db.factionStats = [
    {
      id: `${demoFactionId}_NAME`,
      factionId: demoFactionId,
      sectionKey: 'NAME',
      sectionTitle: 'Название',
      content: JSON.stringify({ state: 'Великое Княжество Поморское', ruler: 'Князь Светослав', motto: 'Сила в единстве' }),
      order: 0,
      updatedAt: ts,
    },
    {
      id: `${demoFactionId}_ARMY`,
      factionId: demoFactionId,
      sectionKey: 'ARMY',
      sectionTitle: 'Армия',
      content: JSON.stringify({ meleeInfantry: 5000, rangedInfantry: 2000, cavalry: 800, fleet: 12, orders: 'Орден Белого Медведя', convoyService: 'Береговая стража', cadres: 'Дружина князя' }),
      order: 3,
      updatedAt: ts,
    },
  ]

  // Пример битвы
  db.battles = [
    {
      id: uid('btl'),
      name: 'Битва у Туманного Брода',
      description: 'Пограничное столкновение между Лодерфесом и Поморьем за контроль над бродом.',
      location: 'Серебряная река, брод у деревни Туманной',
      turnNumber: 12,
      status: 'ACTIVE',
      postDeadline: null,
      createdAt: ts,
      updatedAt: ts,
    },
  ]

  return db
}

// ====== PUBLIC API ======

export const demoStore = {
  // ====== AUTH ======
  register(name: string, email: string, password: string): { user: DemoUser; message: string } {
    const db = loadDB()
    const normalized = email.toLowerCase().trim()
    if (db.users.find((u) => u.email === normalized)) {
      throw new Error('Пользователь с таким email уже существует')
    }
    const role = db.users.length === 0 ? 'ADMIN' : 'PLAYER'
    const user: DemoUser = {
      id: uid('user'),
      name: name.trim(),
      email: normalized,
      password,
      role,
      avatar: null,
      bio: null,
      isBanned: false,
      bannedAt: null,
      bannedReason: null,
      bannedBy: null,
      factionId: null,
      createdAt: now(),
      updatedAt: now(),
      lastLoginAt: now(),
    }
    db.users.push(user)
    db.session.userId = user.id
    db.activity.unshift({
      id: uid('act'),
      type: 'USER_REGISTERED',
      userId: user.id,
      targetId: user.id,
      data: { name: user.name, role: user.role },
      createdAt: now(),
    })
    saveDB(db)
    return { user, message: role === 'ADMIN' ? 'Аккаунт администратора создан' : 'Аккаунт создан' }
  },

  login(email: string, password: string): DemoUser {
    const db = loadDB()
    const normalized = email.toLowerCase().trim()
    const user = db.users.find((u) => u.email === normalized)
    if (!user) throw new Error('Пользователь не найден')
    if (user.password !== password) throw new Error('Неверный пароль')
    if (user.isBanned) {
      throw new Error(`Аккаунт заблокирован${user.bannedReason ? `: ${user.bannedReason}` : ''}`)
    }
    user.lastLoginAt = now()
    db.session.userId = user.id
    saveDB(db)
    return user
  },

  logout() {
    const db = loadDB()
    db.session.userId = null
    saveDB(db)
  },

  getCurrentUser(): DemoUser | null {
    const db = loadDB()
    if (!db.session.userId) return null
    return db.users.find((u) => u.id === db.session.userId) || null
  },

  // ====== USERS (admin) ======
  listUsers(): DemoUser[] {
    return loadDB().users
  },

  banUser(userId: string, reason: string, adminId: string) {
    const db = loadDB()
    const u = db.users.find((x) => x.id === userId)
    if (!u) throw new Error('Пользователь не найден')
    u.isBanned = true
    u.bannedAt = now()
    u.bannedReason = reason
    u.bannedBy = adminId
    u.updatedAt = now()
    db.activity.unshift({ id: uid('act'), type: 'USER_BANNED', userId: adminId, targetId: userId, data: { reason }, createdAt: now() })
    saveDB(db)
  },

  unbanUser(userId: string, adminId: string) {
    const db = loadDB()
    const u = db.users.find((x) => x.id === userId)
    if (!u) throw new Error('Пользователь не найден')
    u.isBanned = false
    u.bannedAt = null
    u.bannedReason = null
    u.bannedBy = null
    u.updatedAt = now()
    db.activity.unshift({ id: uid('act'), type: 'USER_UNBANNED', userId: adminId, targetId: userId, data: {}, createdAt: now() })
    saveDB(db)
  },

  // ====== FACTIONS ======
  createFaction(data: { name: string; shortName?: string; motto?: string; description?: string; bannerColor?: string }, userId: string): DemoFaction {
    const db = loadDB()
    if (db.factions.find((f) => f.userId === userId)) {
      throw new Error('У вас уже есть княжество')
    }
    const faction: DemoFaction = {
      id: uid('fact'),
      name: data.name,
      shortName: data.shortName || null,
      motto: data.motto || null,
      description: data.description || null,
      bannerColor: data.bannerColor || '#2d8a7e',
      emblemUrl: null,
      isApproved: false,
      userId,
      createdAt: now(),
      updatedAt: now(),
    }
    db.factions.push(faction)
    // Создаём пустые секции статов (8 штук из constants.ts)
    const sections = [
      { key: 'NAME', title: 'Название', order: 0, content: { state: data.name, ruler: '', motto: data.motto || '' } },
      { key: 'RELATIONS', title: 'Связи', order: 1, content: { diplomacy: [], military: [], economic: [], internal: [], secret: [] } },
      { key: 'TREASURY', title: 'Казна', order: 2, content: { income: 0, expenses: 0, balance: 0, diamondTreasury: 0, reserve: 0 } },
      { key: 'ARMY', title: 'Армия', order: 3, content: { meleeInfantry: 0, rangedInfantry: 0, cavalry: 0, fleet: 0, orders: '', convoyService: '', cadres: '' } },
      { key: 'RELIGION', title: 'Религия', order: 4, content: { faiths: [] } },
      { key: 'POPULATION', title: 'Население', order: 5, content: { total: 0, authorities: 0, militaryGarrisons: 0, tradeFamilies: 0, ruralUrban: 0, monastery: 0, mages: 0, vagrants: 0 } },
      { key: 'HORSES', title: 'Коневодство', order: 6, content: { total: 0, offspring: 0, exportObligations: 0, deficit: 0, expeditions: '', rules: '', mageService: '' } },
      { key: 'INSTITUTIONS', title: 'Учреждения', order: 7, content: { working: [], pending: [] } },
      { key: 'GOVERNANCE', title: 'Управление', order: 8, content: { rating: 0, senateHouses: '', bureaucracy: '', planning: '', secretCourse: '', prince: '' } },
    ]
    for (const s of sections) {
      db.factionStats.push({
        id: `${faction.id}_${s.key}`,
        factionId: faction.id,
        sectionKey: s.key,
        sectionTitle: s.title,
        content: JSON.stringify(s.content),
        order: s.order,
        updatedAt: now(),
      })
    }
    // Привязываем к пользователю
    const user = db.users.find((x) => x.id === userId)
    if (user) {
      user.factionId = faction.id
      user.updatedAt = now()
    }
    db.activity.unshift({ id: uid('act'), type: 'FACTION_CREATED', userId, targetId: faction.id, data: { name: faction.name }, createdAt: now() })
    saveDB(db)
    return faction
  },

  getFactionByUser(userId: string): DemoFaction | null {
    const db = loadDB()
    return db.factions.find((f) => f.userId === userId) || null
  },

  getFactionById(id: string): DemoFaction | null {
    return loadDB().factions.find((f) => f.id === id) || null
  },

  getFactionStats(factionId: string): DemoFactionStat[] {
    return loadDB().factionStats.filter((s) => s.factionId === factionId).sort((a, b) => a.order - b.order)
  },

  listApprovedFactions(): DemoFaction[] {
    return loadDB().factions.filter((f) => f.isApproved)
  },

  approveFaction(factionId: string) {
    const db = loadDB()
    const f = db.factions.find((x) => x.id === factionId)
    if (f) {
      f.isApproved = true
      f.updatedAt = now()
      saveDB(db)
    }
  },

  // ====== POSTS ======
  createPost(data: { title: string; content: string; context?: string; turnNumber?: number; weekNumber?: number; isPublic?: boolean; battleId?: string }, authorId: string): DemoPost {
    const db = loadDB()
    const author = db.users.find((u) => u.id === authorId)
    const post: DemoPost = {
      id: uid('post'),
      title: data.title,
      content: data.content,
      context: data.context || null,
      turnNumber: data.turnNumber || null,
      weekNumber: data.weekNumber || null,
      status: 'PENDING',
      isPublic: data.isPublic || false,
      battleId: data.battleId || null,
      authorId,
      factionId: author?.factionId || null,
      verdict: null,
      createdAt: now(),
      updatedAt: now(),
    }
    db.posts.unshift(post)
    db.activity.unshift({ id: uid('act'), type: 'POST_CREATED', userId: authorId, targetId: post.id, data: { title: post.title }, createdAt: now() })
    saveDB(db)
    return post
  },

  listPosts(filter?: { authorId?: string; status?: string; battleId?: string }): DemoPost[] {
    const db = loadDB()
    let posts = [...db.posts]
    if (filter?.authorId) posts = posts.filter((p) => p.authorId === filter.authorId)
    if (filter?.status) posts = posts.filter((p) => p.status === filter.status)
    if (filter?.battleId) posts = posts.filter((p) => p.battleId === filter.battleId)
    return posts.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  },

  getPost(id: string): DemoPost | null {
    return loadDB().posts.find((p) => p.id === id) || null
  },

  deletePost(id: string, userId: string, role: string) {
    const db = loadDB()
    const post = db.posts.find((p) => p.id === id)
    if (!post) throw new Error('Пост не найден')
    if (post.authorId !== userId && role !== 'ADMIN') throw new Error('Нет прав на удаление')
    db.posts = db.posts.filter((p) => p.id !== id)
    if (post.verdict) db.verdicts = db.verdicts.filter((v) => v.id !== post.verdict!.id)
    saveDB(db)
  },

  // ====== VERDICTS ======
  issueVerdict(postId: string, roleplayText: string, technicalText: string | null, adminId: string): DemoVerdict {
    const db = loadDB()
    const post = db.posts.find((p) => p.id === postId)
    if (!post) throw new Error('Пост не найден')
    // Удаляем старый вердикт если есть
    if (post.verdict) {
      db.verdicts = db.verdicts.filter((v) => v.id !== post.verdict!.id)
    }
    const verdict: DemoVerdict = {
      id: uid('verd'),
      postId,
      roleplayText,
      technicalText,
      statChanges: null,
      isFinal: true,
      adminId,
      createdAt: now(),
      updatedAt: now(),
    }
    db.verdicts.push(verdict)
    post.verdict = verdict
    post.status = 'VERDICTED'
    post.updatedAt = now()
    db.activity.unshift({ id: uid('act'), type: 'POST_VERDICTED', userId: adminId, targetId: postId, data: { title: post.title }, createdAt: now() })
    saveDB(db)
    return verdict
  },

  // ====== CHATS ======
  listChats(userId: string, role: string): DemoChatRoom[] {
    const db = loadDB()
    // В demo: показываем все чаты (упрощение), но в реальном проекте нужно фильтровать по участникам
    let rooms = db.chatRooms
    if (role !== 'ADMIN') {
      // Игрок видит чаты, где он участник. В demo упрощаем: создатель = участник
      // Для демо: показываем все, чтобы пользователь видел хотя бы системные
    }
    return rooms.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  },

  createChat(data: { name: string; topic?: string; description?: string }, userId: string): DemoChatRoom {
    const db = loadDB()
    const room: DemoChatRoom = {
      id: uid('chat'),
      name: data.name,
      topic: data.topic || null,
      description: data.description || null,
      status: 'OPEN',
      summary: null,
      createdAt: now(),
      updatedAt: now(),
      closedAt: null,
    }
    db.chatRooms.push(room)
    // Системное сообщение о создании
    db.chatMessages.push({
      id: uid('msg'),
      chatRoomId: room.id,
      userId: 'system',
      content: `Переговоры начаты. Тема: ${data.topic || 'без темы'}`,
      isSystem: true,
      createdAt: now(),
    })
    saveDB(db)
    return room
  },

  getChat(id: string): DemoChatRoom | null {
    return loadDB().chatRooms.find((c) => c.id === id) || null
  },

  listMessages(chatRoomId: string): DemoChatMessage[] {
    return loadDB().chatMessages.filter((m) => m.chatRoomId === chatRoomId).sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  },

  sendMessage(chatRoomId: string, userId: string, content: string): DemoChatMessage {
    const db = loadDB()
    const chat = db.chatRooms.find((c) => c.id === chatRoomId)
    if (!chat) throw new Error('Чат не найден')
    if (chat.status === 'CLOSED' || chat.status === 'SUMMARIZED') throw new Error('Переговоры завершены')
    const msg: DemoChatMessage = {
      id: uid('msg'),
      chatRoomId,
      userId,
      content,
      isSystem: false,
      createdAt: now(),
    }
    db.chatMessages.push(msg)
    db.activity.unshift({ id: uid('act'), type: 'MESSAGE_SENT', userId, targetId: chatRoomId, data: { content: content.slice(0, 100) }, createdAt: now() })
    saveDB(db)
    return msg
  },

  // ====== NEWS ======
  listNews(): DemoNews[] {
    return [...loadDB().news].sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1
      if (!a.isPinned && b.isPinned) return 1
      return b.createdAt.localeCompare(a.createdAt)
    })
  },

  getNews(id: string): DemoNews | null {
    return loadDB().news.find((n) => n.id === id) || null
  },

  createNews(data: { title: string; content: string; excerpt?: string; category?: string; isPinned?: boolean; turnNumber?: number }, authorId: string): DemoNews {
    const db = loadDB()
    const news: DemoNews = {
      id: uid('news'),
      title: data.title,
      content: data.content,
      excerpt: data.excerpt || null,
      category: (data.category as DemoNews['category']) || 'GENERAL',
      isPinned: data.isPinned || false,
      turnNumber: data.turnNumber || null,
      authorId,
      createdAt: now(),
      updatedAt: now(),
    }
    db.news.unshift(news)
    db.activity.unshift({ id: uid('act'), type: 'NEWS_PUBLISHED', userId: authorId, targetId: news.id, data: { title: news.title }, createdAt: now() })
    saveDB(db)
    return news
  },

  // ====== BATTLES ======
  listBattles(): DemoBattle[] {
    return [...loadDB().battles].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  },

  getBattle(id: string): DemoBattle | null {
    return loadDB().battles.find((b) => b.id === id) || null
  },

  // ====== CHRONICLE ======
  listChronicle(): DemoChronicle[] {
    return [...loadDB().chronicle].sort((a, b) => a.order - b.order)
  },

  getChronicle(id: string): DemoChronicle | null {
    return loadDB().chronicle.find((c) => c.id === id) || null
  },

  // ====== BESTIARY ======
  listBestiary(category?: string): DemoBestiary[] {
    let items = [...loadDB().bestiary]
    if (category) items = items.filter((b) => b.category === category)
    return items.sort((a, b) => a.order - b.order)
  },

  getBestiary(id: string): DemoBestiary | null {
    return loadDB().bestiary.find((b) => b.id === id) || null
  },

  // ====== BOOKMARKS ======
  listBookmarks(userId: string): DemoBookmark[] {
    return loadDB().bookmarks.filter((b) => b.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  },

  toggleBookmark(userId: string, type: 'post' | 'news', entityId: string): boolean {
    const db = loadDB()
    const id = `${userId}_${type}_${entityId}`
    const existing = db.bookmarks.find((b) => b.id === id)
    if (existing) {
      db.bookmarks = db.bookmarks.filter((b) => b.id !== id)
      saveDB(db)
      return false // removed
    }
    db.bookmarks.push({ id, userId, type, entityId, createdAt: now() })
    saveDB(db)
    return true // added
  },

  isBookmarked(userId: string, type: 'post' | 'news', entityId: string): boolean {
    const id = `${userId}_${type}_${entityId}`
    return !!loadDB().bookmarks.find((b) => b.id === id)
  },

  // ====== ACTIVITY ======
  listActivity(limit = 50): DemoActivity[] {
    return loadDB().activity.slice(0, limit)
  },

  // ====== PROFILE ======
  updateProfile(userId: string, data: { name?: string; bio?: string; avatar?: string | null }): DemoUser {
    const db = loadDB()
    const u = db.users.find((x) => x.id === userId)
    if (!u) throw new Error('Пользователь не найден')
    if (data.name !== undefined) u.name = data.name
    if (data.bio !== undefined) u.bio = data.bio
    if (data.avatar !== undefined) u.avatar = data.avatar
    u.updatedAt = now()
    saveDB(db)
    return u
  },

  // ====== RESET ======
  resetAll() {
    if (typeof window === 'undefined') return
    localStorage.removeItem(STORAGE_KEY)
    cache = null
    loadDB()
  },

  // ====== CHECK ======
  isDemoMode(): boolean {
    return true
  },
}

export type {
  DemoUser,
  DemoFaction,
  DemoFactionStat,
  DemoPost,
  DemoVerdict,
  DemoChatRoom,
  DemoChatMessage,
  DemoNews,
  DemoBattle,
  DemoChronicle,
  DemoBestiary,
  DemoBookmark,
  DemoActivity,
}
