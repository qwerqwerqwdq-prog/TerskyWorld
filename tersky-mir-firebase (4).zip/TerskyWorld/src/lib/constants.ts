// Конфигурация секций статистики фракции (по образцу из ТЗ)
export interface StatFieldDef {
  key: string
  label: string
  type: 'number' | 'text' | 'longtext' | 'list'
  unit?: string
  placeholder?: string
}

export interface StatSectionDef {
  key: string
  title: string
  icon: string
  description: string
  defaultContent: Record<string, unknown>
  fields: StatFieldDef[]
}

export const STAT_SECTIONS: StatSectionDef[] = [
  {
    key: 'NAME',
    title: 'Название',
    icon: 'Flag',
    description: 'Наименование государства',
    defaultContent: { state: 'Новое государство', ruler: '', motto: '' },
    fields: [
      { key: 'state', label: 'Государство', type: 'text', placeholder: 'Великое Княжество Помское' },
      { key: 'ruler', label: 'Правитель', type: 'text', placeholder: 'Князь Светослав' },
      { key: 'motto', label: 'Девиз', type: 'text', placeholder: 'Сила в единстве' },
    ],
  },
  {
    key: 'RELATIONS',
    title: 'Связи',
    icon: 'Handshake',
    description: 'Дипломатия, военные, экономические и тайные связи',
    defaultContent: { diplomacy: [], military: [], economic: [], internal: [], secret: [], ambassadorReplies: [] },
    fields: [
      { key: 'diplomacy', label: 'Дипломатические', type: 'list' },
      { key: 'military', label: 'Военные', type: 'list' },
      { key: 'economic', label: 'Экономические', type: 'list' },
      { key: 'internal', label: 'Внутренние', type: 'list' },
      { key: 'secret', label: 'Тайные', type: 'list' },
      { key: 'ambassadorReplies', label: 'Ответы послов', type: 'list' },
    ],
  },
  {
    key: 'TREASURY',
    title: 'Казна',
    icon: 'Coins',
    description: 'Доходы, расходы, баланс, резервы',
    defaultContent: { income: 0, expenses: 0, balance: 0, diamondTreasury: 0, reserve: 0, smallLoans: 0, shares: '', pending: '' },
    fields: [
      { key: 'income', label: 'Доходы/мес', type: 'number', unit: 'солей' },
      { key: 'expenses', label: 'Расходы/мес', type: 'number', unit: 'солей' },
      { key: 'balance', label: 'Баланс/мес', type: 'number', unit: 'солей' },
      { key: 'diamondTreasury', label: 'Алмазная казна', type: 'number', unit: 'солей' },
      { key: 'reserve', label: 'Резерв', type: 'number', unit: 'солей' },
      { key: 'smallLoans', label: 'Малые займы', type: 'number', unit: 'солей' },
      { key: 'shares', label: 'Паи', type: 'text' },
      { key: 'pending', label: 'Ждут денег', type: 'text' },
    ],
  },
  {
    key: 'ARMY',
    title: 'Армия',
    icon: 'Swords',
    description: 'Пехота, кавалерия, флот, ордена',
    defaultContent: { meleeInfantry: 0, rangedInfantry: 0, cavalry: 0, fleet: 0, orders: '', convoyService: '', cadres: '' },
    fields: [
      { key: 'meleeInfantry', label: 'Пехота ближнего боя', type: 'number', unit: 'копейщиков' },
      { key: 'rangedInfantry', label: 'Пехота дальнего боя', type: 'number', unit: 'лучников' },
      { key: 'cavalry', label: 'Кавалерия', type: 'number', unit: 'всадников' },
      { key: 'fleet', label: 'Флот', type: 'number', unit: 'ушкуев' },
      { key: 'orders', label: 'Ордена', type: 'text' },
      { key: 'convoyService', label: 'Конвойная служба', type: 'text' },
      { key: 'cadres', label: 'Кадры', type: 'text' },
    ],
  },
  {
    key: 'RELIGION',
    title: 'Религия',
    icon: 'Church',
    description: 'Религиозный состав населения',
    defaultContent: { faiths: [] },
    fields: [
      { key: 'faiths', label: 'Вероисповедания', type: 'list' },
    ],
  },
  {
    key: 'POPULATION',
    title: 'Население',
    icon: 'Users',
    description: 'Численность и состав населения',
    defaultContent: { total: 0, authorities: 0, militaryGarrisons: 0, tradeFamilies: 0, ruralUrban: 0, monastery: 0, mages: 0, vagrants: 0 },
    fields: [
      { key: 'total', label: 'Всего', type: 'number' },
      { key: 'authorities', label: 'Власти', type: 'number' },
      { key: 'militaryGarrisons', label: 'Гарнизоны', type: 'number' },
      { key: 'tradeFamilies', label: 'Торговцы', type: 'number' },
      { key: 'ruralUrban', label: 'Город/село', type: 'number' },
      { key: 'monastery', label: 'Монастыри', type: 'number' },
      { key: 'mages', label: 'Маги', type: 'number' },
      { key: 'vagrants', label: 'Бродяги', type: 'number' },
    ],
  },
  {
    key: 'HORSES',
    title: 'Коневодство',
    icon: 'Sparkles',
    description: 'Поголовье, приплод, экспорт, дефицит',
    defaultContent: { total: 0, offspring: 0, exportObligations: 0, deficit: 0, expeditions: '', rules: '', mageService: '' },
    fields: [
      { key: 'total', label: 'Поголовье', type: 'number' },
      { key: 'offspring', label: 'Приплод/год', type: 'number' },
      { key: 'exportObligations', label: 'Экспорт', type: 'number' },
      { key: 'deficit', label: 'Дефицит', type: 'number' },
      { key: 'expeditions', label: 'Экспедиции', type: 'text' },
      { key: 'rules', label: 'Правила', type: 'text' },
      { key: 'mageService', label: 'Маги при деле', type: 'text' },
    ],
  },
  {
    key: 'INSTITUTIONS',
    title: 'Учреждения',
    icon: 'Building2',
    description: 'Работающие и ожидающие учреждения',
    defaultContent: { working: [], pending: [] },
    fields: [
      { key: 'working', label: 'Работающие', type: 'list' },
      { key: 'pending', label: 'Ожидающие', type: 'list' },
    ],
  },
  {
    key: 'GOVERNANCE',
    title: 'Управление',
    icon: 'Crown',
    description: 'Сенат, бюрократия, планирование, князь',
    defaultContent: { rating: 0, senateHouses: '', bureaucracy: '', planning: '', secretCourse: '', prince: '' },
    fields: [
      { key: 'rating', label: 'Рейтинг управления', type: 'number', unit: '%' },
      { key: 'senateHouses', label: 'Дома Сената', type: 'text' },
      { key: 'bureaucracy', label: 'Бюрократия', type: 'text' },
      { key: 'planning', label: 'Планирование', type: 'text' },
      { key: 'secretCourse', label: 'Тайный курс', type: 'text' },
      { key: 'prince', label: 'Князь', type: 'text' },
    ],
  },
]

export function getSectionDef(key: string): StatSectionDef | undefined {
  return STAT_SECTIONS.find((s) => s.key === key)
}

// Цвета для категорий новостей
export const NEWS_CATEGORIES: Record<string, { label: string; color: string }> = {
  GENERAL: { label: 'Общие', color: 'bg-slate-500/20 text-slate-300 border-slate-500/30' },
  WAR: { label: 'Военные', color: 'bg-red-500/20 text-red-300 border-red-500/30' },
  DIPLOMACY: { label: 'Дипломатия', color: 'bg-teal-500/20 text-teal-300 border-teal-500/30' },
  ECONOMY: { label: 'Экономика', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  RELIGION: { label: 'Религия', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
}

// Категории бестиария
export const BESTIARY_CATEGORIES: Record<string, string> = {
  CREATURE: 'Существо',
  FACTION: 'Фракция',
  PERSON: 'Персона',
  PLACE: 'Место',
}

// Категории хроники
export const CHRONICLE_CATEGORIES: Record<string, string> = {
  CHRONICLE: 'Летопись',
  HISTORY: 'История',
  EVENT: 'Событие',
}
