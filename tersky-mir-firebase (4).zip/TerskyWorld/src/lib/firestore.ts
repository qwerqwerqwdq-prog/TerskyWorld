// Firestore helpers: типы коллекций, timestamp-конверсии, common queries

import { FieldValue, type Firestore } from 'firebase-admin/firestore'

// Коллекции — единый источник правды
export const COLLECTIONS = {
  users: 'users',
  factions: 'factions',
  factionStats: 'factionStats', // subcollection? Нет — топ-уровень, keyed by factionId_sectionKey
  posts: 'posts',
  verdicts: 'verdicts',
  attachments: 'attachments',
  chatRooms: 'chatRooms',
  chatParticipants: 'chatParticipants',
  chatMessages: 'chatMessages',
  news: 'news',
  battles: 'battles',
  battleForces: 'battleForces',
  battleParticipants: 'battleParticipants',
  chronicle: 'chronicle',
  bestiary: 'bestiary',
  bookmarks: 'bookmarks',
  userAchievements: 'userAchievements',
  rankSnapshots: 'rankSnapshots',
  activity: 'activity',
  statChangeLogs: 'statChangeLogs',
} as const

// Конвертация Firestore Timestamp → ISO-строка для API
export function toApiDate(ts: unknown): string | null {
  if (!ts) return null
  if (typeof ts === 'string') return ts
  if (typeof ts === 'number') return new Date(ts).toISOString()
  if (typeof ts === 'object' && ts !== null && '_seconds' in ts) {
    const s = (ts as { _seconds: number; _nanoseconds?: number })
    return new Date(s._seconds * 1000 + (s._nanoseconds || 0) / 1e6).toISOString()
  }
  if (ts instanceof Date) return ts.toISOString()
  return null
}

// Маппер документа: добавляет id + конвертирует timestamp'ы в ISO-строки
export function docToApi<T extends Record<string, unknown>>(snap: { id: string; data: () => T }): (T & { id: string }) {
  const data = snap.data()
  const out: Record<string, unknown> = { ...data, id: snap.id }
  for (const key of Object.keys(out)) {
    if (out[key] && typeof out[key] === 'object' && '_seconds' in (out[key] as object)) {
      out[key] = toApiDate(out[key])
    }
  }
  return out as T & { id: string }
}

export { FieldValue }
