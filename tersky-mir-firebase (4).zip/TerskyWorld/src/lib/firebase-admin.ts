// Серверный Firebase Admin SDK — для API routes (verifyIdToken, Firestore)
// Service Account берётся из env-переменных
//
// ВАЖНО: используем require() вместо ESM import, потому что в next.config.ts
// firebase-admin добавлен в serverExternalPackages. В external mode Next.js
// оставляет его как Node.js модуль, и require() работает стабильно во всех
// serverless средах (Vercel, Cloud Run, AWS Lambda).

import type { App as AdminApp } from 'firebase-admin/app'
import type { Auth as AdminAuth } from 'firebase-admin/auth'
import type { Firestore as AdminFirestore } from 'firebase-admin/firestore'

 
type AnyApp = AdminApp & {
  auth?: () => unknown
  firestore?: () => unknown
}

let app: AnyApp | null = null
 
let authInstance: any = null
 
let dbInstance: any = null

function ensureApp(): AnyApp {
  if (app) return app

  // Dynamic require — работает в serverless средах с external packages
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const admin = require('firebase-admin')
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { initializeApp, cert, getApps, getApp } = require('firebase-admin/app')

  // Если уже инициализирован — переиспользуем (Firebase singleton)
   
  const existingApp: any = getApps().length ? getApp() : null
  if (existingApp) {
    app = existingApp
    return app
  }

  const projectId = process.env.FIREBASE_PROJECT_ID
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL
  const privateKeyRaw = process.env.FIREBASE_PRIVATE_KEY

  let config: Record<string, unknown> = {
    projectId: projectId || undefined,
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || undefined,
  }

  if (projectId && clientEmail && privateKeyRaw) {
    // Заменяем escape-последовательности из .env (\\n → \n)
    const privateKey = privateKeyRaw.replace(/\\n/g, '\n')
    config = {
      ...config,
      credential: cert({ projectId, clientEmail, privateKey }),
    }
  }

   
  app = initializeApp(config as any) as any
  return app
}

 
export function getAdminAuth(): any {
  if (!authInstance) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { getAuth } = require('firebase-admin/auth')
    authInstance = getAuth(ensureApp())
  }
  return authInstance
}

 
export function getAdminDb(): any {
  if (!dbInstance) {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { getFirestore } = require('firebase-admin/firestore')
    dbInstance = getFirestore(ensureApp())
  }
  return dbInstance
}

export type { AdminApp, AdminAuth, AdminFirestore }
