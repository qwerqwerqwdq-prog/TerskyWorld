// Клиентский Firebase SDK — инициализируется только в браузере
// Используется для Firebase Auth и прямых Firestore-запросов (realtime в чатах)

import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app'
import { getAuth, type Auth } from 'firebase/auth'
import { getFirestore, type Firestore } from 'firebase/firestore'
import { getStorage, type FirebaseStorage } from 'firebase/storage'

export const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId
)

// Lazy init — работает только на клиенте ( Next.js 'use client' контекст)
let app: FirebaseApp | null = null
let authInstance: Auth | null = null
let dbInstance: Firestore | null = null
let storageInstance: FirebaseStorage | null = null

function ensureApp(): FirebaseApp {
  if (typeof window === 'undefined') {
    throw new Error('Firebase client SDK можно использовать только в браузере')
  }
  if (!app) {
    app = getApps().length ? getApp() : initializeApp(firebaseConfig)
  }
  return app
}

export function getFirebaseAuth(): Auth {
  if (!authInstance) authInstance = getAuth(ensureApp())
  return authInstance
}

export function getDb(): Firestore {
  if (!dbInstance) dbInstance = getFirestore(ensureApp())
  return dbInstance
}

export function getStorageInstance(): FirebaseStorage {
  if (!storageInstance) storageInstance = getStorage(ensureApp())
  return storageInstance
}

// Хелпер: получить текущий ID-токен пользователя (для передачи в API-запросы)
export async function getIdToken(): Promise<string | null> {
  if (typeof window === 'undefined') return null
  try {
    const { getFirebaseAuth: ga } = await import('./firebase-client')
    const a = ga()
    const user = a.currentUser
    if (!user) return null
    return await user.getIdToken()
  } catch {
    return null
  }
}
