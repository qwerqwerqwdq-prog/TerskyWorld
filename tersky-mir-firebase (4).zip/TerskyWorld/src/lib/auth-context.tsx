'use client'

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  updateProfile,
  type User as FbUser,
} from 'firebase/auth'
import { getFirebaseAuth, isFirebaseConfigured, getIdToken } from './firebase-client'
import { demoStore } from './demo-store'

export interface SessionUser {
  id: string
  name: string
  email: string
  role: string
  avatar?: string | null
  bio?: string | null
  faction?: {
    id: string
    name: string
    shortName?: string | null
    isApproved: boolean
  } | null
}

interface AuthContextValue {
  user: SessionUser | null
  fbUser: FbUser | null
  loading: boolean
  error: string | null
  isDemoMode: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<{ role: string }>
  signOut: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth должен использоваться внутри FirebaseAuthProvider')
  return ctx
}

// Конвертация DemoUser → SessionUser
function demoUserToSession(u: ReturnType<typeof demoStore.getCurrentUser>): SessionUser | null {
  if (!u) return null
  let faction = null
  if (u.factionId) {
    const f = demoStore.getFactionById(u.factionId)
    if (f) {
      faction = { id: f.id, name: f.name, shortName: f.shortName, isApproved: f.isApproved }
    }
  }
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    avatar: u.avatar,
    bio: u.bio,
    faction,
  }
}

// Загрузка профиля из Firestore по uid (Firebase mode)
async function loadSessionUser(uid: string): Promise<SessionUser | null> {
  try {
    const token = await getIdToken()
    if (!token) return null
    const res = await fetch('/api/session', {
      headers: { Authorization: `Bearer ${token}` },
    })
    if (!res.ok) return null
    const data = await res.json()
    return data.user || null
  } catch {
    return null
  }
}

export function FirebaseAuthProvider({ children }: { children: ReactNode }) {
  const useFirebase = isFirebaseConfigured
  // Lazy initial state: если Firebase не настроен — сразу demo mode, loading=false
  const [user, setUser] = useState<SessionUser | null>(() => {
    if (isFirebaseConfigured) return null
    return demoUserToSession(demoStore.getCurrentUser())
  })
  const [fbUser, setFbUser] = useState<FbUser | null>(null)
  const [loading, setLoading] = useState<boolean>(useFirebase) // false если demo
  const [error, setError] = useState<string | null>(null)

  // ====== Firebase mode: подписка на onAuthStateChanged ======
  useEffect(() => {
    if (!useFirebase) {
      // Demo mode: loading=false через lazy initial, ничего не делаем
      return
    }
    let auth
    try {
      auth = getFirebaseAuth()
    } catch (e) {
      console.error('Firebase init failed:', e)
      // Не зовём setState здесь — onError callback React Error Boundary обработает
      return
    }
    const unsub = onAuthStateChanged(auth, async (u) => {
      setFbUser(u)
      if (u) {
        try {
          const su = await loadSessionUser(u.uid)
          setUser(su)
        } catch {
          setUser(null)
        }
      } else {
        setUser(null)
      }
      setLoading(false)
    })
    return () => unsub()
  }, [useFirebase])

  // ====== Demo mode: перехват fetch /api/* и возврат из localStorage ======
  useEffect(() => {
    if (useFirebase) {
      // Firebase mode: добавляем Bearer-токен ко всем /api/* запросам
      const originalFetch = window.fetch
      window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
        const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url
        const isApiCall = url.startsWith('/api/') || url.includes('/api/')
        const isAuthEndpoint = url.includes('/api/auth/login') || url.includes('/api/auth/register') || url.includes('/api/auth/logout')
        if (isApiCall && !isAuthEndpoint) {
          const token = await getIdToken()
          if (token) {
            const headers = new Headers(init?.headers || {})
            headers.set('Authorization', `Bearer ${token}`)
            init = { ...init, headers }
          }
        }
        return originalFetch(input, init)
      }
      return () => {
        window.fetch = originalFetch
      }
    }

    // ====== Demo mode: перехватываем все /api/* запросы ======
    const originalFetch = window.fetch
    window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url
      const method = (init?.method || 'GET').toUpperCase()

      // Если это не /api/* — пропускаем оригинальный fetch
      if (!url.includes('/api/')) {
        return originalFetch(input, init)
      }

      // Парсим путь
      const apiPath = url.startsWith('/api/') ? url : url.substring(url.indexOf('/api/'))
      const pathWithoutQuery = apiPath.split('?')[0]
      const query = new URLSearchParams(apiPath.split('?')[1] || '')
      const body = init?.body ? JSON.parse(init.body as string) : undefined

      try {
        const result = handleDemoApi(pathWithoutQuery, method, query, body)
        return new Response(JSON.stringify(result.body), {
          status: result.status,
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
        })
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Demo error'
        return new Response(JSON.stringify({ error: msg }), {
          status: 400,
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
        })
      }
    }
    return () => {
      window.fetch = originalFetch
    }
  }, [useFirebase])

  // ====== login / register / signOut ======
  const login = async (email: string, password: string) => {
    setError(null)
    if (!useFirebase) {
      // Demo mode
      const u = demoStore.login(email, password)
      setUser(demoUserToSession(u)!)
      return
    }
    const auth = getFirebaseAuth()
    const cred = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), password)
    setFbUser(cred.user)
    const su = await loadSessionUser(cred.user.uid)
    if (!su) throw new Error('Профиль не найден')
    setUser(su)
  }

  const register = async (name: string, email: string, password: string) => {
    setError(null)
    if (!useFirebase) {
      // Demo mode
      const { user: u, message } = demoStore.register(name, email, password)
      setUser(demoUserToSession(u)!)
      return { role: u.role }
    }
    const auth = getFirebaseAuth()
    const cred = await createUserWithEmailAndPassword(auth, email.trim().toLowerCase(), password)
    await updateProfile(cred.user, { displayName: name })
    // Пробуем создать профиль через API (нужен Firebase Admin SDK)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: cred.user.uid, name, email: email.trim().toLowerCase() }),
      })
      // Если сервер недоступен (500) — fallback на demoStore
      if (res.status === 500) {
        // Серверный Firebase не настроен — используем demoStore как fallback
        const { user: u } = demoStore.register(name, email, password)
        // Но перезаписываем ID на Firebase UID
        u.id = cred.user.uid
        const su = demoUserToSession(u)!
        setUser(su)
        return { role: u.role }
      }
      const text = await res.text()
      const data = text ? JSON.parse(text) : {}
      if (!res.ok) {
        await cred.user.delete()
        throw new Error(data.error || 'Ошибка регистрации')
      }
      setFbUser(cred.user)
      // Пробуем загрузить сессию; если не получается — fallback на demoStore
      const su = await loadSessionUser(cred.user.uid)
      if (su) {
        setUser(su)
      } else {
        // Fallback: создаём профиль в demoStore
        const { user: u } = demoStore.register(name, email, password)
        u.id = cred.user.uid
        setUser(demoUserToSession(u)!)
      }
      return { role: data.user?.role || 'PLAYER' }
    } catch (e) {
      // Если ошибка сети — fallback на demoStore
      if (e instanceof TypeError && e.message.includes('fetch')) {
        const { user: u } = demoStore.register(name, email, password)
        u.id = cred.user.uid
        setUser(demoUserToSession(u)!)
        return { role: u.role }
      }
      throw e
    }
  }

  const signOut = async () => {
    if (!useFirebase) {
      demoStore.logout()
      setUser(null)
      return
    }
    const auth = getFirebaseAuth()
    await fbSignOut(auth)
    setUser(null)
    setFbUser(null)
  }

  const refreshUser = async () => {
    if (!useFirebase) {
      const current = demoStore.getCurrentUser()
      setUser(demoUserToSession(current))
      return
    }
    if (fbUser) {
      const su = await loadSessionUser(fbUser.uid)
      setUser(su)
    }
  }

  return (
    <AuthContext.Provider value={{ user, fbUser, loading, error, isDemoMode: !useFirebase, login, register, signOut, refreshUser }}>
      {children}
    </AuthContext.Provider>
  )
}

// ====== Demo API handler — повторяет все 30 endpoint'ов ======
function handleDemoApi(path: string, method: string, query: URLSearchParams, body: any): { status: number; body: any } {
  const currentUser = demoStore.getCurrentUser()
  if (!currentUser) {
    // Разрешаем только health-check и session без auth
    if (path === '/api' || path === '/api/') return { status: 200, body: { status: 'ok', service: 'Терский Мир', version: '1.0-demo' } }
    if (path === '/api/session') return { status: 200, body: { user: null } }
    if (path === '/api/auth/register') {
      const { name, email, password } = body || {}
      if (!name || !email || !password) throw new Error('Не заполнены поля')
      const { user, message } = demoStore.register(name, email, password)
      return { status: 200, body: { user: { id: user.id, name: user.name, email: user.email, role: user.role }, message } }
    }
    throw new Error('Не авторизован')
  }

  // ====== /api/session ======
  if (path === '/api/session' && method === 'GET') {
    return { status: 200, body: { user: demoUserToSession(currentUser) } }
  }

  // ====== /api (health) ======
  if (path === '/api' || path === '/api/') {
    return { status: 200, body: { status: 'ok', service: 'Терский Мир', version: '1.0-demo' } }
  }

  // ====== /api/posts ======
  if (path === '/api/posts' && method === 'GET') {
    const filter: any = {}
    if (currentUser.role !== 'ADMIN') filter.authorId = currentUser.id
    if (query.get('status')) filter.status = query.get('status')!
    if (query.get('battleId')) filter.battleId = query.get('battleId')!
    const posts = demoStore.listPosts(filter).map((p) => {
      const author = demoStore.listUsers().find((u) => u.id === p.authorId)
      const faction = p.factionId ? demoStore.getFactionById(p.factionId) : null
      return {
        ...p,
        author: author ? { id: author.id, name: author.name } : null,
        faction: faction ? { id: faction.id, name: faction.name } : null,
        verdict: p.verdict ? {
          ...p.verdict,
          admin: (() => { const a = demoStore.listUsers().find((u) => u.id === p.verdict!.adminId); return a ? { id: a.id, name: a.name } : null })(),
        } : null,
      }
    })
    return { status: 200, body: { posts } }
  }
  if (path === '/api/posts' && method === 'POST') {
    const post = demoStore.createPost(body, currentUser.id)
    return { status: 200, body: { post, message: 'Пост отправлен на рассмотрение администратора' } }
  }

  // ====== /api/posts/[id] ======
  const postMatch = path.match(/^\/api\/posts\/([^/]+)$/)
  if (postMatch) {
    const id = postMatch[1]
    if (method === 'GET') {
      const post = demoStore.getPost(id)
      if (!post) return { status: 404, body: { error: 'Пост не найден' } }
      const author = demoStore.listUsers().find((u) => u.id === post.authorId)
      const faction = post.factionId ? demoStore.getFactionById(post.factionId) : null
      return {
        status: 200,
        body: {
          ...post,
          author: author ? { id: author.id, name: author.name } : null,
          faction: faction ? { id: faction.id, name: faction.name } : null,
          verdict: post.verdict ? {
            ...post.verdict,
            admin: (() => { const a = demoStore.listUsers().find((u) => u.id === post.verdict!.adminId); return a ? { id: a.id, name: a.name } : null })(),
          } : null,
        },
      }
    }
    if (method === 'DELETE') {
      try {
        demoStore.deletePost(id, currentUser.id, currentUser.role)
        return { status: 200, body: { success: true } }
      } catch (e) {
        return { status: 403, body: { error: e instanceof Error ? e.message : 'Ошибка' } }
      }
    }
  }

  // ====== /api/posts/[id]/verdict ======
  const verdictMatch = path.match(/^\/api\/posts\/([^/]+)\/verdict$/)
  if (verdictMatch && method === 'POST') {
    if (currentUser.role !== 'ADMIN') return { status: 403, body: { error: 'Требуются права администратора' } }
    const postId = verdictMatch[1]
    const verdict = demoStore.issueVerdict(postId, body.roleplayText, body.technicalText, currentUser.id)
    return { status: 200, body: { verdict, message: 'Вердикт вынесен' } }
  }

  // ====== /api/factions ======
  if (path === '/api/factions' && method === 'GET') {
    const factions = currentUser.role === 'ADMIN'
      ? demoStore.listApprovedFactions()
      : (demoStore.getFactionByUser(currentUser.id) ? [demoStore.getFactionByUser(currentUser.id)!] : [])
    return { status: 200, body: { factions } }
  }
  if (path === '/api/factions' && method === 'POST') {
    try {
      const faction = demoStore.createFaction(body, currentUser.id)
      return { status: 200, body: { faction, message: 'Княжество создано. Ожидает одобрения администратора.' } }
    } catch (e) {
      return { status: 400, body: { error: e instanceof Error ? e.message : 'Ошибка' } }
    }
  }

  // ====== /api/factions/[id] ======
  const factionMatch = path.match(/^\/api\/factions\/([^/]+)$/)
  if (factionMatch && method === 'GET') {
    const faction = demoStore.getFactionById(factionMatch[1])
    if (!faction) return { status: 404, body: { error: 'Княжество не найдено' } }
    const owner = demoStore.listUsers().find((u) => u.id === faction.userId)
    const postCount = demoStore.listPosts({ authorId: faction.userId }).length
    return { status: 200, body: { faction, owner: owner ? { id: owner.id, name: owner.name } : null, _count: { posts: postCount } } }
  }

  // ====== /api/factions/[id]/stats ======
  const statsMatch = path.match(/^\/api\/factions\/([^/]+)\/stats$/)
  if (statsMatch && method === 'GET') {
    const stats = demoStore.getFactionStats(statsMatch[1])
    return { status: 200, body: { stats } }
  }

  // ====== /api/directory ======
  if (path === '/api/directory' && method === 'GET') {
    const factions = demoStore.listApprovedFactions().map((f) => {
      const owner = demoStore.listUsers().find((u) => u.id === f.userId)
      const postCount = demoStore.listPosts({ authorId: f.userId }).length
      return { ...f, owner: owner ? { id: owner.id, name: owner.name } : null, _count: { posts: postCount } }
    })
    return { status: 200, body: { factions } }
  }
  const dirMatch = path.match(/^\/api\/directory\/([^/]+)$/)
  if (dirMatch && method === 'GET') {
    const faction = demoStore.getFactionById(dirMatch[1])
    if (!faction) return { status: 404, body: { error: 'Княжество не найдено' } }
    const stats = demoStore.getFactionStats(faction.id)
    const recentPosts = demoStore.listPosts({ authorId: faction.userId }).slice(0, 5)
    return { status: 200, body: { faction, stats, recentPosts } }
  }

  // ====== /api/chats ======
  if (path === '/api/chats' && method === 'GET') {
    const chats = demoStore.listChats(currentUser.id, currentUser.role)
    return { status: 200, body: { chats } }
  }
  if (path === '/api/chats' && method === 'POST') {
    const chat = demoStore.createChat(body, currentUser.id)
    return { status: 200, body: { chat, message: 'Переговоры созданы' } }
  }
  const chatMatch = path.match(/^\/api\/chats\/([^/]+)$/)
  if (chatMatch && method === 'GET') {
    const chat = demoStore.getChat(chatMatch[1])
    if (!chat) return { status: 404, body: { error: 'Чат не найден' } }
    return { status: 200, body: { chat } }
  }
  const msgMatch = path.match(/^\/api\/chats\/([^/]+)\/messages$/)
  if (msgMatch && method === 'GET') {
    const messages = demoStore.listMessages(msgMatch[1]).map((m) => {
      const u = demoStore.listUsers().find((x) => x.id === m.userId)
      const f = u?.factionId ? demoStore.getFactionById(u.factionId) : null
      return { ...m, user: u ? { id: u.id, name: u.name, faction: f ? { id: f.id, name: f.name } : null } : null }
    })
    return { status: 200, body: { messages } }
  }
  if (msgMatch && method === 'POST') {
    try {
      const msg = demoStore.sendMessage(msgMatch[1], currentUser.id, body.content)
      const u = demoStore.listUsers().find((x) => x.id === msg.userId)
      const f = u?.factionId ? demoStore.getFactionById(u.factionId) : null
      return {
        status: 200,
        body: { message: { ...msg, user: u ? { id: u.id, name: u.name, faction: f ? { id: f.id, name: f.name } : null } : null } },
      }
    } catch (e) {
      return { status: 403, body: { error: e instanceof Error ? e.message : 'Ошибка' } }
    }
  }

  // ====== /api/news ======
  if (path === '/api/news' && method === 'GET') {
    const news = demoStore.listNews().map((n) => {
      const author = demoStore.listUsers().find((u) => u.id === n.authorId)
      return { ...n, author: author ? { id: author.id, name: author.name } : { id: 'system', name: 'Летописец' } }
    })
    return { status: 200, body: { news } }
  }
  if (path === '/api/news' && method === 'POST') {
    if (currentUser.role !== 'ADMIN') return { status: 403, body: { error: 'Требуются права администратора' } }
    const news = demoStore.createNews(body, currentUser.id)
    return { status: 200, body: { news, message: 'Новость опубликована' } }
  }
  const newsMatch = path.match(/^\/api\/news\/([^/]+)$/)
  if (newsMatch && method === 'GET') {
    const news = demoStore.getNews(newsMatch[1])
    if (!news) return { status: 404, body: { error: 'Новость не найдена' } }
    const author = demoStore.listUsers().find((u) => u.id === news.authorId)
    return { status: 200, body: { news, author: author ? { id: author.id, name: author.name } : null } }
  }

  // ====== /api/battles ======
  if (path === '/api/battles' && method === 'GET') {
    return { status: 200, body: { battles: demoStore.listBattles() } }
  }
  const battleMatch = path.match(/^\/api\/battles\/([^/]+)$/)
  if (battleMatch && method === 'GET') {
    const battle = demoStore.getBattle(battleMatch[1])
    if (!battle) return { status: 404, body: { error: 'Битва не найдена' } }
    return { status: 200, body: { battle, forces: [], participants: [] } }
  }

  // ====== /api/chronicle ======
  if (path === '/api/chronicle' && method === 'GET') {
    return { status: 200, body: { articles: demoStore.listChronicle() } }
  }
  const chrMatch = path.match(/^\/api\/chronicle\/([^/]+)$/)
  if (chrMatch && method === 'GET') {
    const article = demoStore.getChronicle(chrMatch[1])
    if (!article) return { status: 404, body: { error: 'Статья не найдена' } }
    return { status: 200, body: { article } }
  }

  // ====== /api/bestiary ======
  if (path === '/api/bestiary' && method === 'GET') {
    const category = query.get('category') || undefined
    return { status: 200, body: { entries: demoStore.listBestiary(category) } }
  }
  const bestMatch = path.match(/^\/api\/bestiary\/([^/]+)$/)
  if (bestMatch && method === 'GET') {
    const entry = demoStore.getBestiary(bestMatch[1])
    if (!entry) return { status: 404, body: { error: 'Запись не найдена' } }
    return { status: 200, body: { entry } }
  }

  // ====== /api/bookmarks ======
  if (path === '/api/bookmarks' && method === 'GET') {
    const bookmarks = demoStore.listBookmarks(currentUser.id)
    return { status: 200, body: { bookmarks } }
  }
  if (path === '/api/bookmarks' && method === 'POST') {
    const added = demoStore.toggleBookmark(currentUser.id, body.type, body.entityId)
    return { status: 200, body: { added } }
  }
  if (path === '/api/bookmarks' && method === 'DELETE') {
    demoStore.toggleBookmark(currentUser.id, body.type, body.entityId)
    return { status: 200, body: { success: true } }
  }

  // ====== /api/activity ======
  if (path === '/api/activity' && method === 'GET') {
    const activity = demoStore.listActivity().map((a) => {
      const u = demoStore.listUsers().find((x) => x.id === a.userId)
      return { ...a, user: u ? { id: u.id, name: u.name } : null }
    })
    return { status: 200, body: { activity } }
  }

  // ====== /api/achievements ======
  if (path === '/api/achievements' && method === 'GET') {
    const postCount = demoStore.listPosts({ authorId: currentUser.id }).length
    const achievements = [
      { id: 'first_post', title: 'Первый пост', description: 'Создайте свой первый пост', icon: 'ScrollText', unlocked: postCount >= 1 },
      { id: 'ten_posts', title: 'Летописец', description: 'Напишите 10 постов', icon: 'BookOpen', unlocked: postCount >= 10 },
      { id: 'first_faction', title: 'Князь', description: 'Создайте своё княжество', icon: 'Shield', unlocked: !!currentUser.factionId },
    ]
    return { status: 200, body: { achievements, unlockedCount: achievements.filter((a) => a.unlocked).length } }
  }

  // ====== /api/leaderboard ======
  if (path === '/api/leaderboard' && method === 'GET') {
    const users = demoStore.listUsers().map((u) => {
      const postCount = demoStore.listPosts({ authorId: u.id }).length
      const score = postCount * 10
      const faction = u.factionId ? demoStore.getFactionById(u.factionId) : null
      return { id: u.id, name: u.name, role: u.role, faction: faction ? { name: faction.name } : null, _count: { posts: postCount }, score }
    }).sort((a, b) => b.score - a.score)
    return { status: 200, body: { users } }
  }

  // ====== /api/profile ======
  if (path === '/api/profile' && method === 'GET') {
    return { status: 200, body: { user: demoUserToSession(currentUser) } }
  }
  if (path === '/api/profile' && method === 'PATCH') {
    const updated = demoStore.updateProfile(currentUser.id, body)
    return { status: 200, body: { user: demoUserToSession(updated) } }
  }

  // ====== /api/notifications ======
  if (path === '/api/notifications' && method === 'GET') {
    const pending = currentUser.role === 'ADMIN'
      ? demoStore.listPosts({ status: 'PENDING' }).length
      : demoStore.listPosts({ authorId: currentUser.id, status: 'VERDICTED' }).length
    return { status: 200, body: { notifications: [], count: pending } }
  }

  // ====== /api/admin/users ======
  if (path === '/api/admin/users' && method === 'GET') {
    if (currentUser.role !== 'ADMIN') return { status: 403, body: { error: 'Требуются права администратора' } }
    const users = demoStore.listUsers().map((u) => {
      const faction = u.factionId ? demoStore.getFactionById(u.factionId) : null
      const postCount = demoStore.listPosts({ authorId: u.id }).length
      return {
        ...u,
        password: undefined, // не отдаём пароль
        faction: faction ? { id: faction.id, name: faction.name, isApproved: faction.isApproved } : null,
        _count: { posts: postCount },
      }
    })
    return { status: 200, body: { users } }
  }

  // ====== /api/admin/users/[id] (ban/unban) ======
  const adminUserMatch = path.match(/^\/api\/admin\/users\/([^/]+)$/)
  if (adminUserMatch && method === 'POST') {
    if (currentUser.role !== 'ADMIN') return { status: 403, body: { error: 'Требуются права администратора' } }
    const userId = adminUserMatch[1]
    if (body.action === 'ban') {
      demoStore.banUser(userId, body.reason || 'Нарушение правил', currentUser.id)
      return { status: 200, body: { message: 'Пользователь заблокирован' } }
    }
    if (body.action === 'unban') {
      demoStore.unbanUser(userId, currentUser.id)
      return { status: 200, body: { message: 'Пользователь разблокирован' } }
    }
  }

  // ====== /api/upload (fallback — не реально в demo) ======
  if (path === '/api/upload' && method === 'POST') {
    return { status: 200, body: { url: '', markdown: '', message: 'В demo-режиме загрузка файлов недоступна' } }
  }

  // Unknown endpoint
  return { status: 404, body: { error: 'Не найдено (demo): ' + path } }
}
