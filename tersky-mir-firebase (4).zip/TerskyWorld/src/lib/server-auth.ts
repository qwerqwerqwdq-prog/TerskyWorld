import type { NextRequest } from 'next/server'
import { getAdminAuth } from './firebase-admin'
import { getAdminDb } from './firebase-admin'
import { jsonResponse, errorResponse } from './json-response'

export interface AuthContext {
  userId: string
  role: string
  factionId: string | null
}

// Извлекаем Bearer-токен из Authorization header и верифицируем через Firebase Admin
export async function getAuthContext(req?: NextRequest): Promise<AuthContext | null> {
  const authHeader = req?.headers.get('authorization') || req?.headers.get('Authorization')
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null

  const idToken = authHeader.slice('Bearer '.length).trim()
  if (!idToken) return null

  try {
    const decoded = await getAdminAuth().verifyIdToken(idToken)
    if (!decoded.uid) return null

    const db = getAdminDb()
    const userSnap = await db.collection('users').doc(decoded.uid).get()
    if (!userSnap.exists) return null

    const data = userSnap.data() as {
      role?: string
      isBanned?: boolean
      bannedReason?: string | null
      factionId?: string | null
    }

    // Проверка бана
    if (data.isBanned) {
      throw new Error(`Аккаунт заблокирован${data.bannedReason ? `: ${data.bannedReason}` : ''}`)
    }

    return {
      userId: userSnap.id,
      role: data.role || 'PLAYER',
      factionId: data.factionId || null,
    }
  } catch (e) {
    // Если бан — прокидываем ошибку, чтобы caller мог показать её пользователю
    if (e instanceof Error && e.message.includes('заблокирован')) throw e
    return null
  }
}

export async function requireAuth(req?: NextRequest): Promise<AuthContext> {
  const ctx = await getAuthContext(req)
  if (!ctx) throw new Error('Не авторизован')
  return ctx
}

export async function requireAdmin(req?: NextRequest): Promise<AuthContext> {
  const ctx = await requireAuth(req)
  if (ctx.role !== 'ADMIN') throw new Error('Требуются права администратора')
  return ctx
}

// Проверка User-Agent для блокировки ботов/сканеров
export function isBotRequest(req: NextRequest): boolean {
  const ua = req.headers.get('user-agent')?.toLowerCase() || ''
  const botPatterns = [
    'curl', 'wget', 'python-requests', 'aiohttp', 'requests/',
    'httpclient', 'java/', 'go-http-client', 'okhttp',
    'scrapy', 'mechanize', 'httpx', 'node-fetch/',
    'googlebot', 'bingbot', 'yandexbot', 'duckduckbot',
    'baiduspider', 'slurp', 'facebot', 'ia_archiver',
  ]
  return botPatterns.some((p) => ua.includes(p))
}

// re-export для обратной совместимости
export { jsonResponse, errorResponse }
