'use client'

import { useState, useCallback } from 'react'

interface ApiState<T> {
  data: T | null
  loading: boolean
  error: string | null
}

// Хук для выполнения API-запросов (GET по умолчанию)
export function useApi<T>(url: string | null) {
  const [state, setState] = useState<ApiState<T>>({
    data: null,
    loading: !!url,
    error: null,
  })

  const refetch = useCallback(async () => {
    if (!url) return
    setState((s) => ({ ...s, loading: true, error: null }))
    try {
      const res = await fetch(url)
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Ошибка запроса')
      setState({ data, loading: false, error: null })
      return data
    } catch (e) {
      setState({ data: null, loading: false, error: e instanceof Error ? e.message : 'Ошибка' })
      return null
    }
  }, [url])

  return { ...state, refetch }
}

// Хук для мутаций (POST/PUT/DELETE)
export function useMutation() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const mutate = useCallback(
    async <T>(
      url: string,
      options: {
        method: 'POST' | 'PUT' | 'DELETE' | 'PATCH'
        body?: unknown
      }
    ): Promise<T | null> => {
      setLoading(true)
      setError(null)
      try {
        const res = await fetch(url, {
          method: options.method,
          headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
          body: options.body ? JSON.stringify(options.body) : undefined,
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Ошибка запроса')
        return data as T
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Ошибка')
        return null
      } finally {
        setLoading(false)
      }
    },
    []
  )

  return { mutate, loading, error }
}
