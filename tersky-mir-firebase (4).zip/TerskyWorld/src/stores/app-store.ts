import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ViewKey =
  | 'dashboard'
  | 'my-faction'
  | 'posts'
  | 'chats'
  | 'battles'
  | 'news'
  | 'chronicle'
  | 'bestiary'
  | 'activity'
  | 'profile'
  | 'directory'
  | 'bookmarks'
  | 'achievements'
  | 'leaderboard'
  | 'admin-users'
  | 'admin-factions'
  | 'admin-posts'
  | 'admin-news'
  | 'admin-chats'
  | 'admin-battles'
  | 'admin-chronicle'
  | 'admin-bestiary'

interface AppState {
  currentView: ViewKey
  selectedId: string | null // ID выбранной сущности (фракции, поста, чата и т.д.)
  sidebarOpen: boolean
  setView: (view: ViewKey, selectedId?: string | null) => void
  setSelectedId: (id: string | null) => void
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      currentView: 'dashboard',
      selectedId: null,
      sidebarOpen: true,
      setView: (view, selectedId = null) => set({ currentView: view, selectedId }),
      setSelectedId: (id) => set({ selectedId: id }),
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
    }),
    {
      name: 'tersky-nav',
      // Don't persist currentView — it should reset to dashboard on each login
      partialize: () => ({}),
    }
  )
)
